using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.DTOs.Roles;
using NerdERP.Services.Roles;

namespace NerdERP.WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class RolesController : ControllerBase
    {
        private readonly IRoleService _roleService;

        public RolesController(IRoleService roleService)
        {
            _roleService = roleService;
        }

        /// <summary>
        /// Create a new role
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<RoleResponse>> CreateRole([FromBody] CreateRoleRequest request)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();

                var validationResponse = ServiceResponse<RoleResponse>.CreateFailure(
                    "Validation failed.", 400, errors);

                return HandleServiceResponse(validationResponse);
            }

            var result = await _roleService.CreateAsync(request);
            return HandleServiceResponse(result);
        }

        /// <summary>
        /// Update an existing role
        /// </summary>
        [HttpPut("{id}")]
        public async Task<ActionResult<RoleResponse>> UpdateRole(int id, [FromBody] UpdateRoleRequest request)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();

                var validationResponse = ServiceResponse<RoleResponse>.CreateFailure(
                    "Validation failed.", 400, errors);

                return HandleServiceResponse(validationResponse);
            }

            var result = await _roleService.UpdateAsync(id, request);
            return HandleServiceResponse(result);
        }

        /// <summary>
        /// Delete a role
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<ActionResult<bool>> DeleteRole(int id)
        {
            var result = await _roleService.DeleteAsync(id);
            return HandleServiceResponse(result);
        }

        /// <summary>
        /// Get role by ID
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<RoleResponse>> GetRole(int id)
        {
            var result = await _roleService.GetByIdAsync(id);
            return HandleServiceResponse(result);
        }

        /// <summary>
        /// Get all roles with paging
        /// </summary>
        [HttpPost("GetAllWithPaging")]
        public async Task<ActionResult<PagedResult<RoleResponse>>> GetAllRoles(
            [FromBody] PagingAndSortingParams pagingParams, [FromQuery] string? searchTerm = null)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();

                var validationResponse = ServiceResponse<PagedResult<RoleResponse>>.CreateFailure(
                    "Validation failed.", 400, errors);

                return HandleServiceResponse(validationResponse);
            }

            var result = await _roleService.GetAllWithPagingAsync(pagingParams, searchTerm);
            return HandleServiceResponse(result);
        }

        /// <summary>
        /// Get all permissions grouped by module
        /// </summary>
        [HttpGet("permissions")]
        public async Task<ActionResult<List<ModulePermissionsResponse>>> GetAllPermissions()
        {
            var result = await _roleService.GetAllPermissionsByModuleAsync();
            return HandleServiceResponse(result);
        }

        /// <summary>
        /// Get permissions for a specific role
        /// </summary>
        [HttpGet("{roleId}/permissions")]
        public async Task<ActionResult<List<PermissionResponse>>> GetRolePermissions(int roleId)
        {
            var result = await _roleService.GetRolePermissionsAsync(roleId);
            return HandleServiceResponse(result);
        }

        /// <summary>
        /// Assign permissions to a role
        /// </summary>
        [HttpPost("{roleId}/permissions")]
        public async Task<ActionResult<bool>> AssignPermissions(int roleId, [FromBody] AssignPermissionsRequest request)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();

                var validationResponse = ServiceResponse<bool>.CreateFailure(
                    "Validation failed.", 400, errors);

                return HandleServiceResponse(validationResponse);
            }

            var result = await _roleService.AssignPermissionsAsync(roleId, request.PermissionIds);
            return HandleServiceResponse(result);
        }

        /// <summary>
        /// Check if current user has specific permission
        /// </summary>
        [HttpGet("check-permission")]
        public async Task<ActionResult<bool>> CheckPermission([FromQuery] string module, [FromQuery] string action)
        {
            if (string.IsNullOrWhiteSpace(module) || string.IsNullOrWhiteSpace(action))
            {
                var validationResponse = ServiceResponse<bool>.CreateFailure(
                    "Module and action parameters are required.", 400);

                return HandleServiceResponse(validationResponse);
            }

            // Get current user ID from claims
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdClaim, out int userId))
            {
                var authResponse = ServiceResponse<bool>.CreateFailure(
                    "Invalid user authentication.", 401);

                return HandleServiceResponse(authResponse);
            }

            var result = await _roleService.HasPermissionAsync(userId, module, action);
            return HandleServiceResponse(result);
        }

        private ActionResult<T> HandleServiceResponse<T>(ServiceResponse<T> response)
        {
            if (response.IsSuccess)
            {
                return StatusCode(response.StatusCode, response);
            }

            return StatusCode(response.StatusCode, response);
        }
    }
}