using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Products;
using NerdERP.Services.Products;

namespace NerdERP.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ProductsController : BaseApiController
{
    private readonly IProductService _productService;

    public ProductsController(IProductService productService)
    {
        _productService = productService;
    }

    /// <summary>
    /// Create a new product
    /// </summary>
    [HttpPost]
    [Route("Create")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateProduct([FromBody] CreateProductRequest request)
    {
        var response = await _productService.CreateAsync(request);
        return HandleServiceResponse(response);
    }

    /// <summary>
    /// Update an existing product
    /// </summary>
    [HttpPut]
    [Route("Update")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateProduct([FromBody] UpdateProductRequest request)
    {
        var response = await _productService.UpdateAsync(request);
        return HandleServiceResponse(response);
    }

    /// <summary>
    /// Delete a product by ID
    /// </summary>
    [HttpDelete]
    [Route("Delete/{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeleteProduct(int id)
    {
        var response = await _productService.DeleteAsync(id);
        return HandleServiceResponse(response);
    }

    /// <summary>
    /// Get product by ID
    /// </summary>
    [HttpGet]
    [Route("Get/{id}")]
    public async Task<IActionResult> GetProduct(int id)
    {
        var response = await _productService.GetByIdAsync(id);
        return HandleServiceResponse(response);
    }

    /// <summary>
    /// Get all products with paging and filtering
    /// </summary>
    [HttpPost]
    [Route("GetAllWithPaging")]
    public async Task<IActionResult> GetAllProductsWithPaging(
        [FromQuery] PagingAndSortingParams pagingParams, 
        [FromBody] ProductFilterParams filterParams)
    {
        var response = await _productService.GetAllWithPagingAsync(pagingParams, filterParams);
        return HandleServiceResponse(response);
    }
}
