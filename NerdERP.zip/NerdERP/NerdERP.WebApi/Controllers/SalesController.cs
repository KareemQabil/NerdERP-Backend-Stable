using Microsoft.AspNetCore.Mvc;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Sales;
using NerdERP.Services.Sales;

namespace NerdERP.WebApi.Controllers;

[Route("api/[controller]")]
public class SalesController : BaseApiController
{
    private readonly ISaleService _saleService;

    public SalesController(ISaleService saleService)
    {
        _saleService = saleService;
    }

    [HttpPost("Create")]
    public async Task<IActionResult> Create([FromBody] CreateSaleRequest request)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            var validationResponse = ServiceResponse<SaleResponse>.CreateFailure(
                "Validation failed.", 400, errors);

            return HandleServiceResponse(validationResponse);
        }

        var result = await _saleService.CreateAsync(request);
        return HandleServiceResponse(result);
    }

    [HttpPut("Update/{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateSaleRequest request)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            var validationResponse = ServiceResponse<SaleResponse>.CreateFailure(
                "Validation failed.", 400, errors);

            return HandleServiceResponse(validationResponse);
        }

        var result = await _saleService.UpdateAsync(id, request);
        return HandleServiceResponse(result);
    }

    [HttpDelete("Delete/{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _saleService.DeleteAsync(id);
        return HandleServiceResponse(result);
    }

    [HttpGet("Get/{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var result = await _saleService.GetByIdAsync(id);
        return HandleServiceResponse(result);
    }

    [HttpPost("GetAllWithPaging")]
    public async Task<IActionResult> GetAllWithPaging(
        [FromBody] PagingAndSortingParams pagingParams,
        [FromQuery] SaleFilterParams? filterParams = null)
    {
        filterParams ??= new SaleFilterParams();

        var result = await _saleService.GetAllWithPagingAsync(pagingParams, filterParams);
        return HandleServiceResponse(result);
    }

    [HttpGet("GetTotalSalesAmount")]
    public async Task<IActionResult> GetTotalSalesAmount(
        [FromQuery] DateTime? startDate = null,
        [FromQuery] DateTime? endDate = null)
    {
        var result = await _saleService.GetTotalSalesAmountAsync(startDate, endDate);
        return HandleServiceResponse(result);
    }
}