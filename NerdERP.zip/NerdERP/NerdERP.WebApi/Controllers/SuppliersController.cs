using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Suppliers;
using NerdERP.Services.Suppliers;

namespace NerdERP.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class SuppliersController : BaseApiController
{
    private readonly ISupplierService _supplierService;

    public SuppliersController(ISupplierService supplierService)
    {
        _supplierService = supplierService;
    }

    [HttpPost]
    [Route("Create")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create([FromBody] CreateSupplierRequest request)
    {
        var response = await _supplierService.CreateAsync(request);
        return HandleServiceResponse(response);
    }

    [HttpPut]
    [Route("Update")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateSupplierRequest request)
    {
        if (id != request.Id)
        {
            var mismatchResponse = ServiceResponse<SupplierResponse>.CreateFailure("ID mismatch.", 400);
            return HandleServiceResponse(mismatchResponse);
        }
        var response = await _supplierService.UpdateAsync(request);
        return HandleServiceResponse(response);
    }

    [HttpDelete]
    [Route("Delete/{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id)
    {
        var response = await _supplierService.DeleteAsync(id);
        return HandleServiceResponse(response);
    }

    [HttpGet]
    [Route("Get/{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var response = await _supplierService.GetByIdAsync(id);
        return HandleServiceResponse(response);
    }

    [HttpPost]
    [Route("GetAllWithPaging")]
    public async Task<IActionResult> GetAllWithPaging(
        [FromQuery] PagingAndSortingParams pagingParams, 
        [FromBody] SupplierFilterParams filterParams)
    {
        var response = await _supplierService.GetAllWithPagingAsync(pagingParams, filterParams);
        return HandleServiceResponse(response);
    }

    [HttpGet]
    [Route("GetByEmail/{email}")]
    public async Task<IActionResult> GetByEmail(string email)
    {
        var response = await _supplierService.GetByEmailAsync(email);
        return HandleServiceResponse(response);
    }
}
