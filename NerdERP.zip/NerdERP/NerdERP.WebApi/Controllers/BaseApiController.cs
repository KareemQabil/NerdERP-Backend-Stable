using Microsoft.AspNetCore.Mvc;
using NerdERP.Core.Models.Common;

namespace NerdERP.WebApi.Controllers;

[ApiController]
public abstract class BaseApiController : ControllerBase
{
    protected IActionResult HandleServiceResponse<T>(ServiceResponse<T> response)
    {
        return response.StatusCode switch
        {
            200 => Ok(response),
            201 => Created("", response),
            400 => BadRequest(response),
            401 => Unauthorized(response),
            403 => new ForbidResult(),
            404 => NotFound(response),
            409 => Conflict(response),
            422 => UnprocessableEntity(response),
            500 => StatusCode(500, response),
            _ => StatusCode(response.StatusCode, response)
        };
    }
}