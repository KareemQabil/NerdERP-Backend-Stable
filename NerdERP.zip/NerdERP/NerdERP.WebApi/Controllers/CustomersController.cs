using Microsoft.AspNetCore.Mvc;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Customers;
using NerdERP.Services.Customers;

namespace NerdERP.WebApi.Controllers;

[Route("api/[controller]")]
public class CustomersController : BaseApiController
{
    private readonly ICustomerService _customerService;

    public CustomersController(ICustomerService customerService)
    {
        _customerService = customerService;
    }

    [HttpPost("Create")]
    public async Task<IActionResult> Create([FromBody] CreateCustomerRequest request)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            var validationResponse = ServiceResponse<CustomerResponse>.CreateFailure(
                "Validation failed.", 400, errors);

            return HandleServiceResponse(validationResponse);
        }

        var result = await _customerService.CreateAsync(request);
        return HandleServiceResponse(result);
    }

    [HttpPut("Update/{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateCustomerRequest request)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            var validationResponse = ServiceResponse<CustomerResponse>.CreateFailure(
                "Validation failed.", 400, errors);

            return HandleServiceResponse(validationResponse);
        }

        var result = await _customerService.UpdateAsync(id, request);
        return HandleServiceResponse(result);
    }

    [HttpDelete("Delete/{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _customerService.DeleteAsync(id);
        return HandleServiceResponse(result);
    }

    [HttpGet("Get/{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var result = await _customerService.GetByIdAsync(id);
        return HandleServiceResponse(result);
    }

    [HttpPost("GetAllWithPaging")]
    public async Task<IActionResult> GetAllWithPaging(
        [FromBody] PagingAndSortingParams pagingParams,
        [FromQuery] CustomerFilterParams? filterParams = null)
    {
        filterParams ??= new CustomerFilterParams();

        var result = await _customerService.GetAllWithPagingAsync(pagingParams, filterParams);
        return HandleServiceResponse(result);
    }

    [HttpGet("GetByEmail/{email}")]
    public async Task<IActionResult> GetByEmail(string email)
    {
        var result = await _customerService.GetByEmailAsync(email);
        return HandleServiceResponse(result);
    }
}
