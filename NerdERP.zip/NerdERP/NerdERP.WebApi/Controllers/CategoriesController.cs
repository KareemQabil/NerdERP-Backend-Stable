using Microsoft.AspNetCore.Mvc;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Categories;
using NerdERP.Services.Categories;

namespace NerdERP.WebApi.Controllers;

[Route("api/[controller]")]
public class CategoriesController : BaseApiController
{
    private readonly ICategoryService _categoryService;

    public CategoriesController(ICategoryService categoryService)
    {
        _categoryService = categoryService;
    }

    [HttpPost("Create")]
    public async Task<IActionResult> Create([FromBody] CreateCategoryRequest request)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            var validationResponse = ServiceResponse<CategoryResponse>.CreateFailure(
                "Validation failed.", 400, errors);

            return HandleServiceResponse(validationResponse);
        }

        var result = await _categoryService.CreateAsync(request);
        return HandleServiceResponse(result);
    }

    [HttpPut("Update/{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateCategoryRequest request)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            var validationResponse = ServiceResponse<CategoryResponse>.CreateFailure(
                "Validation failed.", 400, errors);

            return HandleServiceResponse(validationResponse);
        }

        var result = await _categoryService.UpdateAsync(id, request);
        return HandleServiceResponse(result);
    }

    [HttpDelete("Delete/{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _categoryService.DeleteAsync(id);
        return HandleServiceResponse(result);
    }

    [HttpGet("Get/{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var result = await _categoryService.GetByIdAsync(id);
        return HandleServiceResponse(result);
    }

    [HttpPost("GetAllWithPaging")]
    public async Task<IActionResult> GetAllWithPaging(
        [FromBody] PagingAndSortingParams pagingParams,
        [FromQuery] CategoryFilterParams? filterParams = null)
    {
        filterParams ??= new CategoryFilterParams();

        var result = await _categoryService.GetAllWithPagingAsync(pagingParams, filterParams);
        return HandleServiceResponse(result);
    }
}
