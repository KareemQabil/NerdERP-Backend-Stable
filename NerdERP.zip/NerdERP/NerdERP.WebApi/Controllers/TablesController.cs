using Microsoft.AspNetCore.Mvc;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Tables;
using NerdERP.Services.Tables;

namespace NerdERP.WebApi.Controllers;

[Route("api/[controller]")]
public class TablesController : BaseApiController
{
    private readonly ITableService _tableService;

    public TablesController(ITableService tableService)
    {
        _tableService = tableService;
    }

    [HttpPost("Create")]
    public async Task<IActionResult> Create([FromBody] CreateTableRequest request)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            var validationResponse = ServiceResponse<TableResponse>.CreateFailure(
                "Validation failed.", 400, errors);

            return HandleServiceResponse(validationResponse);
        }

        var result = await _tableService.CreateAsync(request);
        return HandleServiceResponse(result);
    }

    [HttpPut("Update/{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateTableRequest request)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            var validationResponse = ServiceResponse<TableResponse>.CreateFailure(
                "Validation failed.", 400, errors);

            return HandleServiceResponse(validationResponse);
        }

        var result = await _tableService.UpdateAsync(id, request);
        return HandleServiceResponse(result);
    }

    [HttpDelete("Delete/{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _tableService.DeleteAsync(id);
        return HandleServiceResponse(result);
    }

    [HttpGet("Get/{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var result = await _tableService.GetByIdAsync(id);
        return HandleServiceResponse(result);
    }

    [HttpGet("GetByTableNumber/{tableNumber}")]
    public async Task<IActionResult> GetByTableNumber(string tableNumber)
    {
        var result = await _tableService.GetByTableNumberAsync(tableNumber);
        return HandleServiceResponse(result);
    }

    [HttpPost("GetAllWithPaging")]
    public async Task<IActionResult> GetAllWithPaging(
        [FromBody] PagingAndSortingParams pagingParams,
        [FromQuery] TableFilterParams? filterParams = null)
    {
        filterParams ??= new TableFilterParams();

        var result = await _tableService.GetAllWithPagingAsync(pagingParams, filterParams);
        return HandleServiceResponse(result);
    }

    [HttpGet("GetAvailableTables")]
    public async Task<IActionResult> GetAvailableTables([FromQuery] int? capacity = null)
    {
        var result = await _tableService.GetAvailableTablesAsync(capacity);
        return HandleServiceResponse(result);
    }

    // Table Status Management
    [HttpPut("OccupyTable/{tableId}/{saleId}")]
    public async Task<IActionResult> OccupyTable(int tableId, int saleId)
    {
        var result = await _tableService.OccupyTableAsync(tableId, saleId);
        return HandleServiceResponse(result);
    }

    [HttpPut("ReleaseTable/{tableId}")]
    public async Task<IActionResult> ReleaseTable(int tableId)
    {
        var result = await _tableService.ReleaseTableAsync(tableId);
        return HandleServiceResponse(result);
    }

    [HttpPut("SetTableStatus/{tableId}/{status}")]
    public async Task<IActionResult> SetTableStatus(int tableId, TableStatus status)
    {
        var result = await _tableService.SetTableStatusAsync(tableId, status);
        return HandleServiceResponse(result);
    }

    // Reservation Management
    [HttpPost("CreateReservation/{tableId}")]
    public async Task<IActionResult> CreateReservation(int tableId, [FromBody] ReserveTableRequest request)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            var validationResponse = ServiceResponse<TableReservationResponse>.CreateFailure(
                "Validation failed.", 400, errors);

            return HandleServiceResponse(validationResponse);
        }

        var result = await _tableService.CreateReservationAsync(tableId, request);
        return HandleServiceResponse(result);
    }

    [HttpPut("ConfirmReservation/{reservationId}")]
    public async Task<IActionResult> ConfirmReservation(int reservationId)
    {
        var result = await _tableService.ConfirmReservationAsync(reservationId);
        return HandleServiceResponse(result);
    }

    [HttpPut("CancelReservation/{reservationId}")]
    public async Task<IActionResult> CancelReservation(int reservationId)
    {
        var result = await _tableService.CancelReservationAsync(reservationId);
        return HandleServiceResponse(result);
    }

    [HttpPut("SeatReservation/{reservationId}")]
    public async Task<IActionResult> SeatReservation(int reservationId)
    {
        var result = await _tableService.SeatReservationAsync(reservationId);
        return HandleServiceResponse(result);
    }

    [HttpPost("GetReservations")]
    public async Task<IActionResult> GetReservations(
        [FromBody] PagingAndSortingParams pagingParams,
        [FromQuery] DateTime? date = null)
    {
        var result = await _tableService.GetReservationsAsync(pagingParams, date);
        return HandleServiceResponse(result);
    }
}