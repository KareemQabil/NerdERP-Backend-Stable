using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Schema.PurchaseOrder;
using NerdERP.Infrastructure.Data;
using System.Security.Claims;

namespace NerdERP.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class PurchaseOrdersController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public PurchaseOrdersController(ApplicationDbContext context)
    {
        _context = context;
    }

    /// <summary>
    /// Get all purchase orders
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<PurchaseOrderResponse>>> GetPurchaseOrders()
    {
        var purchaseOrders = await _context.PurchaseOrders
            .Include(po => po.Supplier)
            .Include(po => po.User)
            .Include(po => po.Items)
                .ThenInclude(poi => poi.Product)
            .OrderByDescending(po => po.OrderDate)
            .Select(po => MapToPurchaseOrderResponse(po))
            .ToListAsync();

        return Ok(purchaseOrders);
    }

    /// <summary>
    /// Get purchase order by ID
    /// </summary>
    [HttpGet("{id}")]
    public async Task<ActionResult<PurchaseOrderResponse>> GetPurchaseOrder(int id)
    {
        var purchaseOrder = await _context.PurchaseOrders
            .Include(po => po.Supplier)
            .Include(po => po.User)
            .Include(po => po.Items)
                .ThenInclude(poi => poi.Product)
            .FirstOrDefaultAsync(po => po.Id == id);

        if (purchaseOrder == null)
        {
            return NotFound($"Purchase order with ID {id} not found");
        }

        return Ok(MapToPurchaseOrderResponse(purchaseOrder));
    }

    /// <summary>
    /// Create a new purchase order
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<PurchaseOrderResponse>> CreatePurchaseOrder([FromBody] CreatePurchaseOrderRequest request)
    {
        using var transaction = await _context.Database.BeginTransactionAsync();
        
        try
        {
            // Get current user ID from claims
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdClaim, out int userId))
            {
                return BadRequest("Invalid user authentication");
            }

            // Validate supplier exists
            var supplier = await _context.Suppliers.FindAsync(request.SupplierId);
            if (supplier == null || !supplier.IsActive)
            {
                return BadRequest($"Supplier with ID {request.SupplierId} not found or inactive");
            }

            // Validate all products exist and collect them
            var productIds = request.Items.Select(item => item.ProductId).ToList();
            var products = await _context.Products
                .Where(p => productIds.Contains(p.Id))
                .ToDictionaryAsync(p => p.Id, p => p);

            foreach (var item in request.Items)
            {
                if (!products.ContainsKey(item.ProductId))
                {
                    return BadRequest($"Product with ID {item.ProductId} not found");
                }
            }

            // Generate unique purchase order number
            var orderNumber = await GeneratePurchaseOrderNumber();

            // Calculate totals
            decimal subTotal = request.Items.Sum(item => item.QuantityOrdered * item.UnitCost);
            decimal taxAmount = subTotal * 0.1m; // 10% tax
            decimal totalAmount = subTotal + taxAmount;

            // Create purchase order items
            var purchaseOrderItems = request.Items.Select(item => new PurchaseOrderItem
            {
                ProductId = item.ProductId,
                UnitCost = item.UnitCost,
                QuantityOrdered = item.QuantityOrdered,
                QuantityReceived = 0,
                LineTotal = item.QuantityOrdered * item.UnitCost
            }).ToList();

            // Create purchase order
            var purchaseOrder = new PurchaseOrder
            {
                OrderNumber = orderNumber,
                SupplierId = request.SupplierId,
                UserId = userId,
                SubTotal = subTotal,
                TaxAmount = taxAmount,
                TotalAmount = totalAmount,
                Status = "Pending",
                OrderDate = DateTime.UtcNow,
                Notes = request.Notes,
                Items = purchaseOrderItems
            };

            _context.PurchaseOrders.Add(purchaseOrder);
            await _context.SaveChangesAsync();

            await transaction.CommitAsync();

            // Return the created purchase order with full details
            var createdPurchaseOrder = await _context.PurchaseOrders
                .Include(po => po.Supplier)
                .Include(po => po.User)
                .Include(po => po.Items)
                    .ThenInclude(poi => poi.Product)
                .FirstAsync(po => po.Id == purchaseOrder.Id);

            return CreatedAtAction(nameof(GetPurchaseOrder), new { id = purchaseOrder.Id }, MapToPurchaseOrderResponse(createdPurchaseOrder));
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            return StatusCode(500, $"Error creating purchase order: {ex.Message}");
        }
    }

    /// <summary>
    /// Receive items from a purchase order and update inventory
    /// </summary>
    [HttpPost("{id}/receive")]
    public async Task<ActionResult<PurchaseOrderResponse>> ReceivePurchaseOrder(int id, [FromBody] ReceivePurchaseOrderRequest request)
    {
        using var transaction = await _context.Database.BeginTransactionAsync();
        
        try
        {
            // Get purchase order with items
            var purchaseOrder = await _context.PurchaseOrders
                .Include(po => po.Items)
                    .ThenInclude(poi => poi.Product)
                .FirstOrDefaultAsync(po => po.Id == id);

            if (purchaseOrder == null)
            {
                return NotFound($"Purchase order with ID {id} not found");
            }

            if (purchaseOrder.Status == "Completed")
            {
                return BadRequest("Purchase order is already completed");
            }

            // Validate all received items belong to this purchase order
            var purchaseOrderItemIds = purchaseOrder.Items.Select(poi => poi.Id).ToList();
            foreach (var receiveItem in request.Items)
            {
                if (!purchaseOrderItemIds.Contains(receiveItem.PurchaseOrderItemId))
                {
                    return BadRequest($"Purchase order item with ID {receiveItem.PurchaseOrderItemId} does not belong to this purchase order");
                }
            }

            // Process each received item
            foreach (var receiveItem in request.Items)
            {
                var purchaseOrderItem = purchaseOrder.Items.First(poi => poi.Id == receiveItem.PurchaseOrderItemId);
                
                // Validate quantity received doesn't exceed quantity ordered
                var totalReceived = purchaseOrderItem.QuantityReceived + receiveItem.QuantityReceived;
                if (totalReceived > purchaseOrderItem.QuantityOrdered)
                {
                    return BadRequest($"Cannot receive more items than ordered for product {purchaseOrderItem.Product.Name}. " +
                                    $"Ordered: {purchaseOrderItem.QuantityOrdered}, Already received: {purchaseOrderItem.QuantityReceived}, " +
                                    $"Trying to receive: {receiveItem.QuantityReceived}");
                }

                // Update purchase order item
                purchaseOrderItem.QuantityReceived += receiveItem.QuantityReceived;

                // Update product inventory
                var product = purchaseOrderItem.Product;
                product.CurrentStock += receiveItem.QuantityReceived;
                product.UpdatedDate = DateTime.UtcNow;

                // Create stock movement record
                var stockMovement = new StockMovement
                {
                    ProductId = product.Id,
                    MovementType = "Purchase",
                    Quantity = receiveItem.QuantityReceived,
                    Reason = "Purchase order receipt",
                    Reference = purchaseOrder.OrderNumber,
                    UserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0"),
                    MovementDate = DateTime.UtcNow
                };

                _context.StockMovements.Add(stockMovement);
            }

            // Check if purchase order is fully received
            bool allItemsReceived = purchaseOrder.Items.All(poi => poi.QuantityReceived >= poi.QuantityOrdered);
            if (allItemsReceived)
            {
                purchaseOrder.Status = "Completed";
                purchaseOrder.ReceivedDate = DateTime.UtcNow;
            }
            else
            {
                purchaseOrder.Status = "Partially Received";
            }

            // Update notes if provided
            if (!string.IsNullOrWhiteSpace(request.Notes))
            {
                purchaseOrder.Notes = string.IsNullOrWhiteSpace(purchaseOrder.Notes) 
                    ? request.Notes 
                    : $"{purchaseOrder.Notes}\n{request.Notes}";
            }

            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            // Return updated purchase order
            var updatedPurchaseOrder = await _context.PurchaseOrders
                .Include(po => po.Supplier)
                .Include(po => po.User)
                .Include(po => po.Items)
                    .ThenInclude(poi => poi.Product)
                .FirstAsync(po => po.Id == id);

            return Ok(MapToPurchaseOrderResponse(updatedPurchaseOrder));
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            return StatusCode(500, $"Error receiving purchase order: {ex.Message}");
        }
    }

    /// <summary>
    /// Get purchase orders by supplier
    /// </summary>
    [HttpGet("supplier/{supplierId}")]
    public async Task<ActionResult<IEnumerable<PurchaseOrderResponse>>> GetPurchaseOrdersBySupplier(int supplierId)
    {
        var purchaseOrders = await _context.PurchaseOrders
            .Include(po => po.Supplier)
            .Include(po => po.User)
            .Include(po => po.Items)
                .ThenInclude(poi => poi.Product)
            .Where(po => po.SupplierId == supplierId)
            .OrderByDescending(po => po.OrderDate)
            .Select(po => MapToPurchaseOrderResponse(po))
            .ToListAsync();

        return Ok(purchaseOrders);
    }

    private async Task<string> GeneratePurchaseOrderNumber()
    {
        var today = DateTime.UtcNow;
        var datePrefix = $"PO-{today:yyyyMMdd}";
        
        var lastOrder = await _context.PurchaseOrders
            .Where(po => po.OrderNumber.StartsWith(datePrefix))
            .OrderByDescending(po => po.OrderNumber)
            .FirstOrDefaultAsync();

        int nextNumber = 1;
        if (lastOrder != null)
        {
            var lastNumberPart = lastOrder.OrderNumber.Substring(datePrefix.Length + 1);
            if (int.TryParse(lastNumberPart, out int lastNumber))
            {
                nextNumber = lastNumber + 1;
            }
        }

        return $"{datePrefix}-{nextNumber:D3}";
    }

    private static PurchaseOrderResponse MapToPurchaseOrderResponse(PurchaseOrder purchaseOrder)
    {
        return new PurchaseOrderResponse
        {
            Id = purchaseOrder.Id,
            OrderNumber = purchaseOrder.OrderNumber,
            SupplierId = purchaseOrder.SupplierId,
            SupplierName = purchaseOrder.Supplier?.Name ?? "",
            UserId = purchaseOrder.UserId,
            UserName = $"{purchaseOrder.User?.FirstName} {purchaseOrder.User?.LastName}".Trim(),
            SubTotal = purchaseOrder.SubTotal,
            TaxAmount = purchaseOrder.TaxAmount,
            TotalAmount = purchaseOrder.TotalAmount,
            Status = purchaseOrder.Status,
            OrderDate = purchaseOrder.OrderDate,
            ReceivedDate = purchaseOrder.ReceivedDate,
            Notes = purchaseOrder.Notes,
            Items = purchaseOrder.Items?.Select(poi => new PurchaseOrderItemResponse
            {
                Id = poi.Id,
                ProductId = poi.ProductId,
                ProductName = poi.Product?.Name ?? "",
                ProductSKU = poi.Product?.SKU ?? "",
                UnitCost = poi.UnitCost,
                QuantityOrdered = poi.QuantityOrdered,
                QuantityReceived = poi.QuantityReceived,
                LineTotal = poi.LineTotal
            }).ToList() ?? new List<PurchaseOrderItemResponse>()
        };
    }
}
