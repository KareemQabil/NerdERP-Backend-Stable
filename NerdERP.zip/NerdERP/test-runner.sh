#!/bin/bash

# NerdERP Backend - Automated Test Script
# This script runs automated tests against the NerdERP API

echo "🚀 Starting NerdERP Backend System Tests..."
echo "=================================================="

BASE_URL="http://localhost:5000"
TOKEN=""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to make HTTP requests and check status
test_endpoint() {
    local method=$1
    local endpoint=$2
    local data=$3
    local expected_status=$4
    local test_name=$5
    
    echo -e "${BLUE}Testing:${NC} $test_name"
    
    if [ "$method" = "GET" ]; then
        response=$(curl -s -w "HTTPSTATUS:%{http_code}" -H "Authorization: Bearer $TOKEN" "$BASE_URL$endpoint")
    else
        response=$(curl -s -w "HTTPSTATUS:%{http_code}" -X $method -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" -d "$data" "$BASE_URL$endpoint")
    fi
    
    http_code=$(echo $response | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
    body=$(echo $response | sed -e 's/HTTPSTATUS\:.*//g')
    
    if [ "$http_code" -eq "$expected_status" ]; then
        echo -e "${GREEN}✅ PASS${NC} - Status: $http_code"
    else
        echo -e "${RED}❌ FAIL${NC} - Expected: $expected_status, Got: $http_code"
        echo "Response: $body"
    fi
    echo ""
}

# Check if API is running
echo "🔍 Checking if API is running on $BASE_URL..."
if curl -s "$BASE_URL/swagger" > /dev/null; then
    echo -e "${GREEN}✅ API is running${NC}"
else
    echo -e "${RED}❌ API is not running. Please start the API first with 'dotnet run'${NC}"
    exit 1
fi

echo ""
echo "📝 Running Authentication Tests..."
echo "================================="

# Test 1: Register Admin User
test_endpoint "POST" "/api/auth/register" '{
    "username": "admin",
    "email": "admin@nerderp.com",
    "password": "AdminPass123!",
    "firstName": "System",
    "lastName": "Administrator",
    "role": "Admin"
}' 200 "Register Admin User"

# Test 2: Login and Get Token
echo -e "${BLUE}Getting authentication token...${NC}"
login_response=$(curl -s -X POST -H "Content-Type: application/json" -d '{
    "username": "admin",
    "password": "AdminPass123!"
}' "$BASE_URL/api/auth/login")

if echo "$login_response" | grep -q "token"; then
    TOKEN=$(echo $login_response | sed 's/.*"token":"\([^"]*\)".*/\1/')
    echo -e "${GREEN}✅ Login successful, token obtained${NC}"
else
    echo -e "${RED}❌ Login failed${NC}"
    echo "Response: $login_response"
    exit 1
fi

echo ""
echo "📂 Running Category Tests..."
echo "============================"

# Test 3: Create Categories
test_endpoint "POST" "/api/categories" '{
    "name": "Electronics",
    "description": "Electronic devices and accessories"
}' 201 "Create Electronics Category"

test_endpoint "POST" "/api/categories" '{
    "name": "Books",
    "description": "Books and educational materials"
}' 201 "Create Books Category"

# Test 4: Get Categories
test_endpoint "GET" "/api/categories" "" 200 "Get All Categories"

echo ""
echo "📦 Running Product Tests..."
echo "==========================="

# Test 5: Create Products
test_endpoint "POST" "/api/products" '{
    "name": "iPhone 15 Pro",
    "description": "Latest iPhone with advanced features",
    "sku": "IPH15PRO128",
    "price": 999.99,
    "stockQuantity": 50,
    "categoryId": 1,
    "reorderLevel": 10
}' 201 "Create iPhone Product"

test_endpoint "POST" "/api/products" '{
    "name": "Clean Code",
    "description": "A Handbook of Agile Software Craftsmanship",
    "sku": "BOOK-CLEAN-CODE",
    "price": 42.99,
    "stockQuantity": 30,
    "categoryId": 2,
    "reorderLevel": 5
}' 201 "Create Book Product"

# Test 6: Get Products
test_endpoint "GET" "/api/products" "" 200 "Get All Products"

# Test 7: Search Products
test_endpoint "GET" "/api/products/search?searchTerm=iPhone" "" 200 "Search Products by Name"

echo ""
echo "👥 Running Customer Tests..."
echo "============================"

# Test 8: Create Customers
test_endpoint "POST" "/api/customers" '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@email.com",
    "phone": "+1-555-0123",
    "address": "123 Main St, Anytown, ST 12345"
}' 201 "Create Customer - John Doe"

test_endpoint "POST" "/api/customers" '{
    "firstName": "Jane",
    "lastName": "Smith",
    "email": "jane.smith@email.com",
    "phone": "+1-555-0456",
    "address": "456 Oak Ave, Another City, ST 67890"
}' 201 "Create Customer - Jane Smith"

# Test 9: Get Customers
test_endpoint "GET" "/api/customers" "" 200 "Get All Customers"

# Test 10: Search Customers
test_endpoint "GET" "/api/customers/search?searchTerm=John" "" 200 "Search Customers by Name"

echo ""
echo "💰 Running Sales Tests..."
echo "========================="

# Test 11: Create Single Item Sale
test_endpoint "POST" "/api/sales" '{
    "customerId": 1,
    "paymentMethod": "Credit Card",
    "notes": "Test sale",
    "items": [
        {
            "productId": 1,
            "quantity": 1,
            "unitPrice": 999.99
        }
    ]
}' 201 "Create Single Item Sale"

# Test 12: Create Multi-Item Sale
test_endpoint "POST" "/api/sales" '{
    "customerId": 2,
    "paymentMethod": "Cash",
    "notes": "Multi-item purchase",
    "items": [
        {
            "productId": 1,
            "quantity": 1,
            "unitPrice": 999.99
        },
        {
            "productId": 2,
            "quantity": 2,
            "unitPrice": 42.99
        }
    ]
}' 201 "Create Multi-Item Sale"

# Test 13: Get Sales
test_endpoint "GET" "/api/sales" "" 200 "Get All Sales"

echo ""
echo "🚫 Running Error Handling Tests..."
echo "=================================="

# Test 14: Test Invalid Authentication
echo -e "${BLUE}Testing:${NC} Unauthorized Access (No Token)"
response=$(curl -s -w "HTTPSTATUS:%{http_code}" "$BASE_URL/api/products")
http_code=$(echo $response | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
if [ "$http_code" -eq 401 ]; then
    echo -e "${GREEN}✅ PASS${NC} - Status: $http_code"
else
    echo -e "${RED}❌ FAIL${NC} - Expected: 401, Got: $http_code"
fi
echo ""

# Test 15: Test Insufficient Stock
test_endpoint "POST" "/api/sales" '{
    "customerId": 1,
    "paymentMethod": "Credit Card",
    "notes": "Should fail - insufficient stock",
    "items": [
        {
            "productId": 1,
            "quantity": 1000,
            "unitPrice": 999.99
        }
    ]
}' 400 "Test Insufficient Stock (Should Fail)"

# Test 16: Test Invalid Product
test_endpoint "POST" "/api/sales" '{
    "customerId": 1,
    "paymentMethod": "Credit Card",
    "notes": "Should fail - invalid product",
    "items": [
        {
            "productId": 999,
            "quantity": 1,
            "unitPrice": 100.00
        }
    ]
}' 400 "Test Invalid Product ID (Should Fail)"

# Test 17: Test Duplicate SKU
test_endpoint "POST" "/api/products" '{
    "name": "Duplicate iPhone",
    "description": "This should fail due to duplicate SKU",
    "sku": "IPH15PRO128",
    "price": 999.99,
    "stockQuantity": 10,
    "categoryId": 1,
    "reorderLevel": 5
}' 400 "Test Duplicate SKU (Should Fail)"

echo ""
echo "📊 Running Inventory Verification..."
echo "===================================="

# Test 18: Verify Stock Reduction
echo -e "${BLUE}Testing:${NC} Verify iPhone Stock Reduction After Sales"
response=$(curl -s -H "Authorization: Bearer $TOKEN" "$BASE_URL/api/products/1")
if echo "$response" | grep -q "stockQuantity"; then
    stock=$(echo $response | sed 's/.*"stockQuantity":\([0-9]*\).*/\1/')
    echo -e "${GREEN}✅ PASS${NC} - iPhone stock is now: $stock (should be less than 50)"
else
    echo -e "${RED}❌ FAIL${NC} - Could not retrieve stock information"
fi
echo ""

echo ""
echo "📈 Test Summary"
echo "==============="
echo -e "${GREEN}✅ Authentication System: Tested${NC}"
echo -e "${GREEN}✅ Category Management: Tested${NC}"
echo -e "${GREEN}✅ Product Management: Tested${NC}"
echo -e "${GREEN}✅ Customer Management: Tested${NC}"
echo -e "${GREEN}✅ Sales Processing: Tested${NC}"
echo -e "${GREEN}✅ Inventory Updates: Tested${NC}"
echo -e "${GREEN}✅ Error Handling: Tested${NC}"
echo -e "${GREEN}✅ Data Validation: Tested${NC}"

echo ""
echo -e "${YELLOW}🎉 All automated tests completed!${NC}"
echo -e "${BLUE}💡 For detailed testing, use the complete-system-tests.http file in VS Code${NC}"
echo -e "${BLUE}📊 Check Swagger UI at http://localhost:5000/swagger for interactive testing${NC}"
