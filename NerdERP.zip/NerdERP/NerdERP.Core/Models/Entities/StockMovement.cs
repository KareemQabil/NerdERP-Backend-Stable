namespace NerdERP.Core.Models.Entities;

public class StockMovement
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string MovementType { get; set; } = string.Empty; // IN, OUT, ADJUSTMENT
    public int Quantity { get; set; }
    public string? Reason { get; set; }
    public string? Reference { get; set; } // Sale ID, Purchase ID, etc.
    public int UserId { get; set; }
    public DateTime MovementDate { get; set; } = DateTime.UtcNow;
    
    // Navigation properties
    public Product Product { get; set; } = null!;
    public User User { get; set; } = null!;
}
