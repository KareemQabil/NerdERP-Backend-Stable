namespace NerdERP.Core.Models.Entities;

public class Customer
{
    public int Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? PostalCode { get; set; }
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public decimal TotalPurchases { get; set; } = 0;
    public bool IsActive { get; set; } = true;
}
