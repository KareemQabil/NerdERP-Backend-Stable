namespace NerdERP.Core.Models.Entities;

public class PurchaseOrderItem
{
    public int Id { get; set; }
    public int PurchaseOrderId { get; set; }
    public int ProductId { get; set; }
    public decimal UnitCost { get; set; }
    public int QuantityOrdered { get; set; }
    public int QuantityReceived { get; set; } = 0;
    public decimal LineTotal { get; set; }
    
    // Navigation properties
    public PurchaseOrder PurchaseOrder { get; set; } = null!;
    public Product Product { get; set; } = null!;
}
