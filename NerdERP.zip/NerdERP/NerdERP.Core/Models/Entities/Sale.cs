namespace NerdERP.Core.Models.Entities;

public class Sale
{
    public int Id { get; set; }
    public string SaleNumber { get; set; } = string.Empty; // Auto-generated unique number
    public int? CustomerId { get; set; }
    public int UserId { get; set; } // Cashier who made the sale
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string PaymentMethod { get; set; } = string.Empty; // Cash, Card, Mobile
    public string Status { get; set; } = "Completed"; // Completed, Refunded, Cancelled
    public DateTime SaleDate { get; set; } = DateTime.UtcNow;
    public string? Notes { get; set; }
    
    // Table management fields for restaurant orders
    public int? TableId { get; set; }
    public string OrderType { get; set; } = "Takeaway"; // Takeaway, DineIn
    
    // Navigation properties
    public Customer? Customer { get; set; }
    public User User { get; set; } = null!;
    public Table? Table { get; set; }
    public ICollection<SaleItem> Items { get; set; } = new List<SaleItem>();
}
