using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using NerdERP.Core.Models.Schema.Tables;

namespace NerdERP.Core.Models.Entities;

[Table("Tables")]
public class Table
{
    [Key]
    public int Id { get; set; }

    [Required]
    [StringLength(20)]
    public string TableNumber { get; set; } = string.Empty;

    [StringLength(100)]
    public string? TableName { get; set; }

    [Required]
    [Range(1, 20)]
    public int Capacity { get; set; }

    [StringLength(50)]
    public string? Location { get; set; }

    [StringLength(500)]
    public string? Description { get; set; }

    public bool IsActive { get; set; } = true;

    public TableStatus Status { get; set; } = TableStatus.Available;

    public DateTime? CurrentOrderStartTime { get; set; }

    public int? CurrentSaleId { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    public DateTime? LastModifiedDate { get; set; }

    // Navigation properties
    [ForeignKey("CurrentSaleId")]
    public virtual Sale? CurrentSale { get; set; }

    public virtual ICollection<TableReservation> Reservations { get; set; } = new List<TableReservation>();
}

[Table("TableReservations")]
public class TableReservation
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int TableId { get; set; }

    public int? CustomerId { get; set; }

    [StringLength(100)]
    public string? CustomerName { get; set; }

    [StringLength(20)]
    public string? CustomerPhone { get; set; }

    public DateTime ReservationTime { get; set; }

    [Range(1, 20)]
    public int PartySize { get; set; }

    [StringLength(500)]
    public string? Notes { get; set; }

    public ReservationStatus Status { get; set; } = ReservationStatus.Pending;

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    public DateTime? LastModifiedDate { get; set; }

    // Navigation properties
    [ForeignKey("TableId")]
    public virtual Table Table { get; set; } = null!;

    [ForeignKey("CustomerId")]
    public virtual Customer? Customer { get; set; }
}