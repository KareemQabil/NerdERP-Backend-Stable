using System.ComponentModel.DataAnnotations;

namespace NerdERP.Core.Models.Schema.Products;

public class CreateProductRequest
{
    [Required(ErrorMessage = "Product name is required")]
    [StringLength(100, ErrorMessage = "Product name cannot exceed 100 characters")]
    public string Name { get; set; } = string.Empty;

    [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
    public string? Description { get; set; }

    [Required(ErrorMessage = "SKU is required")]
    [StringLength(50, ErrorMessage = "SKU cannot exceed 50 characters")]
    public string SKU { get; set; } = string.Empty;

    [Required(ErrorMessage = "Barcode is required")]
    [StringLength(50, ErrorMessage = "Barcode cannot exceed 50 characters")]
    public string Barcode { get; set; } = string.Empty;

    [Required(ErrorMessage = "Category ID is required")]
    [Range(1, int.MaxValue, ErrorMessage = "Category ID must be greater than 0")]
    public int CategoryId { get; set; }

    [Required(ErrorMessage = "Cost price is required")]
    [Range(0.01, double.MaxValue, ErrorMessage = "Cost price must be greater than 0")]
    public decimal CostPrice { get; set; }

    [Required(ErrorMessage = "Selling price is required")]
    [Range(0.01, double.MaxValue, ErrorMessage = "Selling price must be greater than 0")]
    public decimal SellingPrice { get; set; }

    [Required(ErrorMessage = "Current stock is required")]
    [Range(0, int.MaxValue, ErrorMessage = "Current stock cannot be negative")]
    public int CurrentStock { get; set; }

    [Required(ErrorMessage = "Minimum stock level is required")]
    [Range(0, int.MaxValue, ErrorMessage = "Minimum stock level cannot be negative")]
    public int MinStockLevel { get; set; }

    [Required(ErrorMessage = "Maximum stock level is required")]
    [Range(1, int.MaxValue, ErrorMessage = "Maximum stock level must be greater than 0")]
    public int MaxStockLevel { get; set; }

    [Required(ErrorMessage = "Unit is required")]
    [StringLength(20, ErrorMessage = "Unit cannot exceed 20 characters")]
    public string Unit { get; set; } = string.Empty;
}