namespace NerdERP.Core.Models.Schema.Products;

public class ProductFilterParams
{
    public string? Name { get; set; }
    public string? SKU { get; set; }
    public string? Barcode { get; set; }
    public int? CategoryId { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public bool? IsActive { get; set; }
    public bool? LowStock { get; set; }
    public DateTime? CreatedFrom { get; set; }
    public DateTime? CreatedTo { get; set; }
}