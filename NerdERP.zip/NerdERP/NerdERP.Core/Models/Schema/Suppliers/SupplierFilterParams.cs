namespace NerdERP.Core.Models.Schema.Suppliers;

public class SupplierFilterParams
{
    public string? SearchTerm { get; set; }
    public string? City { get; set; }
    public bool? IsActive { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
}