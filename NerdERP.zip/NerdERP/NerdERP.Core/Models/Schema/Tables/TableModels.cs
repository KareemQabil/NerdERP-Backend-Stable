using System.ComponentModel.DataAnnotations;

namespace NerdERP.Core.Models.Schema.Tables;

public class CreateTableRequest
{
    [Required(ErrorMessage = "Table number is required")]
    [StringLength(20, ErrorMessage = "Table number cannot exceed 20 characters")]
    public string TableNumber { get; set; } = string.Empty;

    [StringLength(100, ErrorMessage = "Table name cannot exceed 100 characters")]
    public string? TableName { get; set; }

    [Range(1, 20, ErrorMessage = "Capacity must be between 1 and 20")]
    public int Capacity { get; set; }

    [StringLength(50, ErrorMessage = "Location cannot exceed 50 characters")]
    public string? Location { get; set; } // e.g., "Main Floor", "Outdoor", "VIP Section"

    [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
    public string? Description { get; set; }

    public bool IsActive { get; set; } = true;
}

public class UpdateTableRequest
{
    [Required(ErrorMessage = "Table number is required")]
    [StringLength(20, ErrorMessage = "Table number cannot exceed 20 characters")]
    public string TableNumber { get; set; } = string.Empty;

    [StringLength(100, ErrorMessage = "Table name cannot exceed 100 characters")]
    public string? TableName { get; set; }

    [Range(1, 20, ErrorMessage = "Capacity must be between 1 and 20")]
    public int Capacity { get; set; }

    [StringLength(50, ErrorMessage = "Location cannot exceed 50 characters")]
    public string? Location { get; set; }

    [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
    public string? Description { get; set; }

    public bool IsActive { get; set; }
}

public class TableResponse
{
    public int Id { get; set; }
    public string TableNumber { get; set; } = string.Empty;
    public string? TableName { get; set; }
    public int Capacity { get; set; }
    public string? Location { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; }
    public TableStatus Status { get; set; }
    public DateTime? CurrentOrderStartTime { get; set; }
    public int? CurrentSaleId { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime? LastModifiedDate { get; set; }
}

public class TableFilterParams
{
    public string? TableNumber { get; set; }
    public string? Location { get; set; }
    public TableStatus? Status { get; set; }
    public bool? IsActive { get; set; }
    public int? MinCapacity { get; set; }
    public int? MaxCapacity { get; set; }
}

public class ReserveTableRequest
{
    [Required(ErrorMessage = "Customer information is required for reservation")]
    public int? CustomerId { get; set; }

    [StringLength(100, ErrorMessage = "Customer name cannot exceed 100 characters")]
    public string? CustomerName { get; set; }

    [StringLength(20, ErrorMessage = "Phone number cannot exceed 20 characters")]
    public string? CustomerPhone { get; set; }

    public DateTime? ReservationTime { get; set; }

    [Range(1, 20, ErrorMessage = "Party size must be between 1 and 20")]
    public int PartySize { get; set; }

    [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters")]
    public string? Notes { get; set; }
}

public class TableReservationResponse
{
    public int Id { get; set; }
    public int TableId { get; set; }
    public string TableNumber { get; set; } = string.Empty;
    public int? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    public string? CustomerPhone { get; set; }
    public DateTime ReservationTime { get; set; }
    public int PartySize { get; set; }
    public string? Notes { get; set; }
    public ReservationStatus Status { get; set; }
    public DateTime CreatedDate { get; set; }
}

public enum TableStatus
{
    Available = 0,
    Occupied = 1,
    Reserved = 2,
    OutOfService = 3,
    Cleaning = 4
}

public enum ReservationStatus
{
    Pending = 0,
    Confirmed = 1,
    Seated = 2,
    Completed = 3,
    Cancelled = 4,
    NoShow = 5
}