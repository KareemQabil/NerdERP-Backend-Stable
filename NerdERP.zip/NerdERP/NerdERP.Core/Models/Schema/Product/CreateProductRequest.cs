using System.ComponentModel.DataAnnotations;

namespace NerdERP.Core.Models.Schema.Product;

public class CreateProductRequest
{
    [Required]
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;
    
    [StringLength(500)]
    public string? Description { get; set; }
    
    [Required]
    [StringLength(50)]
    public string SKU { get; set; } = string.Empty;
    
    [Required]
    [StringLength(50)]
    public string Barcode { get; set; } = string.Empty;
    
    [Required]
    public int CategoryId { get; set; }
    
    [Required]
    [Range(0, double.MaxValue)]
    public decimal CostPrice { get; set; }
    
    [Required]
    [Range(0, double.MaxValue)]
    public decimal SellingPrice { get; set; }
    
    [Required]
    [Range(0, int.MaxValue)]
    public int CurrentStock { get; set; }
    
    [Required]
    [Range(0, int.MaxValue)]
    public int MinStockLevel { get; set; }
    
    [Required]
    [Range(0, int.MaxValue)]
    public int MaxStockLevel { get; set; }
    
    [Required]
    [StringLength(20)]
    public string Unit { get; set; } = string.Empty;
}
