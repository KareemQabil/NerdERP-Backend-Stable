using System.ComponentModel.DataAnnotations;

namespace NerdERP.Core.Models.Schema.User;

public class UserLoginRequest
{
    [Required]
    [StringLength(50)]
    public string Username { get; set; } = string.Empty;
    
    [Required]
    [StringLength(100)]
    public string Password { get; set; } = string.Empty;
}
