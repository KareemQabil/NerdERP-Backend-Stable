using System.ComponentModel.DataAnnotations;

namespace NerdERP.Core.Models.Schema.Sale;

public class CreateSaleRequest
{
    public int? CustomerId { get; set; }
    
    [Required]
    public List<SaleItemRequest> Items { get; set; } = new();
    
    [Required]
    [StringLength(50)]
    public string PaymentMethod { get; set; } = string.Empty;
    
    [Range(0, double.MaxValue)]
    public decimal DiscountAmount { get; set; } = 0;
    
    [Range(0, 100)]
    public decimal TaxRate { get; set; } = 0;
    
    public string? Notes { get; set; }
}

public class SaleItemRequest
{
    [Required]
    public int ProductId { get; set; }
    
    [Required]
    [Range(1, int.MaxValue)]
    public int Quantity { get; set; }
    
    [Range(0, double.MaxValue)]
    public decimal UnitPrice { get; set; }
    
    [Range(0, double.MaxValue)]
    public decimal DiscountAmount { get; set; } = 0;
}

public class SaleResponse
{
    public int Id { get; set; }
    public string SaleNumber { get; set; } = string.Empty;
    public int? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    public int UserId { get; set; }
    public string UserName { get; set; } = string.Empty;
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string PaymentMethod { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime SaleDate { get; set; }
    public string? Notes { get; set; }
    public List<SaleItemResponse> Items { get; set; } = new();
}

public class SaleItemResponse
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string ProductSKU { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal LineTotal { get; set; }
}
