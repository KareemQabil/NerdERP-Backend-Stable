using System.ComponentModel.DataAnnotations;

namespace NerdERP.Core.Models.Schema.PurchaseOrder;

public class CreatePurchaseOrderRequest
{
    [Required]
    public int SupplierId { get; set; }
    
    [StringLength(1000)]
    public string? Notes { get; set; }
    
    [Required]
    [MinLength(1, ErrorMessage = "At least one item is required")]
    public List<PurchaseOrderItemRequest> Items { get; set; } = new();
}

public class PurchaseOrderItemRequest
{
    [Required]
    public int ProductId { get; set; }
    
    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "Quantity must be greater than 0")]
    public int QuantityOrdered { get; set; }
    
    [Required]
    [Range(0.01, double.MaxValue, ErrorMessage = "Unit cost must be greater than 0")]
    public decimal UnitCost { get; set; }
}

public class ReceivePurchaseOrderRequest
{
    [Required]
    public int PurchaseOrderId { get; set; }
    
    [Required]
    [MinLength(1, ErrorMessage = "At least one item must be received")]
    public List<ReceiveItemRequest> Items { get; set; } = new();
    
    [StringLength(1000)]
    public string? Notes { get; set; }
}

public class ReceiveItemRequest
{
    [Required]
    public int PurchaseOrderItemId { get; set; }
    
    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "Quantity received must be greater than 0")]
    public int QuantityReceived { get; set; }
}

public class PurchaseOrderResponse
{
    public int Id { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public int SupplierId { get; set; }
    public string SupplierName { get; set; } = string.Empty;
    public int UserId { get; set; }
    public string UserName { get; set; } = string.Empty;
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime OrderDate { get; set; }
    public DateTime? ReceivedDate { get; set; }
    public string? Notes { get; set; }
    public List<PurchaseOrderItemResponse> Items { get; set; } = new();
}

public class PurchaseOrderItemResponse
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string ProductSKU { get; set; } = string.Empty;
    public decimal UnitCost { get; set; }
    public int QuantityOrdered { get; set; }
    public int QuantityReceived { get; set; }
    public decimal LineTotal { get; set; }
}
