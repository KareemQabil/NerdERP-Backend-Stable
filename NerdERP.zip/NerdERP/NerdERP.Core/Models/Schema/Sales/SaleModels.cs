using System.ComponentModel.DataAnnotations;

namespace NerdERP.Core.Models.Schema.Sales;

public class CreateSaleRequest
{
    public int? CustomerId { get; set; }

    [Required(ErrorMessage = "User ID is required")]
    public int UserId { get; set; }

    [Required(ErrorMessage = "Payment method is required")]
    [StringLength(50, ErrorMessage = "Payment method cannot exceed 50 characters")]
    public string PaymentMethod { get; set; } = string.Empty;

    [Range(0, double.MaxValue, ErrorMessage = "Discount amount must be non-negative")]
    public decimal DiscountAmount { get; set; } = 0;

    [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters")]
    public string? Notes { get; set; }

    // Table management for restaurant orders
    public int? TableId { get; set; }
    
    [Required(ErrorMessage = "Order type is required")]
    [StringLength(20, ErrorMessage = "Order type cannot exceed 20 characters")]
    public string OrderType { get; set; } = "Takeaway"; // Takeaway, DineIn

    [Required(ErrorMessage = "Sale items are required")]
    [MinLength(1, ErrorMessage = "At least one sale item is required")]
    public List<CreateSaleItemRequest> Items { get; set; } = new();
}

public class CreateSaleItemRequest
{
    [Required(ErrorMessage = "Product ID is required")]
    public int ProductId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1")]
    public int Quantity { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "Unit price must be non-negative")]
    public decimal UnitPrice { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "Discount amount must be non-negative")]
    public decimal DiscountAmount { get; set; } = 0;
}

public class UpdateSaleRequest
{
    public int? CustomerId { get; set; }

    [Required(ErrorMessage = "Status is required")]
    [StringLength(50, ErrorMessage = "Status cannot exceed 50 characters")]
    public string Status { get; set; } = string.Empty;

    [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters")]
    public string? Notes { get; set; }
}

public class SaleResponse
{
    public int Id { get; set; }
    public string SaleNumber { get; set; } = string.Empty;
    public int? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    public int UserId { get; set; }
    public string UserName { get; set; } = string.Empty;
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string PaymentMethod { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime SaleDate { get; set; }
    public string? Notes { get; set; }
    
    // Table information for restaurant orders
    public int? TableId { get; set; }
    public string? TableNumber { get; set; }
    public string OrderType { get; set; } = string.Empty;
    
    public List<SaleItemResponse> Items { get; set; } = new();
}

public class SaleItemResponse
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal LineTotal { get; set; }
}

public class SaleFilterParams
{
    public int? CustomerId { get; set; }
    public int? UserId { get; set; }
    public string? PaymentMethod { get; set; }
    public string? Status { get; set; }
    public DateTime? SaleDateFrom { get; set; }
    public DateTime? SaleDateTo { get; set; }
    public decimal? MinAmount { get; set; }
    public decimal? MaxAmount { get; set; }
}