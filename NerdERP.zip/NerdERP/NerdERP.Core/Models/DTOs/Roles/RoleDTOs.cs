using System.ComponentModel.DataAnnotations;

namespace NerdERP.Core.Models.DTOs.Roles
{
    public class CreateRoleRequest
    {
        [Required]
        [StringLength(50)]
        public string Name { get; set; } = string.Empty;

        [StringLength(255)]
        public string? Description { get; set; }

        public List<int> PermissionIds { get; set; } = new List<int>();
    }

    public class UpdateRoleRequest
    {
        [Required]
        [StringLength(50)]
        public string Name { get; set; } = string.Empty;

        [StringLength(255)]
        public string? Description { get; set; }

        public List<int> PermissionIds { get; set; } = new List<int>();
    }

    public class RoleResponse
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public bool IsActive { get; set; }
        public bool IsSystemRole { get; set; }
        public DateTime CreatedDate { get; set; }
        public List<PermissionResponse> Permissions { get; set; } = new List<PermissionResponse>();
    }

    public class PermissionResponse
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string Module { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public bool IsActive { get; set; }
    }

    public class ModulePermissionsResponse
    {
        public string Module { get; set; } = string.Empty;
        public List<PermissionResponse> Permissions { get; set; } = new List<PermissionResponse>();
    }

    public class AssignPermissionsRequest
    {
        [Required]
        public List<int> PermissionIds { get; set; } = new List<int>();
    }
}