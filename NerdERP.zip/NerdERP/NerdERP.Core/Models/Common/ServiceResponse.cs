using System.ComponentModel.DataAnnotations;

namespace NerdERP.Core.Models.Common;

public class ServiceResponse<T>
{
    public bool IsSuccess { get; set; }
    public string Message { get; set; } = string.Empty;
    public T? Data { get; set; }
    public int StatusCode { get; set; }
    public List<string> Errors { get; set; } = new();

    public static ServiceResponse<T> CreateSuccess(T data, string message = "Operation completed successfully.")
    {
        return new ServiceResponse<T>
        {
            IsSuccess = true,
            Message = message,
            Data = data,
            StatusCode = 200
        };
    }

    public static ServiceResponse<T> CreateFailure(string message, int statusCode = 400, List<string>? errors = null)
    {
        return new ServiceResponse<T>
        {
            IsSuccess = false,
            Message = message,
            StatusCode = statusCode,
            Errors = errors ?? new List<string>()
        };
    }
}

public class PagedResult<T>
{
    public List<T> Data { get; set; } = new();
    public int TotalRecords { get; set; }
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public int TotalPages => (int)Math.Ceiling((double)TotalRecords / PageSize);
    public bool HasPreviousPage => PageNumber > 1;
    public bool HasNextPage => PageNumber < TotalPages;
}

public class PagingAndSortingParams
{
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 10;
    public string? OrderBy { get; set; } = "Id";
    public string? SortDir { get; set; } = "ASC";
}