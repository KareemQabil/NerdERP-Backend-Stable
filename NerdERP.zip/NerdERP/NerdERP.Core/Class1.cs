﻿namespace NerdERP.Core;

public class Class1
{

}
