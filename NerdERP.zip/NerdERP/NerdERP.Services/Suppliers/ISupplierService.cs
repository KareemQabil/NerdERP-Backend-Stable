using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Suppliers;

namespace NerdERP.Services.Suppliers;

public interface ISupplierService
{
    // Standard ERP CRUD operations
    Task<ServiceResponse<SupplierResponse>> CreateAsync(CreateSupplierRequest request);
    Task<ServiceResponse<SupplierResponse>> UpdateAsync(UpdateSupplierRequest request);
    Task<ServiceResponse<bool>> DeleteAsync(int id);
    Task<ServiceResponse<SupplierResponse>> GetByIdAsync(int id);
    Task<ServiceResponse<PagedResult<SupplierResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        SupplierFilterParams filterParams);

    // Business operations
    Task<ServiceResponse<SupplierResponse>> GetByEmailAsync(string email);
    Task<bool> IsSupplierExistsAsync(int id);
    Task<bool> IsEmailExistsAsync(string email, int? excludeId = null);
}