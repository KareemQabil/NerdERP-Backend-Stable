using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Suppliers;
using NerdERP.Infrastructure.Data;

namespace NerdERP.Services.Suppliers;

public class SupplierService : ISupplierService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<SupplierService> _logger;

    public SupplierService(ApplicationDbContext context, ILogger<SupplierService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<ServiceResponse<SupplierResponse>> CreateAsync(CreateSupplierRequest request)
    {
        // Validation
        if (request == null)
            return ServiceResponse<SupplierResponse>.CreateFailure("Request cannot be null.", 400);
        if (string.IsNullOrWhiteSpace(request.Name))
            return ServiceResponse<SupplierResponse>.CreateFailure("Supplier name is required.", 400);
        if (!string.IsNullOrWhiteSpace(request.Email) && await IsEmailExistsAsync(request.Email))
            return ServiceResponse<SupplierResponse>.CreateFailure("Email already exists.", 409);

        var supplier = new Supplier
        {
            Name = request.Name.Trim(),
            ContactPerson = request.ContactPerson?.Trim(),
            Email = request.Email?.Trim(),
            Phone = request.Phone?.Trim(),
            Address = request.Address?.Trim(),
            City = request.City?.Trim(),
            PostalCode = request.PostalCode?.Trim(),
            CreatedDate = DateTime.UtcNow,
            IsActive = true
        };

        _context.Suppliers.Add(supplier);

        try
        {
            await _context.SaveChangesAsync();
            _logger.LogInformation("Supplier created with ID {SupplierId}", supplier.Id);
            return ServiceResponse<SupplierResponse>.CreateSuccess(MapToResponse(supplier));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating supplier");
            return ServiceResponse<SupplierResponse>.CreateFailure("An error occurred while creating the supplier.", 500);
        }
    }

    public async Task<ServiceResponse<SupplierResponse>> UpdateAsync(UpdateSupplierRequest request)
    {
        // Validation
        if (request == null)
            return ServiceResponse<SupplierResponse>.CreateFailure("Request cannot be null.", 400);
        if (string.IsNullOrWhiteSpace(request.Name))
            return ServiceResponse<SupplierResponse>.CreateFailure("Supplier name is required.", 400);
        if (!string.IsNullOrWhiteSpace(request.Email) && await IsEmailExistsAsync(request.Email, request.Id))
            return ServiceResponse<SupplierResponse>.CreateFailure("Email already exists.", 409);

        var supplier = await _context.Suppliers.FindAsync(request.Id);
        if (supplier == null)
            return ServiceResponse<SupplierResponse>.CreateFailure("Supplier not found.", 404);

        supplier.Name = request.Name.Trim();
        supplier.ContactPerson = request.ContactPerson?.Trim();
        supplier.Email = request.Email?.Trim();
        supplier.Phone = request.Phone?.Trim();
        supplier.Address = request.Address?.Trim();
        supplier.City = request.City?.Trim();
        supplier.PostalCode = request.PostalCode?.Trim();
        supplier.IsActive = request.IsActive;

        try
        {
            await _context.SaveChangesAsync();
            _logger.LogInformation("Supplier updated with ID {SupplierId}", supplier.Id);
            return ServiceResponse<SupplierResponse>.CreateSuccess(MapToResponse(supplier));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating supplier {SupplierId}", request.Id);
            return ServiceResponse<SupplierResponse>.CreateFailure("An error occurred while updating the supplier.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> DeleteAsync(int id)
    {
        var supplier = await _context.Suppliers.FindAsync(id);
        if (supplier == null)
            return ServiceResponse<bool>.CreateFailure("Supplier not found.", 404);

        supplier.IsActive = false;

        try
        {
            await _context.SaveChangesAsync();
            _logger.LogInformation("Supplier soft deleted with ID {SupplierId}", id);
            return ServiceResponse<bool>.CreateSuccess(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting supplier {SupplierId}", id);
            return ServiceResponse<bool>.CreateFailure("An error occurred while deleting the supplier.", 500);
        }
    }

    public async Task<ServiceResponse<SupplierResponse>> GetByIdAsync(int id)
    {
        var supplier = await _context.Suppliers
            .FirstOrDefaultAsync(s => s.Id == id && s.IsActive);

        if (supplier == null)
            return ServiceResponse<SupplierResponse>.CreateFailure("Supplier not found.", 404);

        return ServiceResponse<SupplierResponse>.CreateSuccess(MapToResponse(supplier));
    }

    public async Task<ServiceResponse<PagedResult<SupplierResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams,
        SupplierFilterParams filterParams)
    {
        try
        {
            _logger.LogInformation("Retrieving suppliers with paging. Page: {PageNumber}, Size: {PageSize}", 
                pagingParams.PageNumber, pagingParams.PageSize);

            var query = _context.Suppliers.Where(s => s.IsActive);

            // Apply filters
            if (filterParams != null)
            {
                if (!string.IsNullOrWhiteSpace(filterParams.SearchTerm))
                {
                    query = query.Where(s => s.Name.Contains(filterParams.SearchTerm) ||
                                           (s.ContactPerson != null && s.ContactPerson.Contains(filterParams.SearchTerm)));
                }
                if (!string.IsNullOrWhiteSpace(filterParams.Email))
                {
                    query = query.Where(s => s.Email != null && s.Email.Contains(filterParams.Email));
                }
                if (!string.IsNullOrWhiteSpace(filterParams.Phone))
                {
                    query = query.Where(s => s.Phone != null && s.Phone.Contains(filterParams.Phone));
                }
                if (!string.IsNullOrWhiteSpace(filterParams.City))
                {
                    query = query.Where(s => s.City != null && s.City.Contains(filterParams.City));
                }
                if (filterParams.IsActive.HasValue)
                {
                    query = query.Where(s => s.IsActive == filterParams.IsActive.Value);
                }
            }

            // Apply sorting
            query = pagingParams.OrderBy?.ToLower() switch
            {
                "name" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.Name)
                    : query.OrderBy(s => s.Name),
                "email" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.Email)
                    : query.OrderBy(s => s.Email),
                "city" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.City)
                    : query.OrderBy(s => s.City),
                "createddate" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.CreatedDate)
                    : query.OrderBy(s => s.CreatedDate),
                _ => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.Id)
                    : query.OrderBy(s => s.Id)
            };

            var totalRecords = await query.CountAsync();
            var suppliers = await query
                .Skip((pagingParams.PageNumber - 1) * pagingParams.PageSize)
                .Take(pagingParams.PageSize)
                .ToListAsync();

            var supplierResponses = suppliers.Select(MapToResponse).ToList();

            var pagedResult = new PagedResult<SupplierResponse>
            {
                Data = supplierResponses,
                TotalRecords = totalRecords,
                PageNumber = pagingParams.PageNumber,
                PageSize = pagingParams.PageSize
            };

            return ServiceResponse<PagedResult<SupplierResponse>>.CreateSuccess(pagedResult);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting suppliers with paging");
            return ServiceResponse<PagedResult<SupplierResponse>>.CreateFailure("An error occurred while retrieving suppliers.", 500);
        }
    }

    public async Task<ServiceResponse<SupplierResponse>> GetByEmailAsync(string email)
    {
        var supplier = await _context.Suppliers
            .FirstOrDefaultAsync(s => s.Email == email && s.IsActive);

        if (supplier == null)
            return ServiceResponse<SupplierResponse>.CreateFailure("Supplier not found.", 404);

        return ServiceResponse<SupplierResponse>.CreateSuccess(MapToResponse(supplier));
    }

    public async Task<bool> IsSupplierExistsAsync(int id)
    {
        return await _context.Suppliers.AnyAsync(s => s.Id == id && s.IsActive);
    }

    public async Task<bool> IsEmailExistsAsync(string email, int? excludeId = null)
    {
        if (string.IsNullOrWhiteSpace(email)) return false;
        
        var query = _context.Suppliers.Where(s => s.Email == email && s.IsActive);
        if (excludeId.HasValue)
            query = query.Where(s => s.Id != excludeId.Value);
        return await query.AnyAsync();
    }

    private SupplierResponse MapToResponse(Supplier supplier)
    {
        return new SupplierResponse
        {
            Id = supplier.Id,
            Name = supplier.Name,
            ContactPerson = supplier.ContactPerson,
            Email = supplier.Email,
            Phone = supplier.Phone,
            Address = supplier.Address,
            City = supplier.City,
            PostalCode = supplier.PostalCode,
            IsActive = supplier.IsActive,
            CreatedDate = supplier.CreatedDate
        };
    }
}