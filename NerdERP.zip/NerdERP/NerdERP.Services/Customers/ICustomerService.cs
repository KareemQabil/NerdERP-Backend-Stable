using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Customers;

namespace NerdERP.Services.Customers;

public interface ICustomerService
{
    Task<ServiceResponse<CustomerResponse>> CreateAsync(CreateCustomerRequest request);
    Task<ServiceResponse<CustomerResponse>> UpdateAsync(int id, UpdateCustomerRequest request);
    Task<ServiceResponse<bool>> DeleteAsync(int id);
    Task<ServiceResponse<CustomerResponse>> GetByIdAsync(int id);
    Task<ServiceResponse<PagedResult<CustomerResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        CustomerFilterParams filterParams);
    Task<ServiceResponse<CustomerResponse>> GetByEmailAsync(string email);
}