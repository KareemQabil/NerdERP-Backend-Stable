using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Schema.Customers;
using NerdERP.Infrastructure.Data;

namespace NerdERP.Services.Customers;

public class CustomerService : ICustomerService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<CustomerService> _logger;

    public CustomerService(ApplicationDbContext context, ILogger<CustomerService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<ServiceResponse<CustomerResponse>> CreateAsync(CreateCustomerRequest request)
    {
        try
        {
            _logger.LogInformation("Creating new customer: {FirstName} {LastName}", request.FirstName, request.LastName);

            // Validate if email already exists
            if (!string.IsNullOrEmpty(request.Email))
            {
                var existingCustomer = await _context.Customers
                    .FirstOrDefaultAsync(c => c.Email != null && c.Email.ToLower() == request.Email.ToLower() && c.IsActive);

                if (existingCustomer != null)
                {
                    _logger.LogWarning("Customer creation failed - email already exists: {Email}", request.Email);
                    return ServiceResponse<CustomerResponse>.CreateFailure(
                        "A customer with this email already exists.", 409);
                }
            }

            var customer = new Customer
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Phone = request.Phone,
                Address = request.Address,
                City = request.City,
                PostalCode = request.PostalCode,
                CreatedDate = DateTime.UtcNow,
                IsActive = true,
                TotalPurchases = 0
            };

            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Customer created successfully with ID: {CustomerId}", customer.Id);

            var response = MapToResponse(customer);
            return ServiceResponse<CustomerResponse>.CreateSuccess(response, "Customer created successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating customer: {FirstName} {LastName}", request.FirstName, request.LastName);
            return ServiceResponse<CustomerResponse>.CreateFailure(
                "An error occurred while creating the customer.", 500);
        }
    }

    public async Task<ServiceResponse<CustomerResponse>> UpdateAsync(int id, UpdateCustomerRequest request)
    {
        try
        {
            _logger.LogInformation("Updating customer with ID: {CustomerId}", id);

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                _logger.LogWarning("Customer not found for update. ID: {CustomerId}", id);
                return ServiceResponse<CustomerResponse>.CreateFailure(
                    "Customer not found.", 404);
            }

            // Validate if new email already exists (excluding current customer)
            if (!string.IsNullOrEmpty(request.Email))
            {
                var existingCustomer = await _context.Customers
                    .FirstOrDefaultAsync(c => c.Email != null && c.Email.ToLower() == request.Email.ToLower() && c.Id != id && c.IsActive);

                if (existingCustomer != null)
                {
                    _logger.LogWarning("Customer update failed - email already exists: {Email}", request.Email);
                    return ServiceResponse<CustomerResponse>.CreateFailure(
                        "A customer with this email already exists.", 409);
                }
            }

            customer.FirstName = request.FirstName;
            customer.LastName = request.LastName;
            customer.Email = request.Email;
            customer.Phone = request.Phone;
            customer.Address = request.Address;
            customer.City = request.City;
            customer.PostalCode = request.PostalCode;
            customer.IsActive = request.IsActive;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Customer updated successfully. ID: {CustomerId}", id);

            var response = MapToResponse(customer);
            return ServiceResponse<CustomerResponse>.CreateSuccess(response, "Customer updated successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating customer with ID: {CustomerId}", id);
            return ServiceResponse<CustomerResponse>.CreateFailure(
                "An error occurred while updating the customer.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> DeleteAsync(int id)
    {
        try
        {
            _logger.LogInformation("Deleting customer with ID: {CustomerId}", id);

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                _logger.LogWarning("Customer not found for deletion. ID: {CustomerId}", id);
                return ServiceResponse<bool>.CreateFailure(
                    "Customer not found.", 404);
            }

            // Check if customer has any sales
            var hasSales = await _context.Sales
                .AnyAsync(s => s.CustomerId == id);

            if (hasSales)
            {
                _logger.LogWarning("Customer deletion failed - customer has sales. ID: {CustomerId}", id);
                return ServiceResponse<bool>.CreateFailure(
                    "Cannot delete customer as they have sales records.", 409);
            }

            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Customer deleted successfully. ID: {CustomerId}", id);

            return ServiceResponse<bool>.CreateSuccess(true, "Customer deleted successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting customer with ID: {CustomerId}", id);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while deleting the customer.", 500);
        }
    }

    public async Task<ServiceResponse<CustomerResponse>> GetByIdAsync(int id)
    {
        try
        {
            _logger.LogInformation("Retrieving customer with ID: {CustomerId}", id);

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                _logger.LogWarning("Customer not found. ID: {CustomerId}", id);
                return ServiceResponse<CustomerResponse>.CreateFailure(
                    "Customer not found.", 404);
            }

            var response = MapToResponse(customer);
            return ServiceResponse<CustomerResponse>.CreateSuccess(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving customer with ID: {CustomerId}", id);
            return ServiceResponse<CustomerResponse>.CreateFailure(
                "An error occurred while retrieving the customer.", 500);
        }
    }

    public async Task<ServiceResponse<PagedResult<CustomerResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        CustomerFilterParams filterParams)
    {
        try
        {
            _logger.LogInformation("Retrieving customers with paging. Page: {PageNumber}, Size: {PageSize}", 
                pagingParams.PageNumber, pagingParams.PageSize);

            var query = _context.Customers.AsQueryable();

            // Apply filters
            if (!string.IsNullOrEmpty(filterParams.Name))
            {
                query = query.Where(c => 
                    (c.FirstName + " " + c.LastName).ToLower().Contains(filterParams.Name.ToLower()) ||
                    c.FirstName.ToLower().Contains(filterParams.Name.ToLower()) ||
                    c.LastName.ToLower().Contains(filterParams.Name.ToLower()));
            }

            if (!string.IsNullOrEmpty(filterParams.Email))
            {
                query = query.Where(c => c.Email != null && c.Email.ToLower().Contains(filterParams.Email.ToLower()));
            }

            if (!string.IsNullOrEmpty(filterParams.Phone))
            {
                query = query.Where(c => c.Phone != null && c.Phone.Contains(filterParams.Phone));
            }

            if (!string.IsNullOrEmpty(filterParams.City))
            {
                query = query.Where(c => c.City != null && c.City.ToLower().Contains(filterParams.City.ToLower()));
            }

            if (filterParams.IsActive.HasValue)
            {
                query = query.Where(c => c.IsActive == filterParams.IsActive.Value);
            }

            if (filterParams.CreatedFrom.HasValue)
            {
                query = query.Where(c => c.CreatedDate >= filterParams.CreatedFrom.Value);
            }

            if (filterParams.CreatedTo.HasValue)
            {
                query = query.Where(c => c.CreatedDate <= filterParams.CreatedTo.Value);
            }

            if (filterParams.MinPurchases.HasValue)
            {
                query = query.Where(c => c.TotalPurchases >= filterParams.MinPurchases.Value);
            }

            if (filterParams.MaxPurchases.HasValue)
            {
                query = query.Where(c => c.TotalPurchases <= filterParams.MaxPurchases.Value);
            }

            // Apply sorting
            query = pagingParams.OrderBy?.ToLower() switch
            {
                "firstname" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.FirstName)
                    : query.OrderBy(c => c.FirstName),
                "lastname" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.LastName)
                    : query.OrderBy(c => c.LastName),
                "email" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.Email)
                    : query.OrderBy(c => c.Email),
                "createddate" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.CreatedDate)
                    : query.OrderBy(c => c.CreatedDate),
                "totalpurchases" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.TotalPurchases)
                    : query.OrderBy(c => c.TotalPurchases),
                _ => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.Id)
                    : query.OrderBy(c => c.Id)
            };

            var totalRecords = await query.CountAsync();

            var customers = await query
                .Skip((pagingParams.PageNumber - 1) * pagingParams.PageSize)
                .Take(pagingParams.PageSize)
                .ToListAsync();

            var customerResponses = customers.Select(MapToResponse).ToList();

            var pagedResult = new PagedResult<CustomerResponse>
            {
                Data = customerResponses,
                TotalRecords = totalRecords,
                PageNumber = pagingParams.PageNumber,
                PageSize = pagingParams.PageSize
            };

            return ServiceResponse<PagedResult<CustomerResponse>>.CreateSuccess(pagedResult);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving customers with paging");
            return ServiceResponse<PagedResult<CustomerResponse>>.CreateFailure(
                "An error occurred while retrieving customers.", 500);
        }
    }

    public async Task<ServiceResponse<CustomerResponse>> GetByEmailAsync(string email)
    {
        try
        {
            _logger.LogInformation("Retrieving customer by email: {Email}", email);

            var customer = await _context.Customers
                .FirstOrDefaultAsync(c => c.Email == email && c.IsActive);

            if (customer == null)
            {
                _logger.LogWarning("Customer not found with email: {Email}", email);
                return ServiceResponse<CustomerResponse>.CreateFailure(
                    "Customer not found.", 404);
            }

            var response = MapToResponse(customer);
            return ServiceResponse<CustomerResponse>.CreateSuccess(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving customer by email: {Email}", email);
            return ServiceResponse<CustomerResponse>.CreateFailure(
                "An error occurred while retrieving the customer.", 500);
        }
    }

    private static CustomerResponse MapToResponse(Customer customer)
    {
        return new CustomerResponse
        {
            Id = customer.Id,
            FirstName = customer.FirstName,
            LastName = customer.LastName,
            Email = customer.Email,
            Phone = customer.Phone,
            Address = customer.Address,
            City = customer.City,
            PostalCode = customer.PostalCode,
            CreatedDate = customer.CreatedDate,
            TotalPurchases = customer.TotalPurchases,
            IsActive = customer.IsActive
        };
    }
}