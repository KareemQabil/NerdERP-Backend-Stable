﻿namespace NerdERP.Services;

public class Class1
{

}
