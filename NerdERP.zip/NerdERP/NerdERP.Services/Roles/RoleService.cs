using Microsoft.EntityFrameworkCore;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.DTOs.Roles;
using NerdERP.Core.Models.Entities;
using NerdERP.Infrastructure.Data;

namespace NerdERP.Services.Roles
{
    public class RoleService : IRoleService
    {
        private readonly ApplicationDbContext _context;

        public RoleService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<ServiceResponse<RoleResponse>> CreateAsync(CreateRoleRequest request)
        {
            try
            {
                // Check if role name already exists
                var existingRole = await _context.Roles
                    .FirstOrDefaultAsync(r => r.Name.ToLower() == request.Name.ToLower());

                if (existingRole != null)
                {
                    return ServiceResponse<RoleResponse>.CreateFailure(
                        $"Role with name '{request.Name}' already exists.", 400);
                }

                var role = new Role
                {
                    Name = request.Name,
                    Description = request.Description,
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                };

                _context.Roles.Add(role);
                await _context.SaveChangesAsync();

                var response = MapToRoleResponse(role);
                return ServiceResponse<RoleResponse>.CreateSuccess(response, "Role created successfully.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<RoleResponse>.CreateFailure(
                    $"Error creating role: {ex.Message}", 500);
            }
        }

        public async Task<ServiceResponse<RoleResponse>> UpdateAsync(int id, UpdateRoleRequest request)
        {
            try
            {
                var role = await _context.Roles.FindAsync(id);
                if (role == null)
                {
                    return ServiceResponse<RoleResponse>.CreateFailure(
                        $"Role with ID {id} not found.", 404);
                }

                // Check if new name conflicts with existing roles (excluding current)
                if (!string.IsNullOrWhiteSpace(request.Name) && 
                    request.Name.ToLower() != role.Name.ToLower())
                {
                    var nameExists = await _context.Roles
                        .AnyAsync(r => r.Id != id && r.Name.ToLower() == request.Name.ToLower());

                    if (nameExists)
                    {
                        return ServiceResponse<RoleResponse>.CreateFailure(
                            $"Role with name '{request.Name}' already exists.", 400);
                    }
                }

                // Update role properties
                if (!string.IsNullOrWhiteSpace(request.Name))
                    role.Name = request.Name;
                
                if (!string.IsNullOrWhiteSpace(request.Description))
                    role.Description = request.Description;

                await _context.SaveChangesAsync();

                var response = MapToRoleResponse(role);
                return ServiceResponse<RoleResponse>.CreateSuccess(response, "Role updated successfully.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<RoleResponse>.CreateFailure(
                    $"Error updating role: {ex.Message}", 500);
            }
        }

        public async Task<ServiceResponse<bool>> DeleteAsync(int id)
        {
            try
            {
                var role = await _context.Roles.FindAsync(id);
                if (role == null)
                {
                    return ServiceResponse<bool>.CreateFailure(
                        $"Role with ID {id} not found.", 404);
                }

                // Check if role is assigned to any users
                var usersWithRole = await _context.Users
                    .AnyAsync(u => u.RoleId == id);

                if (usersWithRole)
                {
                    return ServiceResponse<bool>.CreateFailure(
                        "Cannot delete role that is assigned to users. Please reassign users first.", 400);
                }

                // Remove role permissions first
                var rolePermissions = await _context.RolePermissions
                    .Where(rp => rp.RoleId == id)
                    .ToListAsync();

                _context.RolePermissions.RemoveRange(rolePermissions);
                _context.Roles.Remove(role);
                
                await _context.SaveChangesAsync();

                return ServiceResponse<bool>.CreateSuccess(true, "Role deleted successfully.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<bool>.CreateFailure(
                    $"Error deleting role: {ex.Message}", 500);
            }
        }

        public async Task<ServiceResponse<RoleResponse>> GetByIdAsync(int id)
        {
            try
            {
                var role = await _context.Roles
                    .Include(r => r.RolePermissions)
                        .ThenInclude(rp => rp.Permission)
                    .FirstOrDefaultAsync(r => r.Id == id);

                if (role == null)
                {
                    return ServiceResponse<RoleResponse>.CreateFailure(
                        $"Role with ID {id} not found.", 404);
                }

                var response = MapToRoleResponse(role);
                return ServiceResponse<RoleResponse>.CreateSuccess(response);
            }
            catch (Exception ex)
            {
                return ServiceResponse<RoleResponse>.CreateFailure(
                    $"Error retrieving role: {ex.Message}", 500);
            }
        }

        public async Task<ServiceResponse<PagedResult<RoleResponse>>> GetAllWithPagingAsync(
            PagingAndSortingParams pagingParams, string? searchTerm = null)
        {
            try
            {
                var query = _context.Roles.AsQueryable();

                // Apply search filter
                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    query = query.Where(r => r.Name.Contains(searchTerm) || 
                                           r.Description!.Contains(searchTerm));
                }

                // Apply sorting
                query = pagingParams.SortDir?.ToLower() == "desc"
                    ? query.OrderByDescending(GetSortExpression(pagingParams.OrderBy))
                    : query.OrderBy(GetSortExpression(pagingParams.OrderBy));

                var totalRecords = await query.CountAsync();

                var roles = await query
                    .Skip((pagingParams.PageNumber - 1) * pagingParams.PageSize)
                    .Take(pagingParams.PageSize)
                    .Include(r => r.RolePermissions)
                        .ThenInclude(rp => rp.Permission)
                    .ToListAsync();

                var roleResponses = roles.Select(MapToRoleResponse).ToList();

                var pagedResult = new PagedResult<RoleResponse>
                {
                    Data = roleResponses,
                    TotalRecords = totalRecords,
                    PageNumber = pagingParams.PageNumber,
                    PageSize = pagingParams.PageSize
                };

                return ServiceResponse<PagedResult<RoleResponse>>.CreateSuccess(pagedResult);
            }
            catch (Exception ex)
            {
                return ServiceResponse<PagedResult<RoleResponse>>.CreateFailure(
                    $"Error retrieving roles: {ex.Message}", 500);
            }
        }

        public async Task<ServiceResponse<List<ModulePermissionsResponse>>> GetAllPermissionsByModuleAsync()
        {
            try
            {
                var permissions = await _context.Permissions
                    .Where(p => p.IsActive)
                    .OrderBy(p => p.Module)
                    .ThenBy(p => p.Action)
                    .ToListAsync();

                var groupedPermissions = permissions
                    .GroupBy(p => p.Module)
                    .Select(g => new ModulePermissionsResponse
                    {
                        Module = g.Key,
                        Permissions = g.Select(p => new PermissionResponse
                        {
                            Id = p.Id,
                            Module = p.Module,
                            Action = p.Action,
                            Description = p.Description,
                            IsActive = p.IsActive
                        }).ToList()
                    })
                    .ToList();

                return ServiceResponse<List<ModulePermissionsResponse>>.CreateSuccess(groupedPermissions);
            }
            catch (Exception ex)
            {
                return ServiceResponse<List<ModulePermissionsResponse>>.CreateFailure(
                    $"Error retrieving permissions: {ex.Message}", 500);
            }
        }

        public async Task<ServiceResponse<List<PermissionResponse>>> GetRolePermissionsAsync(int roleId)
        {
            try
            {
                var role = await _context.Roles.FindAsync(roleId);
                if (role == null)
                {
                    return ServiceResponse<List<PermissionResponse>>.CreateFailure(
                        $"Role with ID {roleId} not found.", 404);
                }

                var permissions = await _context.RolePermissions
                    .Where(rp => rp.RoleId == roleId)
                    .Include(rp => rp.Permission)
                    .Select(rp => new PermissionResponse
                    {
                        Id = rp.Permission.Id,
                        Module = rp.Permission.Module,
                        Action = rp.Permission.Action,
                        Description = rp.Permission.Description,
                        IsActive = rp.Permission.IsActive
                    })
                    .ToListAsync();

                return ServiceResponse<List<PermissionResponse>>.CreateSuccess(permissions);
            }
            catch (Exception ex)
            {
                return ServiceResponse<List<PermissionResponse>>.CreateFailure(
                    $"Error retrieving role permissions: {ex.Message}", 500);
            }
        }

        public async Task<ServiceResponse<bool>> AssignPermissionsAsync(int roleId, List<int> permissionIds)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            
            try
            {
                var role = await _context.Roles.FindAsync(roleId);
                if (role == null)
                {
                    return ServiceResponse<bool>.CreateFailure(
                        $"Role with ID {roleId} not found.", 404);
                }

                // Validate all permission IDs exist
                var existingPermissions = await _context.Permissions
                    .Where(p => permissionIds.Contains(p.Id))
                    .Select(p => p.Id)
                    .ToListAsync();

                var invalidPermissions = permissionIds.Except(existingPermissions).ToList();
                if (invalidPermissions.Any())
                {
                    return ServiceResponse<bool>.CreateFailure(
                        $"Invalid permission IDs: {string.Join(", ", invalidPermissions)}", 400);
                }

                // Remove existing role permissions
                var existingRolePermissions = await _context.RolePermissions
                    .Where(rp => rp.RoleId == roleId)
                    .ToListAsync();

                _context.RolePermissions.RemoveRange(existingRolePermissions);

                // Add new role permissions
                var newRolePermissions = permissionIds.Select(permissionId => new RolePermission
                {
                    RoleId = roleId,
                    PermissionId = permissionId,
                    CreatedDate = DateTime.UtcNow
                }).ToList();

                await _context.RolePermissions.AddRangeAsync(newRolePermissions);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                return ServiceResponse<bool>.CreateSuccess(true, "Permissions assigned successfully.");
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return ServiceResponse<bool>.CreateFailure(
                    $"Error assigning permissions: {ex.Message}", 500);
            }
        }

        public async Task<ServiceResponse<bool>> HasPermissionAsync(int userId, string module, string action)
        {
            try
            {
                var user = await _context.Users
                    .Include(u => u.UserRole)
                        .ThenInclude(r => r!.RolePermissions)
                        .ThenInclude(rp => rp.Permission)
                    .FirstOrDefaultAsync(u => u.Id == userId);

                if (user?.UserRole == null)
                {
                    return ServiceResponse<bool>.CreateSuccess(false);
                }

                var hasPermission = user.UserRole.RolePermissions
                    .Any(rp => rp.Permission.Module.Equals(module, StringComparison.OrdinalIgnoreCase) &&
                              rp.Permission.Action.Equals(action, StringComparison.OrdinalIgnoreCase) &&
                              rp.Permission.IsActive);

                return ServiceResponse<bool>.CreateSuccess(hasPermission);
            }
            catch (Exception ex)
            {
                return ServiceResponse<bool>.CreateFailure(
                    $"Error checking permission: {ex.Message}", 500);
            }
        }

        private static RoleResponse MapToRoleResponse(Role role)
        {
            return new RoleResponse
            {
                Id = role.Id,
                Name = role.Name,
                Description = role.Description,
                IsActive = role.IsActive,
                IsSystemRole = role.IsSystemRole,
                CreatedDate = role.CreatedDate,
                Permissions = role.RolePermissions?.Select(rp => new PermissionResponse
                {
                    Id = rp.Permission.Id,
                    Module = rp.Permission.Module,
                    Action = rp.Permission.Action,
                    Description = rp.Permission.Description,
                    IsActive = rp.Permission.IsActive
                }).ToList() ?? new List<PermissionResponse>()
            };
        }

        private static System.Linq.Expressions.Expression<Func<Role, object>> GetSortExpression(string? sortBy)
        {
            return sortBy?.ToLower() switch
            {
                "name" => r => r.Name,
                "description" => r => r.Description ?? "",
                "isactive" => r => r.IsActive,
                "createddate" => r => r.CreatedDate,
                _ => r => r.Id
            };
        }
    }
}