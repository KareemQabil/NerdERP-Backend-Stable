using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.DTOs.Roles;

namespace NerdERP.Services.Roles
{
    public interface IRoleService
    {
        Task<ServiceResponse<RoleResponse>> CreateAsync(CreateRoleRequest request);
        Task<ServiceResponse<RoleResponse>> UpdateAsync(int id, UpdateRoleRequest request);
        Task<ServiceResponse<bool>> DeleteAsync(int id);
        Task<ServiceResponse<RoleResponse>> GetByIdAsync(int id);
        Task<ServiceResponse<PagedResult<RoleResponse>>> GetAllWithPagingAsync(
            PagingAndSortingParams pagingParams, string? searchTerm = null);
        Task<ServiceResponse<List<ModulePermissionsResponse>>> GetAllPermissionsByModuleAsync();
        Task<ServiceResponse<List<PermissionResponse>>> GetRolePermissionsAsync(int roleId);
        Task<ServiceResponse<bool>> AssignPermissionsAsync(int roleId, List<int> permissionIds);
        Task<ServiceResponse<bool>> HasPermissionAsync(int userId, string module, string action);
    }
}