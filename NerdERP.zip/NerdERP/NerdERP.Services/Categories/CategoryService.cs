using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Schema.Categories;
using NerdERP.Infrastructure.Data;

namespace NerdERP.Services.Categories;

public class CategoryService : ICategoryService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<CategoryService> _logger;

    public CategoryService(ApplicationDbContext context, ILogger<CategoryService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<ServiceResponse<CategoryResponse>> CreateAsync(CreateCategoryRequest request)
    {
        try
        {
            _logger.LogInformation("Creating new category with name: {Name}", request.Name);

            // Validate if category name already exists
            var existingCategory = await _context.Categories
                .FirstOrDefaultAsync(c => c.Name.ToLower() == request.Name.ToLower());

            if (existingCategory != null)
            {
                _logger.LogWarning("Category creation failed - name already exists: {Name}", request.Name);
                return ServiceResponse<CategoryResponse>.CreateFailure(
                    "A category with this name already exists.", 
                    409);
            }

            var category = new Category
            {
                Name = request.Name,
                Description = request.Description,
                IsActive = true,
                CreatedDate = DateTime.UtcNow
            };

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Category created successfully with ID: {CategoryId}", category.Id);

            var response = MapToResponse(category);
            return ServiceResponse<CategoryResponse>.CreateSuccess(response, "Category created successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating category with name: {Name}", request.Name);
            return ServiceResponse<CategoryResponse>.CreateFailure(
                "An error occurred while creating the category.", 
                500);
        }
    }

    public async Task<ServiceResponse<CategoryResponse>> UpdateAsync(int id, UpdateCategoryRequest request)
    {
        try
        {
            _logger.LogInformation("Updating category with ID: {CategoryId}", id);

            var category = await _context.Categories.FindAsync(id);
            if (category == null)
            {
                _logger.LogWarning("Category not found for update. ID: {CategoryId}", id);
                return ServiceResponse<CategoryResponse>.CreateFailure(
                    "Category not found.", 
                    404);
            }

            // Validate if new name already exists (excluding current category)
            var existingCategory = await _context.Categories
                .FirstOrDefaultAsync(c => c.Name.ToLower() == request.Name.ToLower() && c.Id != id);

            if (existingCategory != null)
            {
                _logger.LogWarning("Category update failed - name already exists: {Name}", request.Name);
                return ServiceResponse<CategoryResponse>.CreateFailure(
                    "A category with this name already exists.", 
                    409);
            }

            category.Name = request.Name;
            category.Description = request.Description;
            category.IsActive = request.IsActive;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Category updated successfully. ID: {CategoryId}", id);

            var response = MapToResponse(category);
            return ServiceResponse<CategoryResponse>.CreateSuccess(response, "Category updated successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating category with ID: {CategoryId}", id);
            return ServiceResponse<CategoryResponse>.CreateFailure(
                "An error occurred while updating the category.", 
                500);
        }
    }

    public async Task<ServiceResponse<bool>> DeleteAsync(int id)
    {
        try
        {
            _logger.LogInformation("Deleting category with ID: {CategoryId}", id);

            var category = await _context.Categories.FindAsync(id);
            if (category == null)
            {
                _logger.LogWarning("Category not found for deletion. ID: {CategoryId}", id);
                return ServiceResponse<bool>.CreateFailure(
                    "Category not found.", 
                    404);
            }

            // Check if category is being used by any products
            var productsUsingCategory = await _context.Products
                .AnyAsync(p => p.CategoryId == id);

            if (productsUsingCategory)
            {
                _logger.LogWarning("Category deletion failed - category is being used by products. ID: {CategoryId}", id);
                return ServiceResponse<bool>.CreateFailure(
                    "Cannot delete category as it is being used by one or more products.", 
                    409);
            }

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Category deleted successfully. ID: {CategoryId}", id);

            return ServiceResponse<bool>.CreateSuccess(true, "Category deleted successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting category with ID: {CategoryId}", id);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while deleting the category.", 
                500);
        }
    }

    public async Task<ServiceResponse<CategoryResponse>> GetByIdAsync(int id)
    {
        try
        {
            _logger.LogInformation("Retrieving category with ID: {CategoryId}", id);

            var category = await _context.Categories.FindAsync(id);
            if (category == null)
            {
                _logger.LogWarning("Category not found. ID: {CategoryId}", id);
                return ServiceResponse<CategoryResponse>.CreateFailure(
                    "Category not found.", 
                    404);
            }

            var response = MapToResponse(category);
            return ServiceResponse<CategoryResponse>.CreateSuccess(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving category with ID: {CategoryId}", id);
            return ServiceResponse<CategoryResponse>.CreateFailure(
                "An error occurred while retrieving the category.", 
                500);
        }
    }

    public async Task<ServiceResponse<PagedResult<CategoryResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        CategoryFilterParams filterParams)
    {
        try
        {
            _logger.LogInformation("Retrieving categories with paging. Page: {PageNumber}, Size: {PageSize}", 
                pagingParams.PageNumber, pagingParams.PageSize);

            var query = _context.Categories.AsQueryable();

            // Apply filters
            if (!string.IsNullOrEmpty(filterParams.Name))
            {
                query = query.Where(c => c.Name.ToLower().Contains(filterParams.Name.ToLower()));
            }

            if (filterParams.IsActive.HasValue)
            {
                query = query.Where(c => c.IsActive == filterParams.IsActive.Value);
            }

            if (filterParams.CreatedFrom.HasValue)
            {
                query = query.Where(c => c.CreatedDate >= filterParams.CreatedFrom.Value);
            }

            if (filterParams.CreatedTo.HasValue)
            {
                query = query.Where(c => c.CreatedDate <= filterParams.CreatedTo.Value);
            }

            // Apply sorting
            query = pagingParams.OrderBy?.ToLower() switch
            {
                "name" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.Name)
                    : query.OrderBy(c => c.Name),
                "createdate" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.CreatedDate)
                    : query.OrderBy(c => c.CreatedDate),
                "isactive" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.IsActive)
                    : query.OrderBy(c => c.IsActive),
                _ => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(c => c.Id)
                    : query.OrderBy(c => c.Id)
            };

            var totalRecords = await query.CountAsync();

            var categories = await query
                .Skip((pagingParams.PageNumber - 1) * pagingParams.PageSize)
                .Take(pagingParams.PageSize)
                .ToListAsync();

            var categoryResponses = categories.Select(MapToResponse).ToList();

            var pagedResult = new PagedResult<CategoryResponse>
            {
                Data = categoryResponses,
                TotalRecords = totalRecords,
                PageNumber = pagingParams.PageNumber,
                PageSize = pagingParams.PageSize
            };

            return ServiceResponse<PagedResult<CategoryResponse>>.CreateSuccess(pagedResult);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving categories with paging");
            return ServiceResponse<PagedResult<CategoryResponse>>.CreateFailure(
                "An error occurred while retrieving categories.", 
                500);
        }
    }

    private static CategoryResponse MapToResponse(Category category)
    {
        return new CategoryResponse
        {
            Id = category.Id,
            Name = category.Name,
            Description = category.Description,
            IsActive = category.IsActive,
            CreatedDate = category.CreatedDate
        };
    }
}