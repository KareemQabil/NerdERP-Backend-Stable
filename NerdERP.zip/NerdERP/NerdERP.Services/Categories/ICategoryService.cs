using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Categories;

namespace NerdERP.Services.Categories;

public interface ICategoryService
{
    Task<ServiceResponse<CategoryResponse>> CreateAsync(CreateCategoryRequest request);
    Task<ServiceResponse<CategoryResponse>> UpdateAsync(int id, UpdateCategoryRequest request);
    Task<ServiceResponse<bool>> DeleteAsync(int id);
    Task<ServiceResponse<CategoryResponse>> GetByIdAsync(int id);
    Task<ServiceResponse<PagedResult<CategoryResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        CategoryFilterParams filterParams);
}