using NerdERP.Core.Models.Entities;

namespace NerdERP.Services.PurchaseOrders;

public interface IPurchaseOrderService
{
    Task<IEnumerable<PurchaseOrder>> GetAllPurchaseOrdersAsync();
    Task<PurchaseOrder?> GetPurchaseOrderByIdAsync(int id);
    Task<PurchaseOrder> CreatePurchaseOrderAsync(PurchaseOrder purchaseOrder);
    Task<PurchaseOrder?> UpdatePurchaseOrderAsync(int id, PurchaseOrder purchaseOrder);
    Task<bool> DeletePurchaseOrderAsync(int id);
    Task<IEnumerable<PurchaseOrder>> GetPurchaseOrdersBySupplierAsync(int supplierId);
    Task<IEnumerable<PurchaseOrder>> GetPurchaseOrdersByStatusAsync(string status);
    Task<bool> UpdatePurchaseOrderStatusAsync(int id, string status);
}