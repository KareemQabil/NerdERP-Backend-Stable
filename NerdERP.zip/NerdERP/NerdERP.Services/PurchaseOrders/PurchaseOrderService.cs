using Microsoft.EntityFrameworkCore;
using NerdERP.Core.Models.Entities;
using NerdERP.Infrastructure.Data;

namespace NerdERP.Services.PurchaseOrders;

public class PurchaseOrderService : IPurchaseOrderService
{
    private readonly ApplicationDbContext _context;

    public PurchaseOrderService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<PurchaseOrder>> GetAllPurchaseOrdersAsync()
    {
        return await _context.PurchaseOrders
            .Include(po => po.Supplier)
            .Include(po => po.Items)
                .ThenInclude(poi => poi.Product)
            .ToListAsync();
    }

    public async Task<PurchaseOrder?> GetPurchaseOrderByIdAsync(int id)
    {
        return await _context.PurchaseOrders
            .Include(po => po.Supplier)
            .Include(po => po.Items)
                .ThenInclude(poi => poi.Product)
            .FirstOrDefaultAsync(po => po.Id == id);
    }

    public async Task<PurchaseOrder> CreatePurchaseOrderAsync(PurchaseOrder purchaseOrder)
    {
        _context.PurchaseOrders.Add(purchaseOrder);
        await _context.SaveChangesAsync();
        return purchaseOrder;
    }

    public async Task<PurchaseOrder?> UpdatePurchaseOrderAsync(int id, PurchaseOrder purchaseOrder)
    {
        var existingPurchaseOrder = await _context.PurchaseOrders.FindAsync(id);
        if (existingPurchaseOrder == null)
            return null;

        existingPurchaseOrder.SupplierId = purchaseOrder.SupplierId;
        existingPurchaseOrder.OrderDate = purchaseOrder.OrderDate;
        existingPurchaseOrder.ReceivedDate = purchaseOrder.ReceivedDate;
        existingPurchaseOrder.TotalAmount = purchaseOrder.TotalAmount;
        existingPurchaseOrder.Status = purchaseOrder.Status;
        existingPurchaseOrder.Notes = purchaseOrder.Notes;

        await _context.SaveChangesAsync();
        return existingPurchaseOrder;
    }

    public async Task<bool> DeletePurchaseOrderAsync(int id)
    {
        var purchaseOrder = await _context.PurchaseOrders.FindAsync(id);
        if (purchaseOrder == null)
            return false;

        _context.PurchaseOrders.Remove(purchaseOrder);
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<IEnumerable<PurchaseOrder>> GetPurchaseOrdersBySupplierAsync(int supplierId)
    {
        return await _context.PurchaseOrders
            .Include(po => po.Supplier)
            .Include(po => po.Items)
                .ThenInclude(poi => poi.Product)
            .Where(po => po.SupplierId == supplierId)
            .ToListAsync();
    }

    public async Task<IEnumerable<PurchaseOrder>> GetPurchaseOrdersByStatusAsync(string status)
    {
        return await _context.PurchaseOrders
            .Include(po => po.Supplier)
            .Include(po => po.Items)
                .ThenInclude(poi => poi.Product)
            .Where(po => po.Status == status)
            .ToListAsync();
    }

    public async Task<bool> UpdatePurchaseOrderStatusAsync(int id, string status)
    {
        var purchaseOrder = await _context.PurchaseOrders.FindAsync(id);
        if (purchaseOrder == null)
            return false;

        purchaseOrder.Status = status;
        await _context.SaveChangesAsync();
        return true;
    }
}