using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Tables;

namespace NerdERP.Services.Tables;

public interface ITableService
{
    Task<ServiceResponse<TableResponse>> CreateAsync(CreateTableRequest request);
    Task<ServiceResponse<TableResponse>> UpdateAsync(int id, UpdateTableRequest request);
    Task<ServiceResponse<bool>> DeleteAsync(int id);
    Task<ServiceResponse<TableResponse>> GetByIdAsync(int id);
    Task<ServiceResponse<TableResponse>> GetByTableNumberAsync(string tableNumber);
    Task<ServiceResponse<PagedResult<TableResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        TableFilterParams? filterParams = null);
    Task<ServiceResponse<List<TableResponse>>> GetAvailableTablesAsync(int? capacity = null);
    
    // Table status management
    Task<ServiceResponse<bool>> OccupyTableAsync(int tableId, int saleId);
    Task<ServiceResponse<bool>> ReleaseTableAsync(int tableId);
    Task<ServiceResponse<bool>> SetTableStatusAsync(int tableId, TableStatus status);
    
    // Reservation management
    Task<ServiceResponse<TableReservationResponse>> CreateReservationAsync(int tableId, ReserveTableRequest request);
    Task<ServiceResponse<bool>> ConfirmReservationAsync(int reservationId);
    Task<ServiceResponse<bool>> CancelReservationAsync(int reservationId);
    Task<ServiceResponse<bool>> SeatReservationAsync(int reservationId);
    Task<ServiceResponse<PagedResult<TableReservationResponse>>> GetReservationsAsync(
        PagingAndSortingParams pagingParams, 
        DateTime? date = null);
}