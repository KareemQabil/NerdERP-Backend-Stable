using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Schema.Tables;
using NerdERP.Infrastructure.Data;

namespace NerdERP.Services.Tables;

public class TableService : ITableService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<TableService> _logger;

    public TableService(ApplicationDbContext context, ILogger<TableService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<ServiceResponse<TableResponse>> CreateAsync(CreateTableRequest request)
    {
        try
        {
            // Check if table number already exists
            var existingTable = await _context.Tables
                .FirstOrDefaultAsync(t => t.TableNumber == request.TableNumber);

            if (existingTable != null)
            {
                return ServiceResponse<TableResponse>.CreateFailure(
                    $"Table with number '{request.TableNumber}' already exists.", 400);
            }

            var table = new Table
            {
                TableNumber = request.TableNumber,
                TableName = request.TableName,
                Capacity = request.Capacity,
                Location = request.Location,
                Description = request.Description,
                IsActive = request.IsActive,
                Status = TableStatus.Available,
                CreatedDate = DateTime.UtcNow
            };

            _context.Tables.Add(table);
            await _context.SaveChangesAsync();

            var response = MapToTableResponse(table);
            _logger.LogInformation("Table created successfully with ID: {TableId}", table.Id);

            return ServiceResponse<TableResponse>.CreateSuccess(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating table");
            return ServiceResponse<TableResponse>.CreateFailure(
                "An error occurred while creating the table.", 500);
        }
    }

    public async Task<ServiceResponse<TableResponse>> UpdateAsync(int id, UpdateTableRequest request)
    {
        try
        {
            var table = await _context.Tables.FindAsync(id);
            if (table == null)
            {
                return ServiceResponse<TableResponse>.CreateFailure("Table not found.", 404);
            }

            // Check if table number already exists (excluding current table)
            var existingTable = await _context.Tables
                .FirstOrDefaultAsync(t => t.TableNumber == request.TableNumber && t.Id != id);

            if (existingTable != null)
            {
                return ServiceResponse<TableResponse>.CreateFailure(
                    $"Table with number '{request.TableNumber}' already exists.", 400);
            }

            table.TableNumber = request.TableNumber;
            table.TableName = request.TableName;
            table.Capacity = request.Capacity;
            table.Location = request.Location;
            table.Description = request.Description;
            table.IsActive = request.IsActive;
            table.LastModifiedDate = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            var response = MapToTableResponse(table);
            _logger.LogInformation("Table updated successfully: {TableId}", id);

            return ServiceResponse<TableResponse>.CreateSuccess(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating table with ID: {TableId}", id);
            return ServiceResponse<TableResponse>.CreateFailure(
                "An error occurred while updating the table.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> DeleteAsync(int id)
    {
        try
        {
            var table = await _context.Tables.FindAsync(id);
            if (table == null)
            {
                return ServiceResponse<bool>.CreateFailure("Table not found.", 404);
            }

            // Check if table is currently occupied
            if (table.Status == TableStatus.Occupied)
            {
                return ServiceResponse<bool>.CreateFailure(
                    "Cannot delete an occupied table.", 400);
            }

            // Soft delete - mark as inactive
            table.IsActive = false;
            table.LastModifiedDate = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Table soft deleted: {TableId}", id);
            return ServiceResponse<bool>.CreateSuccess(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting table with ID: {TableId}", id);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while deleting the table.", 500);
        }
    }

    public async Task<ServiceResponse<TableResponse>> GetByIdAsync(int id)
    {
        try
        {
            var table = await _context.Tables
                .Include(t => t.CurrentSale)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (table == null)
            {
                return ServiceResponse<TableResponse>.CreateFailure("Table not found.", 404);
            }

            var response = MapToTableResponse(table);
            return ServiceResponse<TableResponse>.CreateSuccess(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting table with ID: {TableId}", id);
            return ServiceResponse<TableResponse>.CreateFailure(
                "An error occurred while retrieving the table.", 500);
        }
    }

    public async Task<ServiceResponse<TableResponse>> GetByTableNumberAsync(string tableNumber)
    {
        try
        {
            var table = await _context.Tables
                .Include(t => t.CurrentSale)
                .FirstOrDefaultAsync(t => t.TableNumber == tableNumber);

            if (table == null)
            {
                return ServiceResponse<TableResponse>.CreateFailure("Table not found.", 404);
            }

            var response = MapToTableResponse(table);
            return ServiceResponse<TableResponse>.CreateSuccess(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting table with number: {TableNumber}", tableNumber);
            return ServiceResponse<TableResponse>.CreateFailure(
                "An error occurred while retrieving the table.", 500);
        }
    }

    public async Task<ServiceResponse<PagedResult<TableResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        TableFilterParams? filterParams = null)
    {
        try
        {
            var query = _context.Tables.Include(t => t.CurrentSale).AsQueryable();

            // Apply filters
            if (filterParams != null)
            {
                if (!string.IsNullOrEmpty(filterParams.TableNumber))
                {
                    query = query.Where(t => t.TableNumber.Contains(filterParams.TableNumber));
                }

                if (!string.IsNullOrEmpty(filterParams.Location))
                {
                    query = query.Where(t => t.Location != null && t.Location.Contains(filterParams.Location));
                }

                if (filterParams.Status.HasValue)
                {
                    query = query.Where(t => t.Status == filterParams.Status.Value);
                }

                if (filterParams.IsActive.HasValue)
                {
                    query = query.Where(t => t.IsActive == filterParams.IsActive.Value);
                }

                if (filterParams.MinCapacity.HasValue)
                {
                    query = query.Where(t => t.Capacity >= filterParams.MinCapacity.Value);
                }

                if (filterParams.MaxCapacity.HasValue)
                {
                    query = query.Where(t => t.Capacity <= filterParams.MaxCapacity.Value);
                }
            }

            // Apply sorting
            if (!string.IsNullOrEmpty(pagingParams.OrderBy))
            {
                switch (pagingParams.OrderBy.ToLower())
                {
                    case "tablenumber":
                        query = pagingParams.SortDir?.ToLower() == "desc" 
                            ? query.OrderByDescending(t => t.TableNumber)
                            : query.OrderBy(t => t.TableNumber);
                        break;
                    case "capacity":
                        query = pagingParams.SortDir?.ToLower() == "desc" 
                            ? query.OrderByDescending(t => t.Capacity)
                            : query.OrderBy(t => t.Capacity);
                        break;
                    case "location":
                        query = pagingParams.SortDir?.ToLower() == "desc" 
                            ? query.OrderByDescending(t => t.Location)
                            : query.OrderBy(t => t.Location);
                        break;
                    case "status":
                        query = pagingParams.SortDir?.ToLower() == "desc" 
                            ? query.OrderByDescending(t => t.Status)
                            : query.OrderBy(t => t.Status);
                        break;
                    default:
                        query = query.OrderBy(t => t.TableNumber);
                        break;
                }
            }
            else
            {
                query = query.OrderBy(t => t.TableNumber);
            }

            var totalCount = await query.CountAsync();
            var tables = await query
                .Skip((pagingParams.PageNumber - 1) * pagingParams.PageSize)
                .Take(pagingParams.PageSize)
                .ToListAsync();

            var responses = tables.Select(MapToTableResponse).ToList();

            var pagedResult = new PagedResult<TableResponse>
            {
                Data = responses,
                TotalRecords = totalCount,
                PageNumber = pagingParams.PageNumber,
                PageSize = pagingParams.PageSize
            };

            return ServiceResponse<PagedResult<TableResponse>>.CreateSuccess(pagedResult);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting tables with paging");
            return ServiceResponse<PagedResult<TableResponse>>.CreateFailure(
                "An error occurred while retrieving tables.", 500);
        }
    }

    public async Task<ServiceResponse<List<TableResponse>>> GetAvailableTablesAsync(int? capacity = null)
    {
        try
        {
            var query = _context.Tables
                .Where(t => t.IsActive && t.Status == TableStatus.Available);

            if (capacity.HasValue)
            {
                query = query.Where(t => t.Capacity >= capacity.Value);
            }

            var tables = await query
                .OrderBy(t => t.TableNumber)
                .ToListAsync();

            var responses = tables.Select(MapToTableResponse).ToList();
            return ServiceResponse<List<TableResponse>>.CreateSuccess(responses);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting available tables");
            return ServiceResponse<List<TableResponse>>.CreateFailure(
                "An error occurred while retrieving available tables.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> OccupyTableAsync(int tableId, int saleId)
    {
        try
        {
            var table = await _context.Tables.FindAsync(tableId);
            if (table == null)
            {
                return ServiceResponse<bool>.CreateFailure("Table not found.", 404);
            }

            if (table.Status != TableStatus.Available)
            {
                return ServiceResponse<bool>.CreateFailure(
                    "Table is not available for occupation.", 400);
            }

            table.Status = TableStatus.Occupied;
            table.CurrentSaleId = saleId;
            table.CurrentOrderStartTime = DateTime.UtcNow;
            table.LastModifiedDate = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Table {TableId} occupied by sale {SaleId}", tableId, saleId);
            return ServiceResponse<bool>.CreateSuccess(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occupying table {TableId}", tableId);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while occupying the table.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> ReleaseTableAsync(int tableId)
    {
        try
        {
            var table = await _context.Tables.FindAsync(tableId);
            if (table == null)
            {
                return ServiceResponse<bool>.CreateFailure("Table not found.", 404);
            }

            table.Status = TableStatus.Available;
            table.CurrentSaleId = null;
            table.CurrentOrderStartTime = null;
            table.LastModifiedDate = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Table {TableId} released", tableId);
            return ServiceResponse<bool>.CreateSuccess(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error releasing table {TableId}", tableId);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while releasing the table.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> SetTableStatusAsync(int tableId, TableStatus status)
    {
        try
        {
            var table = await _context.Tables.FindAsync(tableId);
            if (table == null)
            {
                return ServiceResponse<bool>.CreateFailure("Table not found.", 404);
            }

            table.Status = status;
            table.LastModifiedDate = DateTime.UtcNow;

            // Clear occupation details if status is not Occupied
            if (status != TableStatus.Occupied)
            {
                table.CurrentSaleId = null;
                table.CurrentOrderStartTime = null;
            }

            await _context.SaveChangesAsync();

            _logger.LogInformation("Table {TableId} status set to {Status}", tableId, status);
            return ServiceResponse<bool>.CreateSuccess(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error setting table status {TableId}", tableId);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while updating table status.", 500);
        }
    }

    public async Task<ServiceResponse<TableReservationResponse>> CreateReservationAsync(int tableId, ReserveTableRequest request)
    {
        try
        {
            var table = await _context.Tables.FindAsync(tableId);
            if (table == null)
            {
                return ServiceResponse<TableReservationResponse>.CreateFailure("Table not found.", 404);
            }

            if (!table.IsActive)
            {
                return ServiceResponse<TableReservationResponse>.CreateFailure(
                    "Table is not active.", 400);
            }

            if (request.PartySize > table.Capacity)
            {
                return ServiceResponse<TableReservationResponse>.CreateFailure(
                    $"Party size ({request.PartySize}) exceeds table capacity ({table.Capacity}).", 400);
            }

            var reservation = new TableReservation
            {
                TableId = tableId,
                CustomerId = request.CustomerId,
                CustomerName = request.CustomerName,
                CustomerPhone = request.CustomerPhone,
                ReservationTime = request.ReservationTime ?? DateTime.UtcNow.AddHours(1),
                PartySize = request.PartySize,
                Notes = request.Notes,
                Status = ReservationStatus.Pending,
                CreatedDate = DateTime.UtcNow
            };

            _context.TableReservations.Add(reservation);
            await _context.SaveChangesAsync();

            // Load the table for response
            reservation.Table = table;

            var response = MapToReservationResponse(reservation);
            _logger.LogInformation("Reservation created successfully with ID: {ReservationId}", reservation.Id);

            return ServiceResponse<TableReservationResponse>.CreateSuccess(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating reservation for table {TableId}", tableId);
            return ServiceResponse<TableReservationResponse>.CreateFailure(
                "An error occurred while creating the reservation.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> ConfirmReservationAsync(int reservationId)
    {
        try
        {
            var reservation = await _context.TableReservations.FindAsync(reservationId);
            if (reservation == null)
            {
                return ServiceResponse<bool>.CreateFailure("Reservation not found.", 404);
            }

            reservation.Status = ReservationStatus.Confirmed;
            reservation.LastModifiedDate = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Reservation {ReservationId} confirmed", reservationId);
            return ServiceResponse<bool>.CreateSuccess(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error confirming reservation {ReservationId}", reservationId);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while confirming the reservation.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> CancelReservationAsync(int reservationId)
    {
        try
        {
            var reservation = await _context.TableReservations.FindAsync(reservationId);
            if (reservation == null)
            {
                return ServiceResponse<bool>.CreateFailure("Reservation not found.", 404);
            }

            reservation.Status = ReservationStatus.Cancelled;
            reservation.LastModifiedDate = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Reservation {ReservationId} cancelled", reservationId);
            return ServiceResponse<bool>.CreateSuccess(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error cancelling reservation {ReservationId}", reservationId);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while cancelling the reservation.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> SeatReservationAsync(int reservationId)
    {
        try
        {
            var reservation = await _context.TableReservations
                .Include(r => r.Table)
                .FirstOrDefaultAsync(r => r.Id == reservationId);

            if (reservation == null)
            {
                return ServiceResponse<bool>.CreateFailure("Reservation not found.", 404);
            }

            if (reservation.Table.Status != TableStatus.Available)
            {
                return ServiceResponse<bool>.CreateFailure(
                    "Table is not available for seating.", 400);
            }

            reservation.Status = ReservationStatus.Seated;
            reservation.LastModifiedDate = DateTime.UtcNow;

            // Update table status to reserved
            reservation.Table.Status = TableStatus.Reserved;
            reservation.Table.LastModifiedDate = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Reservation {ReservationId} seated", reservationId);
            return ServiceResponse<bool>.CreateSuccess(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error seating reservation {ReservationId}", reservationId);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while seating the reservation.", 500);
        }
    }

    public async Task<ServiceResponse<PagedResult<TableReservationResponse>>> GetReservationsAsync(
        PagingAndSortingParams pagingParams, 
        DateTime? date = null)
    {
        try
        {
            var query = _context.TableReservations
                .Include(r => r.Table)
                .Include(r => r.Customer)
                .AsQueryable();

            if (date.HasValue)
            {
                var startDate = date.Value.Date;
                var endDate = startDate.AddDays(1);
                query = query.Where(r => r.ReservationTime >= startDate && r.ReservationTime < endDate);
            }

            // Apply sorting
            query = query.OrderBy(r => r.ReservationTime);

            var totalCount = await query.CountAsync();
            var reservations = await query
                .Skip((pagingParams.PageNumber - 1) * pagingParams.PageSize)
                .Take(pagingParams.PageSize)
                .ToListAsync();

            var responses = reservations.Select(MapToReservationResponse).ToList();

            var pagedResult = new PagedResult<TableReservationResponse>
            {
                Data = responses,
                TotalRecords = totalCount,
                PageNumber = pagingParams.PageNumber,
                PageSize = pagingParams.PageSize
            };

            return ServiceResponse<PagedResult<TableReservationResponse>>.CreateSuccess(pagedResult);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting reservations");
            return ServiceResponse<PagedResult<TableReservationResponse>>.CreateFailure(
                "An error occurred while retrieving reservations.", 500);
        }
    }

    private static TableResponse MapToTableResponse(Table table)
    {
        return new TableResponse
        {
            Id = table.Id,
            TableNumber = table.TableNumber,
            TableName = table.TableName,
            Capacity = table.Capacity,
            Location = table.Location,
            Description = table.Description,
            IsActive = table.IsActive,
            Status = table.Status,
            CurrentOrderStartTime = table.CurrentOrderStartTime,
            CurrentSaleId = table.CurrentSaleId,
            CreatedDate = table.CreatedDate,
            LastModifiedDate = table.LastModifiedDate
        };
    }

    private static TableReservationResponse MapToReservationResponse(TableReservation reservation)
    {
        return new TableReservationResponse
        {
            Id = reservation.Id,
            TableId = reservation.TableId,
            TableNumber = reservation.Table?.TableNumber ?? "",
            CustomerId = reservation.CustomerId,
            CustomerName = reservation.CustomerName,
            CustomerPhone = reservation.CustomerPhone,
            ReservationTime = reservation.ReservationTime,
            PartySize = reservation.PartySize,
            Notes = reservation.Notes,
            Status = reservation.Status,
            CreatedDate = reservation.CreatedDate
        };
    }
}