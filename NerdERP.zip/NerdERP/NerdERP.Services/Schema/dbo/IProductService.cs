using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Products;

namespace NerdERP.Services.Schema.dbo;

public interface IProductService
{
    // Standard CRUD operations following ERP Guide
    Task<ServiceResponse<ProductResponse>> CreateAsync(CreateProductRequest request);
    Task<ServiceResponse<ProductResponse>> UpdateAsync(UpdateProductRequest request);
    Task<ServiceResponse<bool>> DeleteAsync(int id);
    Task<ServiceResponse<ProductResponse>> GetByIdAsync(int id);
    
    // Paging operation
    Task<ServiceResponse<PagedResult<ProductResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        ProductFilterParams filterParams);
        
    // Validation helpers
    Task<bool> IsProductExistsAsync(int id);
    Task<bool> IsSKUExistsAsync(string sku, int? excludeId = null);
    Task<bool> IsBarcodeExistsAsync(string barcode, int? excludeId = null);
    
    // Business operations
    Task<ServiceResponse<bool>> UpdateStockAsync(int productId, int newStock);
    Task<ServiceResponse<List<ProductResponse>>> GetLowStockProductsAsync();
}