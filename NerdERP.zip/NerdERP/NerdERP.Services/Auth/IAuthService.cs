using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Schema.User;

namespace NerdERP.Services.Auth;

public interface IAuthService
{
    Task<UserResponse> RegisterAsync(UserRegisterRequest request);
    Task<UserResponse> LoginAsync(UserLoginRequest request);
}
