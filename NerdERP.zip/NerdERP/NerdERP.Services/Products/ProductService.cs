using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Products;
using NerdERP.Infrastructure.Data;

namespace NerdERP.Services.Products;

public class ProductService : IProductService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<ProductService> _logger;

    public ProductService(ApplicationDbContext context, ILogger<ProductService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<ServiceResponse<ProductResponse>> CreateAsync(CreateProductRequest request)
    {
        // Validation
        if (request == null)
            return ServiceResponse<ProductResponse>.CreateFailure("Request cannot be null.", 400);
        if (string.IsNullOrWhiteSpace(request.Name))
            return ServiceResponse<ProductResponse>.CreateFailure("Product name is required.", 400);
        if (await IsSkuExistsAsync(request.SKU))
            return ServiceResponse<ProductResponse>.CreateFailure("SKU already exists.", 409);
        if (await IsBarcodeExistsAsync(request.Barcode))
            return ServiceResponse<ProductResponse>.CreateFailure("Barcode already exists.", 409);

        var product = new Product
        {
            Name = request.Name.Trim(),
            Description = request.Description,
            SKU = request.SKU.Trim(),
            Barcode = request.Barcode.Trim(),
            CategoryId = request.CategoryId,
            CostPrice = request.CostPrice,
            SellingPrice = request.SellingPrice,
            CurrentStock = request.CurrentStock,
            MinStockLevel = request.MinStockLevel,
            MaxStockLevel = request.MaxStockLevel,
            Unit = request.Unit.Trim(),
            CreatedDate = DateTime.UtcNow,
            IsActive = true
        };

        _context.Products.Add(product);
        await _context.SaveChangesAsync();

        var response = MapToResponse(product);
        return ServiceResponse<ProductResponse>.CreateSuccess(response, "Product created successfully.");
    }

    public async Task<ServiceResponse<ProductResponse>> UpdateAsync(UpdateProductRequest request)
    {
        if (request == null)
            return ServiceResponse<ProductResponse>.CreateFailure("Request cannot be null.", 400);
        var product = await _context.Products.FindAsync(request.Id);
        if (product == null)
            return ServiceResponse<ProductResponse>.CreateFailure("Product not found.", 404);
        if (await IsSkuExistsAsync(request.SKU, request.Id))
            return ServiceResponse<ProductResponse>.CreateFailure("SKU already exists.", 409);
        if (await IsBarcodeExistsAsync(request.Barcode, request.Id))
            return ServiceResponse<ProductResponse>.CreateFailure("Barcode already exists.", 409);

        product.Name = request.Name.Trim();
        product.Description = request.Description;
        product.SKU = request.SKU.Trim();
        product.Barcode = request.Barcode.Trim();
        product.CategoryId = request.CategoryId;
        product.CostPrice = request.CostPrice;
        product.SellingPrice = request.SellingPrice;
        product.CurrentStock = request.CurrentStock;
        product.MinStockLevel = request.MinStockLevel;
        product.MaxStockLevel = request.MaxStockLevel;
        product.Unit = request.Unit.Trim();
        product.UpdatedDate = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        var response = MapToResponse(product);
        return ServiceResponse<ProductResponse>.CreateSuccess(response, "Product updated successfully.");
    }

    public async Task<ServiceResponse<bool>> DeleteAsync(int id)
    {
        var product = await _context.Products.FindAsync(id);
        if (product == null)
            return ServiceResponse<bool>.CreateFailure("Product not found.", 404);

        _context.Products.Remove(product);
        await _context.SaveChangesAsync();
        return ServiceResponse<bool>.CreateSuccess(true, "Product deleted successfully.");
    }

    public async Task<ServiceResponse<ProductResponse>> GetByIdAsync(int id)
    {
        var product = await _context.Products
            .Include(p => p.Category)
            .FirstOrDefaultAsync(p => p.Id == id);
        if (product == null)
            return ServiceResponse<ProductResponse>.CreateFailure("Product not found.", 404);
        var response = MapToResponse(product);
        return ServiceResponse<ProductResponse>.CreateSuccess(response, "Product retrieved successfully.");
    }

    public async Task<ServiceResponse<PagedResult<ProductResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams,
        ProductFilterParams filterParams)
    {
        var query = _context.Products.Include(p => p.Category).AsQueryable();

        // Apply filters
        if (filterParams != null)
        {
            if (!string.IsNullOrWhiteSpace(filterParams.Name))
                query = query.Where(x => x.Name.Contains(filterParams.Name.Trim()));
            if (!string.IsNullOrWhiteSpace(filterParams.SKU))
                query = query.Where(x => x.SKU.Contains(filterParams.SKU.Trim()));
            if (!string.IsNullOrWhiteSpace(filterParams.Barcode))
                query = query.Where(x => x.Barcode.Contains(filterParams.Barcode.Trim()));
            if (filterParams.CategoryId.HasValue)
                query = query.Where(x => x.CategoryId == filterParams.CategoryId.Value);
            if (filterParams.MinPrice.HasValue)
                query = query.Where(x => x.SellingPrice >= filterParams.MinPrice.Value);
            if (filterParams.MaxPrice.HasValue)
                query = query.Where(x => x.SellingPrice <= filterParams.MaxPrice.Value);
            if (filterParams.IsActive.HasValue)
                query = query.Where(x => x.IsActive == filterParams.IsActive.Value);
            if (filterParams.LowStock.HasValue && filterParams.LowStock.Value)
                query = query.Where(x => x.CurrentStock <= x.MinStockLevel);
            if (filterParams.CreatedFrom.HasValue)
                query = query.Where(x => x.CreatedDate >= filterParams.CreatedFrom.Value);
            if (filterParams.CreatedTo.HasValue)
                query = query.Where(x => x.CreatedDate <= filterParams.CreatedTo.Value);
        }

        var totalRecords = await query.CountAsync();
        var orderBy = pagingParams.OrderBy ?? "Id";
        var sortDirection = pagingParams.SortDir ?? "ASC";
        query = sortDirection.ToUpper() == "DESC"
            ? query.OrderByDescending(x => EF.Property<object>(x, orderBy))
            : query.OrderBy(x => EF.Property<object>(x, orderBy));

        var products = await query
            .Skip((pagingParams.PageNumber - 1) * pagingParams.PageSize)
            .Take(pagingParams.PageSize)
            .ToListAsync();

        var responses = products.Select(MapToResponse).ToList();
        var pagedResult = new PagedResult<ProductResponse>
        {
            Data = responses,
            TotalRecords = totalRecords,
            PageNumber = pagingParams.PageNumber,
            PageSize = pagingParams.PageSize
        };
        return ServiceResponse<PagedResult<ProductResponse>>.CreateSuccess(pagedResult, "Products retrieved successfully.");
    }

    public async Task<bool> IsProductExistsAsync(int id)
    {
        return await _context.Products.AnyAsync(x => x.Id == id);
    }

    public async Task<bool> IsSkuExistsAsync(string sku, int? excludeId = null)
    {
        var query = _context.Products.Where(x => x.SKU.ToLower() == sku.ToLower().Trim());
        if (excludeId.HasValue)
            query = query.Where(x => x.Id != excludeId.Value);
        return await query.AnyAsync();
    }

    public async Task<bool> IsBarcodeExistsAsync(string barcode, int? excludeId = null)
    {
        var query = _context.Products.Where(x => x.Barcode.ToLower() == barcode.ToLower().Trim());
        if (excludeId.HasValue)
            query = query.Where(x => x.Id != excludeId.Value);
        return await query.AnyAsync();
    }

    private ProductResponse MapToResponse(Product product)
    {
        return new ProductResponse
        {
            Id = product.Id,
            Name = product.Name,
            Description = product.Description,
            SKU = product.SKU,
            Barcode = product.Barcode,
            CategoryId = product.CategoryId,
            CategoryName = product.Category?.Name ?? string.Empty,
            CostPrice = product.CostPrice,
            SellingPrice = product.SellingPrice,
            CurrentStock = product.CurrentStock,
            MinStockLevel = product.MinStockLevel,
            MaxStockLevel = product.MaxStockLevel,
            Unit = product.Unit,
            IsActive = product.IsActive,
            CreatedDate = product.CreatedDate,
            UpdatedDate = product.UpdatedDate
        };
    }
}