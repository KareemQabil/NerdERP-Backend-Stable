using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Products;

namespace NerdERP.Services.Products;

public interface IProductService
{
    Task<ServiceResponse<ProductResponse>> CreateAsync(CreateProductRequest request);
    Task<ServiceResponse<ProductResponse>> UpdateAsync(UpdateProductRequest request);
    Task<ServiceResponse<bool>> DeleteAsync(int id);
    Task<ServiceResponse<ProductResponse>> GetByIdAsync(int id);
    Task<ServiceResponse<PagedResult<ProductResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams,
        ProductFilterParams filterParams);
    Task<bool> IsProductExistsAsync(int id);
    Task<bool> IsSkuExistsAsync(string sku, int? excludeId = null);
    Task<bool> IsBarcodeExistsAsync(string barcode, int? excludeId = null);
}