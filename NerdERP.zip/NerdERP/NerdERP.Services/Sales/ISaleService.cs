using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Sales;

namespace NerdERP.Services.Sales;

public interface ISaleService
{
    Task<ServiceResponse<SaleResponse>> CreateAsync(CreateSaleRequest request);
    Task<ServiceResponse<SaleResponse>> UpdateAsync(int id, UpdateSaleRequest request);
    Task<ServiceResponse<bool>> DeleteAsync(int id);
    Task<ServiceResponse<SaleResponse>> GetByIdAsync(int id);
    Task<ServiceResponse<PagedResult<SaleResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        SaleFilterParams filterParams);
    Task<ServiceResponse<decimal>> GetTotalSalesAmountAsync(DateTime? startDate = null, DateTime? endDate = null);
}