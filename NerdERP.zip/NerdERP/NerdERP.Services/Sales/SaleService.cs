using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Schema.Sales;
using NerdERP.Infrastructure.Data;

namespace NerdERP.Services.Sales;

public class SaleService : ISaleService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<SaleService> _logger;

    public SaleService(ApplicationDbContext context, ILogger<SaleService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<ServiceResponse<SaleResponse>> CreateAsync(CreateSaleRequest request)
    {
        using var transaction = await _context.Database.BeginTransactionAsync();
        try
        {
            _logger.LogInformation("Creating new sale for user: {UserId}", request.UserId);

            // Validate customer if provided
            if (request.CustomerId.HasValue)
            {
                var customerExists = await _context.Customers
                    .AnyAsync(c => c.Id == request.CustomerId.Value && c.IsActive);
                
                if (!customerExists)
                {
                    _logger.LogWarning("Sale creation failed - customer not found: {CustomerId}", request.CustomerId);
                    return ServiceResponse<SaleResponse>.CreateFailure(
                        "Customer not found.", 404);
                }
            }

            // Validate user exists
            var userExists = await _context.Users
                .AnyAsync(u => u.Id == request.UserId);
            
            if (!userExists)
            {
                _logger.LogWarning("Sale creation failed - user not found: {UserId}", request.UserId);
                return ServiceResponse<SaleResponse>.CreateFailure(
                    "User not found.", 404);
            }

            // Validate table if provided (for dine-in orders)
            if (request.TableId.HasValue)
            {
                var table = await _context.Tables
                    .FirstOrDefaultAsync(t => t.Id == request.TableId.Value && t.IsActive);
                
                if (table == null)
                {
                    _logger.LogWarning("Sale creation failed - table not found: {TableId}", request.TableId);
                    return ServiceResponse<SaleResponse>.CreateFailure(
                        "Table not found.", 404);
                }

                if (table.Status != Core.Models.Schema.Tables.TableStatus.Available)
                {
                    _logger.LogWarning("Sale creation failed - table not available: {TableId}", request.TableId);
                    return ServiceResponse<SaleResponse>.CreateFailure(
                        "Table is not available.", 409);
                }
            }

            // Validate order type
            if (request.OrderType == "DineIn" && !request.TableId.HasValue)
            {
                return ServiceResponse<SaleResponse>.CreateFailure(
                    "Table selection is required for dine-in orders.", 400);
            }

            // Validate and prepare sale items
            var saleItems = new List<SaleItem>();
            decimal subTotal = 0;

            foreach (var itemRequest in request.Items)
            {
                var product = await _context.Products
                    .FirstOrDefaultAsync(p => p.Id == itemRequest.ProductId && p.IsActive);

                if (product == null)
                {
                    _logger.LogWarning("Sale creation failed - product not found: {ProductId}", itemRequest.ProductId);
                    return ServiceResponse<SaleResponse>.CreateFailure(
                        $"Product with ID {itemRequest.ProductId} not found.", 404);
                }

                // Check stock availability
                if (product.CurrentStock < itemRequest.Quantity)
                {
                    _logger.LogWarning("Sale creation failed - insufficient stock for product: {ProductId}", itemRequest.ProductId);
                    return ServiceResponse<SaleResponse>.CreateFailure(
                        $"Insufficient stock for product '{product.Name}'. Available: {product.CurrentStock}, Requested: {itemRequest.Quantity}", 409);
                }

                var lineTotal = (itemRequest.UnitPrice * itemRequest.Quantity) - itemRequest.DiscountAmount;
                subTotal += lineTotal;

                var saleItem = new SaleItem
                {
                    ProductId = itemRequest.ProductId,
                    ProductName = product.Name,
                    UnitPrice = itemRequest.UnitPrice,
                    Quantity = itemRequest.Quantity,
                    DiscountAmount = itemRequest.DiscountAmount,
                    LineTotal = lineTotal
                };

                saleItems.Add(saleItem);

                // Update product stock
                product.CurrentStock -= itemRequest.Quantity;
            }

            // Generate sale number
            var saleNumber = await GenerateSaleNumberAsync();

            // Calculate totals
            var taxRate = 0.14m; // 14% tax rate (configurable)
            var taxAmount = subTotal * taxRate;
            var totalAmount = subTotal + taxAmount - request.DiscountAmount;

            var sale = new Sale
            {
                SaleNumber = saleNumber,
                CustomerId = request.CustomerId,
                UserId = request.UserId,
                SubTotal = subTotal,
                TaxAmount = taxAmount,
                DiscountAmount = request.DiscountAmount,
                TotalAmount = totalAmount,
                PaymentMethod = request.PaymentMethod,
                Status = "Completed",
                SaleDate = DateTime.UtcNow,
                Notes = request.Notes,
                TableId = request.TableId,
                OrderType = request.OrderType,
                Items = saleItems
            };

            _context.Sales.Add(sale);
            await _context.SaveChangesAsync();

            // Occupy table if it's a dine-in order
            if (request.TableId.HasValue && request.OrderType == "DineIn")
            {
                var table = await _context.Tables.FindAsync(request.TableId.Value);
                if (table != null)
                {
                    table.Status = Core.Models.Schema.Tables.TableStatus.Occupied;
                    table.CurrentSaleId = sale.Id;
                    table.CurrentOrderStartTime = DateTime.UtcNow;
                    table.LastModifiedDate = DateTime.UtcNow;
                    await _context.SaveChangesAsync();
                }
            }

            await transaction.CommitAsync();

            _logger.LogInformation("Sale created successfully with ID: {SaleId}", sale.Id);

            // Reload with navigation properties
            var createdSale = await _context.Sales
                .Include(s => s.Customer)
                .Include(s => s.User)
                .Include(s => s.Table)
                .Include(s => s.Items)
                    .ThenInclude(si => si.Product)
                .FirstOrDefaultAsync(s => s.Id == sale.Id);

            var response = MapToResponse(createdSale!);
            return ServiceResponse<SaleResponse>.CreateSuccess(response, "Sale created successfully.");
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            _logger.LogError(ex, "Error creating sale for user: {UserId}", request.UserId);
            return ServiceResponse<SaleResponse>.CreateFailure(
                "An error occurred while creating the sale.", 500);
        }
    }

    public async Task<ServiceResponse<SaleResponse>> UpdateAsync(int id, UpdateSaleRequest request)
    {
        try
        {
            _logger.LogInformation("Updating sale with ID: {SaleId}", id);

            var sale = await _context.Sales.FindAsync(id);
            if (sale == null)
            {
                _logger.LogWarning("Sale not found for update. ID: {SaleId}", id);
                return ServiceResponse<SaleResponse>.CreateFailure(
                    "Sale not found.", 404);
            }

            // Validate customer if provided
            if (request.CustomerId.HasValue)
            {
                var customerExists = await _context.Customers
                    .AnyAsync(c => c.Id == request.CustomerId.Value && c.IsActive);
                
                if (!customerExists)
                {
                    _logger.LogWarning("Sale update failed - customer not found: {CustomerId}", request.CustomerId);
                    return ServiceResponse<SaleResponse>.CreateFailure(
                        "Customer not found.", 404);
                }
            }

            sale.CustomerId = request.CustomerId;
            sale.Status = request.Status;
            sale.Notes = request.Notes;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Sale updated successfully. ID: {SaleId}", id);

            // Reload with navigation properties
            var updatedSale = await _context.Sales
                .Include(s => s.Customer)
                .Include(s => s.User)
                .Include(s => s.Items)
                    .ThenInclude(si => si.Product)
                .FirstOrDefaultAsync(s => s.Id == id);

            var response = MapToResponse(updatedSale!);
            return ServiceResponse<SaleResponse>.CreateSuccess(response, "Sale updated successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating sale with ID: {SaleId}", id);
            return ServiceResponse<SaleResponse>.CreateFailure(
                "An error occurred while updating the sale.", 500);
        }
    }

    public async Task<ServiceResponse<bool>> DeleteAsync(int id)
    {
        try
        {
            _logger.LogInformation("Deleting sale with ID: {SaleId}", id);

            var sale = await _context.Sales
                .Include(s => s.Items)
                    .ThenInclude(si => si.Product)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (sale == null)
            {
                _logger.LogWarning("Sale not found for deletion. ID: {SaleId}", id);
                return ServiceResponse<bool>.CreateFailure(
                    "Sale not found.", 404);
            }

            // Restore stock quantities
            foreach (var item in sale.Items)
            {
                if (item.Product != null)
                {
                    item.Product.CurrentStock += item.Quantity;
                }
            }

            _context.Sales.Remove(sale);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Sale deleted successfully. ID: {SaleId}", id);

            return ServiceResponse<bool>.CreateSuccess(true, "Sale deleted successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting sale with ID: {SaleId}", id);
            return ServiceResponse<bool>.CreateFailure(
                "An error occurred while deleting the sale.", 500);
        }
    }

    public async Task<ServiceResponse<SaleResponse>> GetByIdAsync(int id)
    {
        try
        {
            _logger.LogInformation("Retrieving sale with ID: {SaleId}", id);

            var sale = await _context.Sales
                .Include(s => s.Customer)
                .Include(s => s.User)
                .Include(s => s.Table)
                .Include(s => s.Items)
                    .ThenInclude(si => si.Product)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (sale == null)
            {
                _logger.LogWarning("Sale not found. ID: {SaleId}", id);
                return ServiceResponse<SaleResponse>.CreateFailure(
                    "Sale not found.", 404);
            }

            var response = MapToResponse(sale);
            return ServiceResponse<SaleResponse>.CreateSuccess(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving sale with ID: {SaleId}", id);
            return ServiceResponse<SaleResponse>.CreateFailure(
                "An error occurred while retrieving the sale.", 500);
        }
    }

    public async Task<ServiceResponse<PagedResult<SaleResponse>>> GetAllWithPagingAsync(
        PagingAndSortingParams pagingParams, 
        SaleFilterParams filterParams)
    {
        try
        {
            _logger.LogInformation("Retrieving sales with paging. Page: {PageNumber}, Size: {PageSize}", 
                pagingParams.PageNumber, pagingParams.PageSize);

            var query = _context.Sales
                .Include(s => s.Customer)
                .Include(s => s.User)
                .Include(s => s.Table)
                .Include(s => s.Items)
                    .ThenInclude(si => si.Product)
                .AsQueryable();

            // Apply filters
            if (filterParams.CustomerId.HasValue)
            {
                query = query.Where(s => s.CustomerId == filterParams.CustomerId.Value);
            }

            if (filterParams.UserId.HasValue)
            {
                query = query.Where(s => s.UserId == filterParams.UserId.Value);
            }

            if (!string.IsNullOrEmpty(filterParams.PaymentMethod))
            {
                query = query.Where(s => s.PaymentMethod.ToLower().Contains(filterParams.PaymentMethod.ToLower()));
            }

            if (!string.IsNullOrEmpty(filterParams.Status))
            {
                query = query.Where(s => s.Status.ToLower() == filterParams.Status.ToLower());
            }

            if (filterParams.SaleDateFrom.HasValue)
            {
                query = query.Where(s => s.SaleDate >= filterParams.SaleDateFrom.Value);
            }

            if (filterParams.SaleDateTo.HasValue)
            {
                query = query.Where(s => s.SaleDate <= filterParams.SaleDateTo.Value);
            }

            if (filterParams.MinAmount.HasValue)
            {
                query = query.Where(s => s.TotalAmount >= filterParams.MinAmount.Value);
            }

            if (filterParams.MaxAmount.HasValue)
            {
                query = query.Where(s => s.TotalAmount <= filterParams.MaxAmount.Value);
            }

            // Apply sorting
            query = pagingParams.OrderBy?.ToLower() switch
            {
                "salenumber" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.SaleNumber)
                    : query.OrderBy(s => s.SaleNumber),
                "saledate" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.SaleDate)
                    : query.OrderBy(s => s.SaleDate),
                "totalamount" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.TotalAmount)
                    : query.OrderBy(s => s.TotalAmount),
                "status" => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.Status)
                    : query.OrderBy(s => s.Status),
                _ => pagingParams.SortDir?.ToUpper() == "DESC" 
                    ? query.OrderByDescending(s => s.Id)
                    : query.OrderBy(s => s.Id)
            };

            var totalRecords = await query.CountAsync();

            var sales = await query
                .Skip((pagingParams.PageNumber - 1) * pagingParams.PageSize)
                .Take(pagingParams.PageSize)
                .ToListAsync();

            var saleResponses = sales.Select(MapToResponse).ToList();

            var pagedResult = new PagedResult<SaleResponse>
            {
                Data = saleResponses,
                TotalRecords = totalRecords,
                PageNumber = pagingParams.PageNumber,
                PageSize = pagingParams.PageSize
            };

            return ServiceResponse<PagedResult<SaleResponse>>.CreateSuccess(pagedResult);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving sales with paging");
            return ServiceResponse<PagedResult<SaleResponse>>.CreateFailure(
                "An error occurred while retrieving sales.", 500);
        }
    }

    public async Task<ServiceResponse<decimal>> GetTotalSalesAmountAsync(DateTime? startDate = null, DateTime? endDate = null)
    {
        try
        {
            _logger.LogInformation("Calculating total sales amount. Start: {StartDate}, End: {EndDate}", 
                startDate, endDate);

            var query = _context.Sales.AsQueryable();

            if (startDate.HasValue)
                query = query.Where(s => s.SaleDate >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(s => s.SaleDate <= endDate.Value);

            var totalAmount = await query.SumAsync(s => s.TotalAmount);

            return ServiceResponse<decimal>.CreateSuccess(totalAmount);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calculating total sales amount");
            return ServiceResponse<decimal>.CreateFailure(
                "An error occurred while calculating total sales amount.", 500);
        }
    }

    private async Task<string> GenerateSaleNumberAsync()
    {
        var today = DateTime.UtcNow.ToString("yyyyMMdd");
        var count = await _context.Sales
            .CountAsync(s => s.SaleNumber.StartsWith($"SALE-{today}"));
        
        return $"SALE-{today}-{(count + 1):D4}";
    }

    private static SaleResponse MapToResponse(Sale sale)
    {
        return new SaleResponse
        {
            Id = sale.Id,
            SaleNumber = sale.SaleNumber,
            CustomerId = sale.CustomerId,
            CustomerName = sale.Customer?.FirstName + " " + sale.Customer?.LastName,
            UserId = sale.UserId,
            UserName = sale.User?.Username ?? "",
            SubTotal = sale.SubTotal,
            TaxAmount = sale.TaxAmount,
            DiscountAmount = sale.DiscountAmount,
            TotalAmount = sale.TotalAmount,
            PaymentMethod = sale.PaymentMethod,
            Status = sale.Status,
            SaleDate = sale.SaleDate,
            Notes = sale.Notes,
            TableId = sale.TableId,
            TableNumber = sale.Table?.TableNumber,
            OrderType = sale.OrderType,
            Items = sale.Items.Select(item => new SaleItemResponse
            {
                Id = item.Id,
                ProductId = item.ProductId,
                ProductName = item.ProductName,
                UnitPrice = item.UnitPrice,
                Quantity = item.Quantity,
                DiscountAmount = item.DiscountAmount,
                LineTotal = item.LineTotal
            }).ToList()
        };
    }
}