using Microsoft.EntityFrameworkCore;
using NerdERP.Infrastructure.Data;
using NerdERP.Core.Models.Entities;

namespace NerdERP.Tests.Infrastructure;

public class TestDbContext : IDisposable
{
    public ApplicationDbContext Context { get; }

    public TestDbContext()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

        Context = new ApplicationDbContext(options);
        Context.Database.EnsureCreated();
        SeedTestData();
    }

    private void SeedTestData()
    {
        // Seed test categories
        var electronics = new Category 
        { 
            Id = 1,
            Name = "Electronics", 
            Description = "Electronic devices",
            IsActive = true,
            CreatedDate = DateTime.UtcNow
        };
        
        var books = new Category 
        { 
            Id = 2,
            Name = "Books", 
            Description = "Books and materials",
            IsActive = true,
            CreatedDate = DateTime.UtcNow
        };

        Context.Categories.AddRange(electronics, books);

        // Seed test products
        var product1 = new Product
        {
            Id = 1,
            Name = "Test iPhone",
            Description = "Test iPhone device",
            SKU = "TEST-IPHONE-001",
            Barcode = "123456789012",
            CategoryId = 1,
            CostPrice = 800m,
            SellingPrice = 999m,
            CurrentStock = 50,
            MinStockLevel = 10,
            MaxStockLevel = 100,
            Unit = "pieces",
            IsActive = true,
            CreatedDate = DateTime.UtcNow
        };

        var product2 = new Product
        {
            Id = 2,
            Name = "Test Book",
            Description = "Test programming book",
            SKU = "TEST-BOOK-001",
            Barcode = "123456789013",
            CategoryId = 2,
            CostPrice = 25m,
            SellingPrice = 45m,
            CurrentStock = 30,
            MinStockLevel = 5,
            MaxStockLevel = 50,
            Unit = "pieces",
            IsActive = true,
            CreatedDate = DateTime.UtcNow
        };

        Context.Products.AddRange(product1, product2);

        // Seed test user
        var testUser = new User
        {
            Id = 1,
            Username = "testuser",
            Email = "test@example.com",
            FirstName = "Test",
            LastName = "User",
            Role = "Admin",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("TestPass123!"),
            IsActive = true,
            CreatedDate = DateTime.UtcNow
        };

        Context.Users.Add(testUser);

        // Seed test customer
        var testCustomer = new Customer
        {
            Id = 1,
            FirstName = "Test",
            LastName = "Customer",
            Email = "customer@test.com",
            Phone = "+1-555-0123",
            Address = "123 Test St",
            IsActive = true,
            CreatedDate = DateTime.UtcNow
        };

        Context.Customers.Add(testCustomer);

        // Seed test supplier
        var testSupplier = new Supplier
        {
            Id = 1,
            Name = "Test Supplier Inc",
            ContactPerson = "John Test",
            Email = "supplier@test.com",
            Phone = "+1-555-0456",
            Address = "456 Supplier Ave",
            IsActive = true,
            CreatedDate = DateTime.UtcNow
        };

        Context.Suppliers.Add(testSupplier);

        Context.SaveChanges();
    }

    public void Dispose()
    {
        Context.Dispose();
    }
}
