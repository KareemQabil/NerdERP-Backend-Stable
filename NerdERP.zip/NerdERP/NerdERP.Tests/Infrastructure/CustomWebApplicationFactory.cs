using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using NerdERP.Infrastructure.Data;

namespace NerdERP.Tests.Infrastructure;

public class CustomWebApplicationFactory<TProgram> : WebApplicationFactory<TProgram> where TProgram : class
{
    private readonly string _databaseName = $"TestDb_{Guid.NewGuid()}";

    public override async ValueTask DisposeAsync()
    {
        using var scope = Services.CreateScope();
        var context = scope.ServiceProvider.GetService<ApplicationDbContext>();
        if (context != null)
        {
            await context.Database.EnsureDeletedAsync();
        }
        await base.DisposeAsync();
    }

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        
        builder.ConfigureServices(services =>
        {
            // Remove all existing DbContext registrations
            var descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(DbContextOptions<ApplicationDbContext>));
            if (descriptor != null)
            {
                services.Remove(descriptor);
            }
            
            // Add test database context
            services.AddDbContext<ApplicationDbContext>(options =>
            {
                options.UseInMemoryDatabase(_databaseName);
                options.EnableSensitiveDataLogging();
            });
        });
    }

    public void InitializeDatabase()
    {
        using var scope = Services.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        
        context.Database.EnsureCreated();
        
        if (!context.Categories.Any())
        {
            context.Categories.AddRange(
                new NerdERP.Core.Models.Entities.Category 
                { 
                    Name = "Test Electronics", 
                    Description = "Test electronic devices",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new NerdERP.Core.Models.Entities.Category 
                { 
                    Name = "Test Books", 
                    Description = "Test books and materials",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                }
            );
        }

        if (!context.Users.Any())
        {
            context.Users.Add(new NerdERP.Core.Models.Entities.User
            {
                Username = "testadmin",
                Email = "test@admin.com",
                FirstName = "Test",
                LastName = "Admin",
                Role = "Admin",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("TestPass123!"),
                IsActive = true,
                CreatedDate = DateTime.UtcNow
            });
        }

        context.SaveChanges();
    }
}
