using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using NerdERP.Core.Models.Entities;
using NerdERP.Tests.Infrastructure;
using NerdERP.WebApi;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace NerdERP.Tests.IntegrationTests;

// NOTE: Integration tests temporarily disabled due to database provider conflicts
// These tests will be re-enabled in a future version with proper configuration
public class ProductsIntegrationTests_Disabled : IClassFixture<CustomWebApplicationFactory<Program>>
{
    private readonly HttpClient _client;
    private readonly CustomWebApplicationFactory<Program> _factory;

    public ProductsIntegrationTests_Disabled(CustomWebApplicationFactory<Program> factory)
    {
        _factory = factory;
        _client = _factory.CreateClient();
        
        // Initialize test database with seed data
        _factory.InitializeDatabase();
    }

    private async Task<string> GetAuthTokenAsync()
    {
        var loginRequest = new
        {
            Username = "testadmin",
            Password = "TestPass123!"
        };

        var response = await _client.PostAsJsonAsync("/api/auth/login", loginRequest);
        response.EnsureSuccessStatusCode();
        
        var content = await response.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(content);
        return doc.RootElement.GetProperty("token").GetString()!;
    }

    [Fact]
    public async Task GetProducts_WithoutAuth_ShouldReturnUnauthorized()
    {
        // Act
        var response = await _client.GetAsync("/api/products");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    [Fact]
    public async Task GetProducts_WithAuth_ShouldReturnProducts()
    {
        // Arrange
        var token = await GetAuthTokenAsync();
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        // Act
        var response = await _client.GetAsync("/api/products");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var content = await response.Content.ReadAsStringAsync();
        
        using var doc = JsonDocument.Parse(content);
        doc.RootElement.GetArrayLength().Should().BeGreaterThan(0);
    }

    [Fact]
    public async Task CreateProduct_WithValidData_ShouldSucceed()
    {
        // Arrange
        var token = await GetAuthTokenAsync();
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var newProduct = new
        {
            Name = "Integration Test Product",
            Description = "Product created during integration testing",
            SKU = "INT-TEST-001",
            Barcode = "123456789999",
            CategoryId = 1,
            CostPrice = 50.00m,
            SellingPrice = 75.00m,
            CurrentStock = 100,
            MinStockLevel = 10,
            MaxStockLevel = 200,
            Unit = "pieces"
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/products", newProduct);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Created);
        
        var content = await response.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(content);
        doc.RootElement.GetProperty("name").GetString().Should().Be("Integration Test Product");
        doc.RootElement.GetProperty("id").GetInt32().Should().BeGreaterThan(0);
    }

    [Fact]
    public async Task CreateProduct_WithDuplicateSKU_ShouldFail()
    {
        // Arrange
        var token = await GetAuthTokenAsync();
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var duplicateProduct = new
        {
            Name = "Duplicate SKU Product",
            Description = "This should fail",
            SKU = "TEST-IPHONE-001", // This SKU exists in test data
            Barcode = "123456789998",
            CategoryId = 1,
            CostPrice = 50.00m,
            SellingPrice = 75.00m,
            CurrentStock = 100,
            MinStockLevel = 10,
            MaxStockLevel = 200,
            Unit = "pieces"
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/products", duplicateProduct);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task UpdateProduct_WithValidData_ShouldSucceed()
    {
        // Arrange
        var token = await GetAuthTokenAsync();
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var productId = 1;
        var updatedProduct = new
        {
            Id = productId,
            Name = "Updated Test iPhone",
            Description = "Updated description",
            SKU = "TEST-IPHONE-001",
            Barcode = "123456789012",
            CategoryId = 1,
            CostPrice = 850.00m,
            SellingPrice = 1099.00m,
            CurrentStock = 50,
            MinStockLevel = 10,
            MaxStockLevel = 100,
            Unit = "pieces"
        };

        // Act
        var response = await _client.PutAsJsonAsync($"/api/products/{productId}", updatedProduct);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.NoContent);

        // Verify the update
        var getResponse = await _client.GetAsync($"/api/products/{productId}");
        getResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        
        var content = await getResponse.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(content);
        doc.RootElement.GetProperty("name").GetString().Should().Be("Updated Test iPhone");
        doc.RootElement.GetProperty("costPrice").GetDecimal().Should().Be(850.00m);
    }

    [Fact]
    public async Task SearchProducts_WithValidTerm_ShouldReturnResults()
    {
        // Arrange
        var token = await GetAuthTokenAsync();
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        // Act
        var response = await _client.GetAsync("/api/products/search?searchTerm=iPhone");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        
        var content = await response.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(content);
        doc.RootElement.GetArrayLength().Should().BeGreaterThan(0);
        
        // Check that all returned products contain the search term
        foreach (var product in doc.RootElement.EnumerateArray())
        {
            var name = product.GetProperty("name").GetString();
            name.Should().ContainEquivalentOf("iPhone");
        }
    }

    [Fact]
    public async Task DeleteProduct_WithValidId_ShouldSoftDelete()
    {
        // Arrange
        var token = await GetAuthTokenAsync();
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var productId = 2; // Use the test book product

        // Act
        var response = await _client.DeleteAsync($"/api/products/{productId}");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.NoContent);

        // Verify the product still exists but is inactive
        var getResponse = await _client.GetAsync($"/api/products/{productId}");
        getResponse.StatusCode.Should().Be(HttpStatusCode.NotFound); // Should not be found in active products
    }

    [Theory]
    [InlineData("", "Test Product", "TEST-001", "123456789001", 1, 50.00, 75.00, 100, 10, 200, "pieces")] // Empty name
    [InlineData("Test Product", "", "TEST-002", "123456789002", 1, 50.00, 75.00, 100, 10, 200, "pieces")] // Empty description is OK
    [InlineData("Test Product", "Description", "", "123456789003", 1, 50.00, 75.00, 100, 10, 200, "pieces")] // Empty SKU
    [InlineData("Test Product", "Description", "TEST-004", "", 1, 50.00, 75.00, 100, 10, 200, "pieces")] // Empty barcode
    [InlineData("Test Product", "Description", "TEST-005", "123456789005", 0, 50.00, 75.00, 100, 10, 200, "pieces")] // Invalid category
    [InlineData("Test Product", "Description", "TEST-006", "123456789006", 1, -50.00, 75.00, 100, 10, 200, "pieces")] // Negative cost
    [InlineData("Test Product", "Description", "TEST-007", "123456789007", 1, 50.00, -75.00, 100, 10, 200, "pieces")] // Negative selling price
    [InlineData("Test Product", "Description", "TEST-008", "123456789008", 1, 50.00, 75.00, -100, 10, 200, "pieces")] // Negative stock
    public async Task CreateProduct_WithInvalidData_ShouldFail(
        string name, string description, string sku, string barcode,
        int categoryId, decimal costPrice, decimal sellingPrice,
        int currentStock, int minStockLevel, int maxStockLevel, string unit)
    {
        // Arrange
        var token = await GetAuthTokenAsync();
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        var invalidProduct = new
        {
            Name = name,
            Description = description,
            SKU = sku,
            Barcode = barcode,
            CategoryId = categoryId,
            CostPrice = costPrice,
            SellingPrice = sellingPrice,
            CurrentStock = currentStock,
            MinStockLevel = minStockLevel,
            MaxStockLevel = maxStockLevel,
            Unit = unit
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/products", invalidProduct);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }
}
