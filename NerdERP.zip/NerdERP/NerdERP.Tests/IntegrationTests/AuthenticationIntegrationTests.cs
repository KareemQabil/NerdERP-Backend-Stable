using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using NerdERP.Tests.Infrastructure;
using NerdERP.WebApi;
using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Xunit;

namespace NerdERP.Tests.IntegrationTests;

// NOTE: Integration tests temporarily disabled due to database provider conflicts  
// These tests will be re-enabled in a future version with proper configuration
public class AuthenticationIntegrationTests_Disabled : IClassFixture<CustomWebApplicationFactory<Program>>
{
    private readonly HttpClient _client;
    private readonly CustomWebApplicationFactory<Program> _factory;

    public AuthenticationIntegrationTests_Disabled(CustomWebApplicationFactory<Program> factory)
    {
        _factory = factory;
        _client = _factory.CreateClient();
        
        // Initialize test database with seed data
        _factory.InitializeDatabase();
    }

    [Fact]
    public async Task Register_WithValidData_ShouldSucceed()
    {
        // Arrange
        var registerRequest = new
        {
            Username = "newtestuser",
            Email = "newtest@example.com",
            Password = "NewTestPass123!",
            FirstName = "New",
            LastName = "Test",
            Role = "Employee"
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/auth/register", registerRequest);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var content = await response.Content.ReadAsStringAsync();
        content.Should().NotBeEmpty();
    }

    [Fact]
    public async Task Register_WithDuplicateUsername_ShouldFail()
    {
        // Arrange
        var registerRequest = new
        {
            Username = "testadmin", // This already exists from seeded data
            Email = "duplicate@example.com",
            Password = "TestPass123!",
            FirstName = "Duplicate",
            LastName = "User",
            Role = "Employee"
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/auth/register", registerRequest);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task Login_WithValidCredentials_ShouldReturnToken()
    {
        // Arrange
        var loginRequest = new
        {
            Username = "testadmin",
            Password = "TestPass123!"
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/auth/login", loginRequest);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var content = await response.Content.ReadAsStringAsync();
        
        using var doc = JsonDocument.Parse(content);
        doc.RootElement.TryGetProperty("token", out var tokenElement).Should().BeTrue();
        tokenElement.GetString().Should().NotBeNullOrEmpty();
    }

    [Fact]
    public async Task Login_WithInvalidCredentials_ShouldFail()
    {
        // Arrange
        var loginRequest = new
        {
            Username = "testadmin",
            Password = "WrongPassword"
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/auth/login", loginRequest);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task Login_WithNonexistentUser_ShouldFail()
    {
        // Arrange
        var loginRequest = new
        {
            Username = "nonexistentuser",
            Password = "SomePassword123!"
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/auth/login", loginRequest);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Theory]
    [InlineData("", "test@example.com", "TestPass123!", "First", "Last", "Employee")] // Empty username
    [InlineData("testuser", "", "TestPass123!", "First", "Last", "Employee")] // Empty email
    [InlineData("testuser", "invalid-email", "TestPass123!", "First", "Last", "Employee")] // Invalid email
    [InlineData("testuser", "test@example.com", "weak", "First", "Last", "Employee")] // Weak password
    [InlineData("testuser", "test@example.com", "TestPass123!", "", "Last", "Employee")] // Empty first name
    [InlineData("testuser", "test@example.com", "TestPass123!", "First", "", "Employee")] // Empty last name
    public async Task Register_WithInvalidData_ShouldFail(
        string username, string email, string password, 
        string firstName, string lastName, string role)
    {
        // Arrange
        var registerRequest = new
        {
            Username = username,
            Email = email,
            Password = password,
            FirstName = firstName,
            LastName = lastName,
            Role = role
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/auth/register", registerRequest);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }
}
