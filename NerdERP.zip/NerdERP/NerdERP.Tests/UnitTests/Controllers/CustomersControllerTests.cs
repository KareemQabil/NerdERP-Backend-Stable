using Microsoft.AspNetCore.Mvc;
using Moq;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Customers;
using NerdERP.Services.Customers;
using NerdERP.WebApi.Controllers;
using FluentAssertions;
using Xunit;

namespace NerdERP.Tests.UnitTests.Controllers;

public class CustomersControllerTests
{
    private readonly Mock<ICustomerService> _mockCustomerService;
    private readonly CustomersController _controller;

    public CustomersControllerTests()
    {
        _mockCustomerService = new Mock<ICustomerService>();
        _controller = new CustomersController(_mockCustomerService.Object);
    }

    [Fact]
    public async Task CreateCustomer_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var request = new CreateCustomerRequest
        {
            FirstName = "John",
            LastName = "Doe",
            Email = "john.doe@email.com",
            Phone = "123-456-7890",
            Address = "123 Main Street",
            City = "Test City",
            PostalCode = "12345"
        };

        var expectedResponse = new CustomerResponse
        {
            Id = 1,
            FirstName = "John",
            LastName = "Doe",
            Email = "john.doe@email.com",
            Phone = "123-456-7890",
            Address = "123 Main Street",
            City = "Test City",
            PostalCode = "12345",
            IsActive = true,
            CreatedDate = DateTime.UtcNow,
            TotalPurchases = 0
        };

        var serviceResponse = ServiceResponse<CustomerResponse>.CreateSuccess(expectedResponse);
        _mockCustomerService.Setup(s => s.CreateAsync(It.IsAny<CreateCustomerRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Create(request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockCustomerService.Verify(s => s.CreateAsync(request), Times.Once);
    }

    [Fact]
    public async Task CreateCustomer_WithInvalidRequest_ShouldReturnBadRequest()
    {
        // Arrange
        var request = new CreateCustomerRequest
        {
            FirstName = "", // Invalid - empty first name
            LastName = "Doe",
            Email = "john.doe@email.com"
        };

        var serviceResponse = ServiceResponse<CustomerResponse>.CreateFailure("First name is required.", 400);
        _mockCustomerService.Setup(s => s.CreateAsync(It.IsAny<CreateCustomerRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Create(request);

        // Assert
        result.Should().BeOfType<BadRequestObjectResult>();
        var badRequestResult = result as BadRequestObjectResult;
        badRequestResult!.Value.Should().Be(serviceResponse);
    }

    [Fact]
    public async Task GetCustomer_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var customerId = 1;
        var expectedCustomer = new CustomerResponse
        {
            Id = customerId,
            FirstName = "John",
            LastName = "Doe",
            Email = "john.doe@email.com",
            Phone = "123-456-7890",
            IsActive = true,
            CreatedDate = DateTime.UtcNow,
            TotalPurchases = 250.75m
        };

        var serviceResponse = ServiceResponse<CustomerResponse>.CreateSuccess(expectedCustomer);
        _mockCustomerService.Setup(s => s.GetByIdAsync(customerId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Get(customerId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockCustomerService.Verify(s => s.GetByIdAsync(customerId), Times.Once);
    }

    [Fact]
    public async Task GetCustomer_WithInvalidId_ShouldReturnNotFound()
    {
        // Arrange
        var customerId = 999;
        var serviceResponse = ServiceResponse<CustomerResponse>.CreateFailure("Customer not found.", 404);
        _mockCustomerService.Setup(s => s.GetByIdAsync(customerId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Get(customerId);

        // Assert
        result.Should().BeOfType<NotFoundObjectResult>();
        var notFoundResult = result as NotFoundObjectResult;
        notFoundResult!.Value.Should().Be(serviceResponse);
    }

    [Fact]
    public async Task UpdateCustomer_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var customerId = 1;
        var request = new UpdateCustomerRequest
        {
            FirstName = "Jane",
            LastName = "Smith",
            Email = "jane.smith@email.com",
            Phone = "987-654-3210",
            Address = "456 Oak Avenue",
            City = "Updated City",
            PostalCode = "54321",
            IsActive = true
        };

        var expectedResponse = new CustomerResponse
        {
            Id = 1,
            FirstName = "Jane",
            LastName = "Smith",
            Email = "jane.smith@email.com",
            Phone = "987-654-3210",
            Address = "456 Oak Avenue",
            City = "Updated City",
            PostalCode = "54321",
            IsActive = true,
            CreatedDate = DateTime.UtcNow.AddDays(-10),
            TotalPurchases = 500.25m
        };

        var serviceResponse = ServiceResponse<CustomerResponse>.CreateSuccess(expectedResponse);
        _mockCustomerService.Setup(s => s.UpdateAsync(customerId, It.IsAny<UpdateCustomerRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Update(customerId, request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockCustomerService.Verify(s => s.UpdateAsync(customerId, request), Times.Once);
    }

    [Fact]
    public async Task DeleteCustomer_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var customerId = 1;
        var serviceResponse = ServiceResponse<bool>.CreateSuccess(true);
        _mockCustomerService.Setup(s => s.DeleteAsync(customerId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Delete(customerId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockCustomerService.Verify(s => s.DeleteAsync(customerId), Times.Once);
    }

    [Fact]
    public async Task GetAllCustomersWithPaging_WithValidParameters_ShouldReturnOk()
    {
        // Arrange
        var pagingParams = new PagingAndSortingParams
        {
            PageNumber = 1,
            PageSize = 10,
            OrderBy = "FirstName",
            SortDir = "ASC"
        };

        var filterParams = new CustomerFilterParams
        {
            Name = "John",
            Email = "test",
            IsActive = true
        };

        var customers = new List<CustomerResponse>
        {
            new CustomerResponse
            {
                Id = 1,
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@email.com",
                IsActive = true,
                CreatedDate = DateTime.UtcNow,
                TotalPurchases = 250.75m
            },
            new CustomerResponse
            {
                Id = 2,
                FirstName = "John",
                LastName = "Smith",
                Email = "john.smith@email.com",
                IsActive = true,
                CreatedDate = DateTime.UtcNow.AddDays(-5),
                TotalPurchases = 150.50m
            }
        };

        var pagedResult = new PagedResult<CustomerResponse>
        {
            Data = customers,
            TotalRecords = 2,
            PageNumber = 1,
            PageSize = 10
        };

        var serviceResponse = ServiceResponse<PagedResult<CustomerResponse>>.CreateSuccess(pagedResult);
        _mockCustomerService.Setup(s => s.GetAllWithPagingAsync(
                It.IsAny<PagingAndSortingParams>(),
                It.IsAny<CustomerFilterParams>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.GetAllWithPaging(pagingParams, filterParams);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockCustomerService.Verify(s => s.GetAllWithPagingAsync(pagingParams, filterParams), Times.Once);
    }

    [Fact]
    public async Task GetCustomerByEmail_WithValidEmail_ShouldReturnOk()
    {
        // Arrange
        var email = "john.doe@email.com";
        var expectedCustomer = new CustomerResponse
        {
            Id = 1,
            FirstName = "John",
            LastName = "Doe",
            Email = email,
            IsActive = true,
            CreatedDate = DateTime.UtcNow,
            TotalPurchases = 250.75m
        };

        var serviceResponse = ServiceResponse<CustomerResponse>.CreateSuccess(expectedCustomer);
        _mockCustomerService.Setup(s => s.GetByEmailAsync(email))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.GetByEmail(email);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockCustomerService.Verify(s => s.GetByEmailAsync(email), Times.Once);
    }
}