using Microsoft.AspNetCore.Mvc;
using Moq;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Sales;
using NerdERP.Services.Sales;
using NerdERP.WebApi.Controllers;
using FluentAssertions;
using Xunit;

namespace NerdERP.Tests.UnitTests.Controllers;

public class SalesControllerTests
{
    private readonly Mock<ISaleService> _mockSaleService;
    private readonly SalesController _controller;

    public SalesControllerTests()
    {
        _mockSaleService = new Mock<ISaleService>();
        _controller = new SalesController(_mockSaleService.Object);
    }

    [Fact]
    public async Task CreateSale_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var request = new CreateSaleRequest
        {
            CustomerId = 1,
            UserId = 1,
            PaymentMethod = "Cash",
            Items = new List<CreateSaleItemRequest>
            {
                new CreateSaleItemRequest
                {
                    ProductId = 1,
                    Quantity = 2,
                    UnitPrice = 25.50m,
                    DiscountAmount = 1.00m
                }
            }
        };

        var expectedResponse = new SaleResponse
        {
            Id = 1,
            SaleNumber = "SALE-001",
            CustomerId = 1,
            UserId = 1,
            SubTotal = 50.00m,
            TaxAmount = 5.00m,
            DiscountAmount = 1.00m,
            TotalAmount = 54.00m,
            PaymentMethod = "Cash",
            Status = "Completed",
            SaleDate = DateTime.UtcNow
        };

        var serviceResponse = ServiceResponse<SaleResponse>.CreateSuccess(expectedResponse);
        _mockSaleService.Setup(s => s.CreateAsync(It.IsAny<CreateSaleRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Create(request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockSaleService.Verify(s => s.CreateAsync(request), Times.Once);
    }

    [Fact]
    public async Task GetSale_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var saleId = 1;
        var expectedSale = new SaleResponse
        {
            Id = saleId,
            SaleNumber = "SALE-001",
            CustomerId = 1,
            UserId = 1,
            TotalAmount = 54.00m,
            PaymentMethod = "Cash",
            Status = "Completed",
            SaleDate = DateTime.UtcNow
        };

        var serviceResponse = ServiceResponse<SaleResponse>.CreateSuccess(expectedSale);
        _mockSaleService.Setup(s => s.GetByIdAsync(saleId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Get(saleId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockSaleService.Verify(s => s.GetByIdAsync(saleId), Times.Once);
    }

    [Fact]
    public async Task GetSale_WithInvalidId_ShouldReturnNotFound()
    {
        // Arrange
        var saleId = 999;
        var serviceResponse = ServiceResponse<SaleResponse>.CreateFailure("Sale not found.", 404);
        _mockSaleService.Setup(s => s.GetByIdAsync(saleId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Get(saleId);

        // Assert
        result.Should().BeOfType<NotFoundObjectResult>();
        var notFoundResult = result as NotFoundObjectResult;
        notFoundResult!.Value.Should().Be(serviceResponse);
    }

    [Fact]
    public async Task GetAllSalesWithPaging_WithValidParameters_ShouldReturnOk()
    {
        // Arrange
        var pagingParams = new PagingAndSortingParams
        {
            PageNumber = 1,
            PageSize = 10,
            OrderBy = "SaleDate",
            SortDir = "DESC"
        };

        var filterParams = new SaleFilterParams
        {
            CustomerId = 1,
            PaymentMethod = "Cash",
            Status = "Completed"
        };

        var sales = new List<SaleResponse>
        {
            new SaleResponse
            {
                Id = 1,
                SaleNumber = "SALE-001",
                TotalAmount = 54.00m,
                PaymentMethod = "Cash",
                Status = "Completed",
                SaleDate = DateTime.UtcNow
            },
            new SaleResponse
            {
                Id = 2,
                SaleNumber = "SALE-002",
                TotalAmount = 32.50m,
                PaymentMethod = "Cash",
                Status = "Completed",
                SaleDate = DateTime.UtcNow.AddHours(-1)
            }
        };

        var pagedResult = new PagedResult<SaleResponse>
        {
            Data = sales,
            TotalRecords = 2,
            PageNumber = 1,
            PageSize = 10
        };

        var serviceResponse = ServiceResponse<PagedResult<SaleResponse>>.CreateSuccess(pagedResult);
        _mockSaleService.Setup(s => s.GetAllWithPagingAsync(
                It.IsAny<PagingAndSortingParams>(),
                It.IsAny<SaleFilterParams>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.GetAllWithPaging(pagingParams, filterParams);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockSaleService.Verify(s => s.GetAllWithPagingAsync(pagingParams, filterParams), Times.Once);
    }

    [Fact]
    public async Task GetTotalSalesAmount_WithDateRange_ShouldReturnOk()
    {
        // Arrange
        var startDate = DateTime.UtcNow.AddDays(-30);
        var endDate = DateTime.UtcNow;
        var expectedTotal = 1250.75m;

        var serviceResponse = ServiceResponse<decimal>.CreateSuccess(expectedTotal);
        _mockSaleService.Setup(s => s.GetTotalSalesAmountAsync(startDate, endDate))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.GetTotalSalesAmount(startDate, endDate);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockSaleService.Verify(s => s.GetTotalSalesAmountAsync(startDate, endDate), Times.Once);
    }
}