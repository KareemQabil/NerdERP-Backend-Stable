using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Categories;
using NerdERP.Services.Categories;
using NerdERP.WebApi.Controllers;
using Xunit;

namespace NerdERP.Tests.UnitTests.Controllers;

public class CategoriesControllerTests
{
    private readonly Mock<ICategoryService> _mockCategoryService;
    private readonly CategoriesController _controller;

    public CategoriesControllerTests()
    {
        _mockCategoryService = new Mock<ICategoryService>();
        _controller = new CategoriesController(_mockCategoryService.Object);
        _controller.ControllerContext = new ControllerContext()
        {
            HttpContext = new DefaultHttpContext()
        };
    }

    [Fact]
    public async Task Create_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var request = new CreateCategoryRequest { Name = "Test Category" };
        var response = new CategoryResponse { Id = 1, Name = "Test Category", IsActive = true };
        var serviceResponse = ServiceResponse<CategoryResponse>.CreateSuccess(response);
        _mockCategoryService.Setup(x => x.CreateAsync(request)).ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Create(request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
    }

    [Fact]
    public async Task Get_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var categoryId = 1;
        var response = new CategoryResponse { Id = categoryId, Name = "Test Category", IsActive = true };
        var serviceResponse = ServiceResponse<CategoryResponse>.CreateSuccess(response);
        _mockCategoryService.Setup(x => x.GetByIdAsync(categoryId)).ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Get(categoryId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
    }
}
