using Microsoft.AspNetCore.Mvc;
using Moq;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Suppliers;
using NerdERP.Services.Suppliers;
using NerdERP.WebApi.Controllers;
using FluentAssertions;
using Xunit;

namespace NerdERP.Tests.UnitTests.Controllers;

public class SuppliersControllerTests
{
    private readonly Mock<ISupplierService> _mockSupplierService;
    private readonly SuppliersController _controller;

    public SuppliersControllerTests()
    {
        _mockSupplierService = new Mock<ISupplierService>();
        _controller = new SuppliersController(_mockSupplierService.Object);
    }

    [Fact]
    public async Task CreateSupplier_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var request = new CreateSupplierRequest
        {
            Name = "Test Supplier",
            ContactPerson = "John Doe",
            Email = "test@supplier.com",
            Phone = "123-456-7890",
            Address = "123 Test Street",
            City = "Test City",
            PostalCode = "12345"
        };

        var expectedResponse = new SupplierResponse
        {
            Id = 1,
            Name = "Test Supplier",
            ContactPerson = "John Doe",
            Email = "test@supplier.com",
            Phone = "123-456-7890",
            Address = "123 Test Street",
            City = "Test City",
            PostalCode = "12345",
            IsActive = true,
            CreatedDate = DateTime.UtcNow
        };

        var serviceResponse = ServiceResponse<SupplierResponse>.CreateSuccess(expectedResponse);
        _mockSupplierService.Setup(s => s.CreateAsync(It.IsAny<CreateSupplierRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Create(request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockSupplierService.Verify(s => s.CreateAsync(request), Times.Once);
    }

    [Fact]
    public async Task CreateSupplier_WithInvalidRequest_ShouldReturnBadRequest()
    {
        // Arrange
        var request = new CreateSupplierRequest
        {
            Name = "", // Invalid - empty name
            Email = "test@supplier.com"
        };

        var serviceResponse = ServiceResponse<SupplierResponse>.CreateFailure("Supplier name is required.", 400);
        _mockSupplierService.Setup(s => s.CreateAsync(It.IsAny<CreateSupplierRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Create(request);

        // Assert
        result.Should().BeOfType<BadRequestObjectResult>();
        var badRequestResult = result as BadRequestObjectResult;
        badRequestResult!.Value.Should().Be(serviceResponse);
    }

    [Fact]
    public async Task GetSupplier_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var supplierId = 1;
        var expectedSupplier = new SupplierResponse
        {
            Id = supplierId,
            Name = "Test Supplier",
            ContactPerson = "John Doe",
            Email = "test@supplier.com",
            IsActive = true,
            CreatedDate = DateTime.UtcNow
        };

        var serviceResponse = ServiceResponse<SupplierResponse>.CreateSuccess(expectedSupplier);
        _mockSupplierService.Setup(s => s.GetByIdAsync(supplierId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Get(supplierId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockSupplierService.Verify(s => s.GetByIdAsync(supplierId), Times.Once);
    }

    [Fact]
    public async Task GetSupplier_WithInvalidId_ShouldReturnNotFound()
    {
        // Arrange
        var supplierId = 999;
        var serviceResponse = ServiceResponse<SupplierResponse>.CreateFailure("Supplier not found.", 404);
        _mockSupplierService.Setup(s => s.GetByIdAsync(supplierId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Get(supplierId);

        // Assert
        result.Should().BeOfType<NotFoundObjectResult>();
        var notFoundResult = result as NotFoundObjectResult;
        notFoundResult!.Value.Should().Be(serviceResponse);
    }

    [Fact]
    public async Task UpdateSupplier_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var request = new UpdateSupplierRequest
        {
            Id = 1,
            Name = "Updated Supplier",
            ContactPerson = "Jane Doe",
            Email = "updated@supplier.com",
            Phone = "987-654-3210",
            Address = "456 Updated Street",
            City = "Updated City",
            PostalCode = "54321",
            IsActive = true
        };

        var expectedResponse = new SupplierResponse
        {
            Id = 1,
            Name = "Updated Supplier",
            ContactPerson = "Jane Doe",
            Email = "updated@supplier.com",
            Phone = "987-654-3210",
            Address = "456 Updated Street",
            City = "Updated City",
            PostalCode = "54321",
            IsActive = true,
            CreatedDate = DateTime.UtcNow.AddDays(-1)
        };

        var serviceResponse = ServiceResponse<SupplierResponse>.CreateSuccess(expectedResponse);
        _mockSupplierService.Setup(s => s.UpdateAsync(It.IsAny<UpdateSupplierRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Update(request.Id, request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockSupplierService.Verify(s => s.UpdateAsync(request), Times.Once);
    }

    [Fact]
    public async Task DeleteSupplier_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var supplierId = 1;
        var serviceResponse = ServiceResponse<bool>.CreateSuccess(true);
        _mockSupplierService.Setup(s => s.DeleteAsync(supplierId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Delete(supplierId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockSupplierService.Verify(s => s.DeleteAsync(supplierId), Times.Once);
    }

    [Fact]
    public async Task GetAllSuppliersWithPaging_WithValidParameters_ShouldReturnOk()
    {
        // Arrange
        var pagingParams = new PagingAndSortingParams
        {
            PageNumber = 1,
            PageSize = 10,
            OrderBy = "Name",
            SortDir = "ASC"
        };

        var filterParams = new SupplierFilterParams
        {
            SearchTerm = "Test",
            IsActive = true
        };

        var suppliers = new List<SupplierResponse>
        {
            new SupplierResponse
            {
                Id = 1,
                Name = "Test Supplier 1",
                Email = "test1@supplier.com",
                IsActive = true,
                CreatedDate = DateTime.UtcNow
            },
            new SupplierResponse
            {
                Id = 2,
                Name = "Test Supplier 2",
                Email = "test2@supplier.com",
                IsActive = true,
                CreatedDate = DateTime.UtcNow
            }
        };

        var pagedResult = new PagedResult<SupplierResponse>
        {
            Data = suppliers,
            TotalRecords = 2,
            PageNumber = 1,
            PageSize = 10
        };

        var serviceResponse = ServiceResponse<PagedResult<SupplierResponse>>.CreateSuccess(pagedResult);
        _mockSupplierService.Setup(s => s.GetAllWithPagingAsync(
                It.IsAny<PagingAndSortingParams>(),
                It.IsAny<SupplierFilterParams>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.GetAllWithPaging(pagingParams, filterParams);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockSupplierService.Verify(s => s.GetAllWithPagingAsync(pagingParams, filterParams), Times.Once);
    }
}