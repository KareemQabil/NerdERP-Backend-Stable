using Microsoft.AspNetCore.Mvc;
using Moq;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Tables;
using NerdERP.Services.Tables;
using NerdERP.WebApi.Controllers;
using FluentAssertions;
using Xunit;

namespace NerdERP.Tests.UnitTests.Controllers;

public class TablesControllerTests
{
    private readonly Mock<ITableService> _mockTableService;
    private readonly TablesController _controller;

    public TablesControllerTests()
    {
        _mockTableService = new Mock<ITableService>();
        _controller = new TablesController(_mockTableService.Object);
    }

    [Fact]
    public async Task CreateTable_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var request = new CreateTableRequest
        {
            TableNumber = "T001",
            TableName = "Table 1",
            Capacity = 4,
            Location = "Main Floor",
            Description = "Window table",
            IsActive = true
        };

        var expectedResponse = new TableResponse
        {
            Id = 1,
            TableNumber = "T001",
            TableName = "Table 1",
            Capacity = 4,
            Location = "Main Floor",
            Description = "Window table",
            IsActive = true,
            Status = TableStatus.Available,
            CreatedDate = DateTime.UtcNow
        };

        var serviceResponse = ServiceResponse<TableResponse>.CreateSuccess(expectedResponse);
        _mockTableService.Setup(s => s.CreateAsync(It.IsAny<CreateTableRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Create(request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockTableService.Verify(s => s.CreateAsync(request), Times.Once);
    }

    [Fact]
    public async Task GetTable_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var tableId = 1;
        var expectedTable = new TableResponse
        {
            Id = 1,
            TableNumber = "T001",
            TableName = "Table 1",
            Capacity = 4,
            Location = "Main Floor",
            IsActive = true,
            Status = TableStatus.Available,
            CreatedDate = DateTime.UtcNow
        };

        var serviceResponse = ServiceResponse<TableResponse>.CreateSuccess(expectedTable);
        _mockTableService.Setup(s => s.GetByIdAsync(tableId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Get(tableId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockTableService.Verify(s => s.GetByIdAsync(tableId), Times.Once);
    }

    [Fact]
    public async Task GetTable_WithInvalidId_ShouldReturnNotFound()
    {
        // Arrange
        var tableId = 999;
        var serviceResponse = ServiceResponse<TableResponse>.CreateFailure("Table not found.", 404);
        _mockTableService.Setup(s => s.GetByIdAsync(tableId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Get(tableId);

        // Assert
        result.Should().BeOfType<NotFoundObjectResult>();
        var notFoundResult = result as NotFoundObjectResult;
        notFoundResult!.Value.Should().Be(serviceResponse);
    }

    [Fact]
    public async Task UpdateTable_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var tableId = 1;
        var request = new UpdateTableRequest
        {
            TableNumber = "T001",
            TableName = "Updated Table 1",
            Capacity = 6,
            Location = "VIP Section",
            Description = "Updated description",
            IsActive = true
        };

        var expectedResponse = new TableResponse
        {
            Id = 1,
            TableNumber = "T001",
            TableName = "Updated Table 1",
            Capacity = 6,
            Location = "VIP Section",
            Description = "Updated description",
            IsActive = true,
            Status = TableStatus.Available,
            CreatedDate = DateTime.UtcNow.AddDays(-1)
        };

        var serviceResponse = ServiceResponse<TableResponse>.CreateSuccess(expectedResponse);
        _mockTableService.Setup(s => s.UpdateAsync(tableId, It.IsAny<UpdateTableRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Update(tableId, request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockTableService.Verify(s => s.UpdateAsync(tableId, request), Times.Once);
    }

    [Fact]
    public async Task DeleteTable_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var tableId = 1;
        var serviceResponse = ServiceResponse<bool>.CreateSuccess(true);
        _mockTableService.Setup(s => s.DeleteAsync(tableId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.Delete(tableId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockTableService.Verify(s => s.DeleteAsync(tableId), Times.Once);
    }

    [Fact]
    public async Task GetAvailableTables_ShouldReturnOk()
    {
        // Arrange
        var capacity = 4;
        var expectedTables = new List<TableResponse>
        {
            new TableResponse
            {
                Id = 1,
                TableNumber = "T001",
                Capacity = 4,
                Status = TableStatus.Available,
                IsActive = true
            },
            new TableResponse
            {
                Id = 2,
                TableNumber = "T002",
                Capacity = 6,
                Status = TableStatus.Available,
                IsActive = true
            }
        };

        var serviceResponse = ServiceResponse<List<TableResponse>>.CreateSuccess(expectedTables);
        _mockTableService.Setup(s => s.GetAvailableTablesAsync(capacity))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.GetAvailableTables(capacity);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockTableService.Verify(s => s.GetAvailableTablesAsync(capacity), Times.Once);
    }

    [Fact]
    public async Task OccupyTable_WithValidIds_ShouldReturnOk()
    {
        // Arrange
        var tableId = 1;
        var saleId = 100;
        var serviceResponse = ServiceResponse<bool>.CreateSuccess(true);
        _mockTableService.Setup(s => s.OccupyTableAsync(tableId, saleId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.OccupyTable(tableId, saleId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockTableService.Verify(s => s.OccupyTableAsync(tableId, saleId), Times.Once);
    }

    [Fact]
    public async Task ReleaseTable_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var tableId = 1;
        var serviceResponse = ServiceResponse<bool>.CreateSuccess(true);
        _mockTableService.Setup(s => s.ReleaseTableAsync(tableId))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.ReleaseTable(tableId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockTableService.Verify(s => s.ReleaseTableAsync(tableId), Times.Once);
    }

    [Fact]
    public async Task CreateReservation_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var tableId = 1;
        var request = new ReserveTableRequest
        {
            CustomerId = 1,
            CustomerName = "John Doe",
            CustomerPhone = "123-456-7890",
            ReservationTime = DateTime.UtcNow.AddHours(2),
            PartySize = 4,
            Notes = "Anniversary dinner"
        };

        var expectedResponse = new TableReservationResponse
        {
            Id = 1,
            TableId = tableId,
            TableNumber = "T001",
            CustomerId = 1,
            CustomerName = "John Doe",
            CustomerPhone = "123-456-7890",
            ReservationTime = request.ReservationTime.Value,
            PartySize = 4,
            Notes = "Anniversary dinner",
            Status = ReservationStatus.Pending,
            CreatedDate = DateTime.UtcNow
        };

        var serviceResponse = ServiceResponse<TableReservationResponse>.CreateSuccess(expectedResponse);
        _mockTableService.Setup(s => s.CreateReservationAsync(tableId, It.IsAny<ReserveTableRequest>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.CreateReservation(tableId, request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockTableService.Verify(s => s.CreateReservationAsync(tableId, request), Times.Once);
    }

    [Fact]
    public async Task GetAllTablesWithPaging_WithValidParameters_ShouldReturnOk()
    {
        // Arrange
        var pagingParams = new PagingAndSortingParams
        {
            PageNumber = 1,
            PageSize = 10,
            OrderBy = "tableNumber",
            SortDir = "ASC"
        };

        var filterParams = new TableFilterParams
        {
            Status = TableStatus.Available,
            IsActive = true
        };

        var expectedTables = new List<TableResponse>
        {
            new TableResponse { Id = 1, TableNumber = "T001", Status = TableStatus.Available },
            new TableResponse { Id = 2, TableNumber = "T002", Status = TableStatus.Available }
        };

        var pagedResult = new PagedResult<TableResponse>
        {
            Data = expectedTables,
            TotalRecords = 2,
            PageNumber = 1,
            PageSize = 10
        };

        var serviceResponse = ServiceResponse<PagedResult<TableResponse>>.CreateSuccess(pagedResult);
        _mockTableService.Setup(s => s.GetAllWithPagingAsync(It.IsAny<PagingAndSortingParams>(), It.IsAny<TableFilterParams>()))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.GetAllWithPaging(pagingParams, filterParams);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
        var okResult = result as OkObjectResult;
        okResult!.Value.Should().Be(serviceResponse);

        _mockTableService.Verify(s => s.GetAllWithPagingAsync(pagingParams, filterParams), Times.Once);
    }
}