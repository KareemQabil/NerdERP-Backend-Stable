using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NerdERP.Core.Models.Common;
using NerdERP.Core.Models.Schema.Products;
using NerdERP.Services.Products;
using NerdERP.WebApi.Controllers;
using Xunit;

namespace NerdERP.Tests.UnitTests.Controllers;

public class ProductsControllerTests
{
    private readonly Mock<IProductService> _mockProductService;
    private readonly ProductsController _controller;

    public ProductsControllerTests()
    {
        _mockProductService = new Mock<IProductService>();
        _controller = new ProductsController(_mockProductService.Object);
        _controller.ControllerContext = new ControllerContext()
        {
            HttpContext = new DefaultHttpContext()
        };
    }

    [Fact]
    public async Task CreateProduct_WithValidRequest_ShouldReturnOk()
    {
        // Arrange
        var request = new CreateProductRequest
        {
            Name = "Test Product",
            SKU = "TEST001",
            Barcode = "123456789",
            CategoryId = 1,
            CostPrice = 10.00m,
            SellingPrice = 15.00m,
            CurrentStock = 100
        };

        var response = new ProductResponse
        {
            Id = 1,
            Name = "Test Product",
            IsActive = true
        };

        var serviceResponse = ServiceResponse<ProductResponse>.CreateSuccess(response);
        _mockProductService.Setup(x => x.CreateAsync(request)).ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.CreateProduct(request);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
    }

    [Fact]
    public async Task GetProduct_WithValidId_ShouldReturnOk()
    {
        // Arrange
        var productId = 1;
        var response = new ProductResponse { Id = productId, Name = "Test Product", IsActive = true };
        var serviceResponse = ServiceResponse<ProductResponse>.CreateSuccess(response);
        _mockProductService.Setup(x => x.GetByIdAsync(productId)).ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.GetProduct(productId);

        // Assert
        result.Should().BeOfType<OkObjectResult>();
    }

    [Fact]
    public async Task GetProduct_WithInvalidId_ShouldReturnNotFound()
    {
        // Arrange
        var productId = 999;
        var serviceResponse = ServiceResponse<ProductResponse>.CreateFailure("Product not found.", 404);
        _mockProductService.Setup(x => x.GetByIdAsync(productId)).ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.GetProduct(productId);

        // Assert
        result.Should().BeOfType<NotFoundObjectResult>();
    }
}
