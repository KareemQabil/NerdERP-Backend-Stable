# NerdERP - Modular Enterprise Resource Planning System

![.NET](https://img.shields.io/badge/.NET-8.0-512BD4?style=flat-square&logo=dotnet)
![SQL Server](https://img.shields.io/badge/SQL%20Server-2022-CC2927?style=flat-square&logo=microsoftsqlserver)
![Docker](https://img.shields.io/badge/Docker-Containerized-2496ED?style=flat-square&logo=docker)
![Swagger](https://img.shields.io/badge/Swagger-API%20Docs-85EA2D?style=flat-square&logo=swagger)

A comprehensive, modular ERP system built with .NET 8 that can be configured for different business types including retail stores, restaurants, manufacturing, services, and warehouses.

## 🌟 Features

### Core Business Modules
- **🛍️ Products & Inventory** - Complete product catalog with SKU management, stock tracking, and categorization
- **� Sales Management** - Transaction processing with multiple order types (DineIn, Takeaway, Online)
- **👥 Customer Relationship Management** - Customer profiles, contact management, and purchase history
- **🏭 Supplier Management** - Vendor profiles and procurement integration
- **� Purchase Orders** - Complete supply chain management with receiving workflow
- **🍽️ Table Management** - Restaurant table management with reservations (Hospitality module)
- **�️ Role-Based Access Control** - Granular permissions system with custom role creation

### System Features
- **🔧 Modular Architecture** - Enable/disable modules based on business type
- **🔐 JWT Authentication** - Secure API access with role-based authorization
- **🐳 Docker Containerization** - Easy deployment with Docker Compose
- **📖 API Documentation** - Complete Swagger/OpenAPI documentation
- **🗄️ Entity Framework Core** - Code-first database approach with migrations
- **🧪 Unit Testing** - Comprehensive test coverage

## 🏗️ Architecture

### Clean Architecture Pattern
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Presentation  │    │   Application   │    │   Infrastructure│
│   (WebApi)      │───▶│   (Services)    │───▶│   (Data Layer)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Core Domain (Entities & DTOs)               │
└─────────────────────────────────────────────────────────────────┘
```

### Module Structure
- **NerdERP.Core** - Domain entities, DTOs, and business models
- **NerdERP.Infrastructure** - Data access, Entity Framework, migrations
- **NerdERP.Services** - Business logic and application services
- **NerdERP.WebApi** - REST API controllers and endpoints
- **NerdERP.Tests** - Unit and integration tests

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- .NET 8 SDK (for development)
- SQL Server (handled by Docker)

### Using Docker (Recommended)
```bash
# Clone the repository
git clone https://github.com/KareemQabil/NerdERP-Stable.git
cd NerdERP-Stable

# Start the application
docker-compose up -d

# Access the API documentation
# Open http://localhost:5000/swagger in your browser
```

### Local Development
```bash
# Restore dependencies
dotnet restore

# Apply database migrations
dotnet ef database update --project NerdERP.Infrastructure --startup-project NerdERP.WebApi

# Run the application
dotnet run --project NerdERP.WebApi

# Access Swagger UI at https://localhost:5001/swagger
```

## � Default Credentials

| Username | Password | Role |
|----------|----------|------|
| admin | Admin123! | Administrator |
| manager1 | Manager123! | Manager |
| cashier1 | Cashier123! | Cashier |

### Prerequisites
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- [Docker Desktop](https://www.docker.com/products/docker-desktop)
- [Git](https://git-scm.com/)

### 1. Clone the Repository
```bash
git clone https://github.com/KareemQabil/NerdERP-backend.git
cd NerdERP-backend
```

### 2. Start with Docker (Recommended)
```bash
# Start all services (API + SQL Server)
docker-compose up -d

# View logs
docker-compose logs -f
```

### 3. Access the Application
- **API Documentation**: http://localhost:5000/swagger
- **Health Check**: http://localhost:5000/api/health

### 4. Default Login Credentials
```
Username: admin
Password: Admin123!
```

## 📖 API Documentation

### Authentication
First, obtain a JWT token:
```bash
curl -X POST "http://localhost:5000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"Admin123!"}'
```

### Example API Calls

#### Products
```bash
# Get all products
curl -X GET "http://localhost:5000/api/products" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"

# Create a product
curl -X POST "http://localhost:5000/api/products" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"New Product","sku":"SKU001","price":29.99,"categoryId":1}'
```

#### Sales
```bash
# Create a sale
curl -X POST "http://localhost:5000/api/sales" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"customerId":1,"items":[{"productId":1,"quantity":2,"unitPrice":15.99}]}'
```

## 🏢 Business Configurations

### Retail Store
**Enabled**: Products, Categories, Sales, Customers, Suppliers, Purchase Orders, Roles  
**Use Case**: Traditional retail with inventory and sales management

### Restaurant/Cafe
**Enabled**: All modules including Tables for seating management  
**Use Case**: Full-service restaurants with reservations and table management

### Manufacturing
**Enabled**: Products, Categories, Suppliers, Purchase Orders, Roles  
**Use Case**: Manufacturing operations focused on procurement and inventory

### Service Business
**Enabled**: Sales, Customers, Roles  
**Use Case**: Consulting, repair services, or other service-based businesses

### Warehouse/Distribution
**Enabled**: Products, Categories, Suppliers, Purchase Orders, Roles  
**Use Case**: Warehousing and distribution with heavy inventory focus

## 🛠️ Development

### Local Development Setup
```bash
# Restore dependencies
dotnet restore

# Apply database migrations
dotnet ef database update --project NerdERP.Infrastructure --startup-project NerdERP.WebApi

# Run the API
dotnet run --project NerdERP.WebApi
```

### Running Tests
```bash
# Run all tests
dotnet test

# Run specific test project
dotnet test NerdERP.Tests
```

### Database Migrations
```bash
# Create a new migration
dotnet ef migrations add MigrationName --project NerdERP.Infrastructure --startup-project NerdERP.WebApi

# Update database
dotnet ef database update --project NerdERP.Infrastructure --startup-project NerdERP.WebApi
```

## 🔐 Security & Permissions

### Role-Based Access Control
The system includes a comprehensive permission system with 45+ granular permissions:

- **Module-Based**: Each module has Create, Read, Update, Delete permissions
- **Action-Specific**: Special permissions like `PurchaseOrders.Receive`
- **Custom Roles**: Create roles with specific permission combinations

### Default Roles
- **Administrator**: Full system access
- **Manager**: Most permissions excluding user/role management
- **Sales Staff**: Sales, customers, products (read-only), tables
- **Inventory Staff**: Products, categories, suppliers, purchase orders
- **Cashier**: Limited sales and product read access

## 📊 Sample Data

The system comes with pre-seeded data for immediate testing:
- **7 Products**: Various categories (beverages, main courses, desserts)
- **5 Categories**: Food and beverage classifications
- **3 Customers**: Sample customer profiles
- **3 Suppliers**: Vendor profiles for procurement
- **10 Tables**: Restaurant seating arrangements
- **45+ Permissions**: Complete permission matrix
- **5 Default Roles**: Ready-to-use role configurations

## 🐳 Docker Deployment

### Production Deployment
```bash
# Build and start services
docker-compose -f docker-compose.yml up -d

# Scale API instances
docker-compose up -d --scale nerderp-api=3

# Monitor services
docker-compose ps
docker-compose logs
```

### Environment Variables
```env
ASPNETCORE_ENVIRONMENT=Production
ConnectionStrings__DefaultConnection=Server=sqlserver;Database=NerdERP;User Id=sa;Password=YourPassword123!;TrustServerCertificate=true;
JwtConfig__Secret=YourSecretKey
JwtConfig__Issuer=NerdERP
JwtConfig__Audience=NerdERP
```

## 📝 Documentation

- **[Modular Architecture Guide](./MODULAR-ARCHITECTURE-GUIDE.md)**: Complete implementation guide
- **[API Documentation](http://localhost:5000/swagger)**: Interactive Swagger UI
- **[Testing Guide](./TESTING-GUIDE.md)**: Comprehensive testing documentation

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines
- Follow clean architecture principles
- Maintain test coverage above 80%
- Use consistent naming conventions
- Document public APIs
- Create migrations for database changes

## 🔄 Roadmap

### Version 2.0
- [ ] Multi-tenant support
- [ ] Advanced reporting module
- [ ] Mobile API optimizations
- [ ] Real-time notifications
- [ ] Advanced inventory management

### Version 2.1
- [ ] Import/Export functionality
- [ ] Advanced user management
- [ ] Audit logging
- [ ] Performance optimizations

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

### Getting Help
- **Issues**: [GitHub Issues](https://github.com/KareemQabil/NerdERP-backend/issues)
- **Documentation**: Check the `/swagger` endpoint for API docs
- **Architecture**: See [MODULAR-ARCHITECTURE-GUIDE.md](./MODULAR-ARCHITECTURE-GUIDE.md)

### Common Issues
1. **Docker not starting**: Ensure Docker Desktop is running
2. **Database connection errors**: Check SQL Server container status
3. **Authentication failures**: Verify JWT token in Authorization header
4. **Permission denied**: Check user role and assigned permissions

## 🎯 Use Cases

### Small Business (Retail Store)
- Product catalog management
- Sales tracking
- Customer relationships
- Supplier management
- Purchase order processing

### Restaurant Operations
- Menu item management
- Table reservations
- Order processing
- Customer profiles
- Ingredient procurement
- Seating management

### Manufacturing
- Raw material tracking
- Supplier relationships
- Purchase order management
- Inventory control
- Production planning support

### Service Business
- Client management
- Service order tracking
- Basic inventory (if applicable)
- Customer relationship management

---

**Built with ❤️ using .NET 8, Entity Framework Core, and Docker**

*Ready for production deployment and customization for any business type!*