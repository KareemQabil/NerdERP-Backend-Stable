# NerdERP Modular Architecture Guide

## Overview

NerdERP is designed as a modular Enterprise Resource Planning (ERP) system that can be configured for different business types. Each module represents a specific business function and can be enabled or disabled based on client requirements.

## Core Architecture

### Module Structure
Each module follows a consistent architecture:
- **Entities**: Data models in `NerdERP.Core/Models/Entities/`
- **DTOs**: Data Transfer Objects in `NerdERP.Core/Models/DTOs/`
- **Services**: Business logic in `NerdERP.Services/`
- **Controllers**: API endpoints in `NerdERP.WebApi/Controllers/`

### Database Integration
- Entity Framework Core with SQL Server
- Migrations for schema versioning
- Seeding for initial data setup
- Foreign key relationships between modules

## Available Modules

### 1. Products Module
**Purpose**: Inventory and product catalog management
**Use Cases**: All business types
**Key Features**:
- Product CRUD operations
- SKU management
- Stock tracking
- Price management
- Category integration

**API Endpoints**:
- `GET /api/products` - List all products
- `POST /api/products` - Create new product
- `PUT /api/products/{id}` - Update product
- `DELETE /api/products/{id}` - Delete product

### 2. Categories Module
**Purpose**: Product classification and organization
**Use Cases**: Retail, Manufacturing, Hospitality
**Key Features**:
- Hierarchical categorization
- Category-based filtering
- Product organization

**API Endpoints**:
- `GET /api/categories` - List categories
- `POST /api/categories` - Create category
- `PUT /api/categories/{id}` - Update category

### 3. Sales Module
**Purpose**: Transaction processing and order management
**Use Cases**: All business types
**Key Features**:
- Order creation and management
- Multiple order types (DineIn, Takeaway, Online)
- Customer integration
- Table integration (hospitality)
- Payment tracking

**API Endpoints**:
- `POST /api/sales` - Create sale
- `GET /api/sales/GetAllWithPaging` - List sales
- `GET /api/sales/{id}` - Get sale details

### 4. Customers Module
**Purpose**: Customer relationship management (CRM)
**Use Cases**: Retail, Services, Hospitality
**Key Features**:
- Customer profiles
- Contact management
- Purchase history
- Loyalty tracking

**API Endpoints**:
- `POST /api/customers` - Create customer
- `GET /api/customers/GetAllWithPaging` - List customers
- `PUT /api/customers/{id}` - Update customer

### 5. Suppliers Module
**Purpose**: Vendor and supplier management
**Use Cases**: Manufacturing, Retail, Hospitality
**Key Features**:
- Supplier profiles
- Contact management
- Purchase order integration
- Vendor performance tracking

**API Endpoints**:
- `POST /api/suppliers` - Create supplier
- `GET /api/suppliers/GetAllWithPaging` - List suppliers
- `PUT /api/suppliers/{id}` - Update supplier

### 6. Purchase Orders Module
**Purpose**: Procurement and supply chain management
**Use Cases**: Manufacturing, Retail, Hospitality
**Key Features**:
- Purchase order creation
- Multi-item orders
- Receiving workflow
- Inventory updates
- Supplier integration

**API Endpoints**:
- `POST /api/purchaseorders` - Create purchase order
- `GET /api/purchaseorders` - List purchase orders
- `POST /api/purchaseorders/{id}/receive` - Receive items

### 7. Tables Module (Hospitality)
**Purpose**: Table and seating management
**Use Cases**: Restaurants, Hotels, Cafes
**Key Features**:
- Table configuration
- Reservation system
- Occupancy tracking
- Sales integration
- Multiple locations/sections

**API Endpoints**:
- `POST /api/tables/Create` - Create table
- `POST /api/tables/GetAllWithPaging` - List tables
- `POST /api/tables/CreateReservation/{tableId}` - Make reservation
- `GET /api/tables/GetAvailableTables` - Check availability

### 8. Roles Module (Administration)
**Purpose**: Role-based access control and permissions
**Use Cases**: All business types
**Key Features**:
- Custom role creation
- Granular permissions by module and action
- User assignment
- Security management

**API Endpoints**:
- `POST /api/roles` - Create role
- `GET /api/roles/permissions` - List all permissions
- `POST /api/roles/{roleId}/permissions` - Assign permissions
- `GET /api/roles/check-permission` - Check user permissions

## Business Type Configurations

### Retail Store Configuration
**Enabled Modules**:
- Products ✅
- Categories ✅
- Sales ✅
- Customers ✅
- Suppliers ✅
- Purchase Orders ✅
- Roles ✅

**Disabled Modules**:
- Tables ❌ (Not applicable)

**Use Case**: Traditional retail operations with inventory, sales, and customer management.

### Restaurant/Cafe Configuration
**Enabled Modules**:
- Products ✅ (Menu items)
- Categories ✅ (Food categories)
- Sales ✅ (Orders)
- Customers ✅ (Customer profiles)
- Suppliers ✅ (Food suppliers)
- Purchase Orders ✅ (Ingredient procurement)
- Tables ✅ (Seating management)
- Roles ✅

**Use Case**: Full-service restaurants with table management, reservations, and kitchen operations.

### Manufacturing Configuration
**Enabled Modules**:
- Products ✅ (Raw materials & finished goods)
- Categories ✅ (Material classification)
- Suppliers ✅ (Material suppliers)
- Purchase Orders ✅ (Material procurement)
- Roles ✅

**Disabled Modules**:
- Sales ❌ (Use specialized manufacturing sales)
- Customers ❌ (Use specialized B2B systems)
- Tables ❌ (Not applicable)

**Use Case**: Manufacturing operations focused on procurement and inventory management.

### Service Business Configuration
**Enabled Modules**:
- Sales ✅ (Service orders)
- Customers ✅ (Client management)
- Roles ✅

**Disabled Modules**:
- Products ❌ (Services, not physical products)
- Categories ❌ (Not applicable)
- Suppliers ❌ (Minimal procurement)
- Purchase Orders ❌ (Minimal procurement)
- Tables ❌ (Not applicable)

**Use Case**: Consulting, repair services, or other service-based businesses.

### Warehouse/Distribution Configuration
**Enabled Modules**:
- Products ✅ (Inventory items)
- Categories ✅ (Product classification)
- Suppliers ✅ (Product sources)
- Purchase Orders ✅ (Inventory procurement)
- Roles ✅

**Disabled Modules**:
- Sales ❌ (Use specialized B2B systems)
- Customers ❌ (Use specialized B2B systems)
- Tables ❌ (Not applicable)

**Use Case**: Warehousing and distribution operations with heavy inventory focus.

## Module Dependencies

### Core Dependencies
- **Authentication**: Required for all modules
- **Users**: Required for all modules
- **Roles**: Recommended for all business types

### Inter-Module Dependencies
- **Sales** → Products, Customers (optional: Tables)
- **Purchase Orders** → Products, Suppliers
- **Products** → Categories (optional)
- **Tables** → Sales (for order assignment)

## Implementation Guide

### 1. Module Selection
Choose modules based on business type:
```csharp
public class ModuleConfiguration
{
    public bool EnableProducts { get; set; }
    public bool EnableCategories { get; set; }
    public bool EnableSales { get; set; }
    public bool EnableCustomers { get; set; }
    public bool EnableSuppliers { get; set; }
    public bool EnablePurchaseOrders { get; set; }
    public bool EnableTables { get; set; }
    public bool EnableRoles { get; set; } = true; // Always enabled
}
```

### 2. Database Migration
Apply only relevant migrations:
```bash
# For retail configuration
dotnet ef database update --context ApplicationDbContext

# Tables are created but can be ignored if not using Tables module
```

### 3. Service Registration
Register only needed services in `Program.cs`:
```csharp
// Core services (always enabled)
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IRoleService, RoleService>();

// Conditional service registration
if (moduleConfig.EnableProducts)
    builder.Services.AddScoped<IProductService, ProductService>();

if (moduleConfig.EnableSales)
    builder.Services.AddScoped<ISaleService, SaleService>();

// ... other conditional registrations
```

### 4. API Endpoint Control
Control endpoint availability through configuration:
```csharp
[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    // Endpoints automatically available when service is registered
}
```

### 5. Frontend Module Control
Hide/show UI components based on module configuration:
```javascript
// Example frontend configuration
const moduleConfig = {
    enableProducts: true,
    enableTables: false,
    enableSuppliers: true
};

// Conditional menu rendering
{moduleConfig.enableTables && <TablesMenu />}
{moduleConfig.enableSuppliers && <SuppliersMenu />}
```

## Permission System

### Module-Based Permissions
Each module has standardized permissions:
- `{Module}.Create` - Create new records
- `{Module}.Read` - View records
- `{Module}.Update` - Modify existing records
- `{Module}.Delete` - Remove records
- `{Module}.{Special}` - Module-specific actions (e.g., `PurchaseOrders.Receive`)

### Role Templates
Pre-configured roles for common business scenarios:

**Administrator**: All permissions across all modules
**Manager**: Most permissions excluding user/role management
**Sales Staff**: Sales, Customers, Products (read-only), Tables
**Inventory Staff**: Products, Categories, Suppliers, Purchase Orders
**Cashier**: Sales (limited), Products (read-only)

## Deployment Considerations

### Environment Configuration
```json
{
  "ModuleConfiguration": {
    "EnableProducts": true,
    "EnableCategories": true,
    "EnableSales": true,
    "EnableCustomers": true,
    "EnableSuppliers": false,
    "EnablePurchaseOrders": false,
    "EnableTables": false
  }
}
```

### Database Optimization
- Unused tables can be ignored but will exist in schema
- Consider separate databases for completely different business types
- Use database views to expose only relevant data

### Performance Optimization
- Disable unused API endpoints at startup
- Implement lazy loading for unused modules
- Cache module configuration at application level

## Customization Options

### 1. Module Extension
Add custom fields to existing modules:
```csharp
public class ProductExtension
{
    public string CustomField1 { get; set; }
    public int CustomField2 { get; set; }
}
```

### 2. Custom Modules
Create new modules following the established pattern:
- Entities in Core layer
- Services in Services layer
- Controllers in WebApi layer
- Permissions in the permission system

### 3. Business Logic Customization
Override default services with business-specific implementations:
```csharp
builder.Services.AddScoped<ISaleService, RestaurantSaleService>();
```

## Migration Between Configurations

### Enabling New Modules
1. Update module configuration
2. Register additional services
3. Apply any new migrations
4. Update user permissions
5. Train users on new functionality

### Disabling Modules
1. Export critical data
2. Update module configuration
3. Remove service registrations
4. Update user permissions
5. Hide UI components

**Note**: Disabling modules doesn't delete data, only hides functionality.

## Support and Maintenance

### Module Health Monitoring
- Monitor API endpoint usage by module
- Track performance metrics per module
- Log module-specific errors

### Updates and Patches
- Module-specific updates possible
- Core system updates affect all modules
- Role-based access to admin functions

## Conclusion

The NerdERP modular architecture provides flexibility for businesses of all types while maintaining a consistent, professional ERP experience. The system can grow with the business by enabling additional modules as needed, making it suitable for both small startups and larger enterprises.

For technical support or custom module development, refer to the API documentation available at `/swagger` endpoint.