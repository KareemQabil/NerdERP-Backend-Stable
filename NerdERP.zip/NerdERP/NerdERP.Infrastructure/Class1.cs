﻿namespace NerdERP.Infrastructure;

public class Class1
{

}
