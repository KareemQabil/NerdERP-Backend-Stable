using Microsoft.EntityFrameworkCore;
using NerdERP.Core.Models.Entities;

namespace NerdERP.Infrastructure.Data;

public class ApplicationDbContext : DbContext
{
	public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

	public DbSet<User> Users { get; set; } = null!;
	public DbSet<Category> Categories { get; set; } = null!;
	public DbSet<Product> Products { get; set; } = null!;
	public DbSet<StockMovement> StockMovements { get; set; } = null!;
	public DbSet<Customer> Customers { get; set; } = null!;
	public DbSet<Supplier> Suppliers { get; set; } = null!;
	public DbSet<Sale> Sales { get; set; } = null!;
	public DbSet<SaleItem> SaleItems { get; set; } = null!;
	public DbSet<PurchaseOrder> PurchaseOrders { get; set; } = null!;
	public DbSet<PurchaseOrderItem> PurchaseOrderItems { get; set; } = null!;
	public DbSet<Table> Tables { get; set; } = null!;
	public DbSet<TableReservation> TableReservations { get; set; } = null!;

	// Role-based permissions
	public DbSet<Role> Roles { get; set; } = null!;
	public DbSet<Permission> Permissions { get; set; } = null!;
	public DbSet<RolePermission> RolePermissions { get; set; } = null!;

	protected override void OnModelCreating(ModelBuilder modelBuilder)
	{
		base.OnModelCreating(modelBuilder);

		// Configure decimal precision for money-related fields
		modelBuilder.Entity<Customer>()
			.Property(p => p.TotalPurchases)
			.HasPrecision(18, 2);

		modelBuilder.Entity<Product>(entity =>
		{
			entity.Property(p => p.CostPrice).HasPrecision(18, 2);
			entity.Property(p => p.SellingPrice).HasPrecision(18, 2);
		});

		modelBuilder.Entity<PurchaseOrder>(entity =>
		{
			entity.Property(p => p.SubTotal).HasPrecision(18, 2);
			entity.Property(p => p.TaxAmount).HasPrecision(18, 2);
			entity.Property(p => p.TotalAmount).HasPrecision(18, 2);
		});

		modelBuilder.Entity<PurchaseOrderItem>(entity =>
		{
			entity.Property(p => p.UnitCost).HasPrecision(18, 2);
			entity.Property(p => p.LineTotal).HasPrecision(18, 2);
		});

		modelBuilder.Entity<Sale>(entity =>
		{
			entity.Property(p => p.SubTotal).HasPrecision(18, 2);
			entity.Property(p => p.TaxAmount).HasPrecision(18, 2);
			entity.Property(p => p.DiscountAmount).HasPrecision(18, 2);
			entity.Property(p => p.TotalAmount).HasPrecision(18, 2);
		});

		modelBuilder.Entity<SaleItem>(entity =>
		{
			entity.Property(p => p.UnitPrice).HasPrecision(18, 2);
			entity.Property(p => p.DiscountAmount).HasPrecision(18, 2);
			entity.Property(p => p.LineTotal).HasPrecision(18, 2);
		});

		// Configure role-based permissions relationships
		modelBuilder.Entity<User>(entity =>
		{
			entity.HasOne(u => u.UserRole)
				.WithMany(r => r.Users)
				.HasForeignKey(u => u.RoleId)
				.OnDelete(DeleteBehavior.SetNull);
		});

		modelBuilder.Entity<RolePermission>(entity =>
		{
			entity.HasKey(rp => rp.Id);
			
			entity.HasOne(rp => rp.Role)
				.WithMany(r => r.RolePermissions)
				.HasForeignKey(rp => rp.RoleId)
				.OnDelete(DeleteBehavior.Cascade);

			entity.HasOne(rp => rp.Permission)
				.WithMany(p => p.RolePermissions)
				.HasForeignKey(rp => rp.PermissionId)
				.OnDelete(DeleteBehavior.Cascade);

			// Ensure unique role-permission combinations
			entity.HasIndex(rp => new { rp.RoleId, rp.PermissionId })
				.IsUnique();
		});
	}
}
