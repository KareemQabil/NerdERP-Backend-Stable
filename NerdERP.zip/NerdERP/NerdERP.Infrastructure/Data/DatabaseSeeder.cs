using Microsoft.EntityFrameworkCore;
using NerdERP.Core.Models.Entities;
using NerdERP.Core.Models.Schema.Tables;
using System.Security.Cryptography;
using System.Text;

namespace NerdERP.Infrastructure.Data;

public static class DatabaseSeeder
{
    public static async Task SeedAsync(ApplicationDbContext context)
    {
        // Ensure database is created
        await context.Database.EnsureCreatedAsync();

        // Seed Users
        if (!context.Users.Any())
        {
            var users = new List<User>
            {
                new User
                {
                    Username = "admin",
                    Email = "admin@nerderp.com",
                    PasswordHash = HashPassword("Admin123!"),
                    FirstName = "System",
                    LastName = "Administrator",
                    Role = "Admin",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new User
                {
                    Username = "cashier1",
                    Email = "cashier1@nerderp.com",
                    PasswordHash = HashPassword("Cashier123!"),
                    FirstName = "John",
                    LastName = "Doe",
                    Role = "Cashier",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new User
                {
                    Username = "manager1",
                    Email = "manager1@nerderp.com",
                    PasswordHash = HashPassword("Manager123!"),
                    FirstName = "Jane",
                    LastName = "Smith",
                    Role = "Manager",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                }
            };

            context.Users.AddRange(users);
            await context.SaveChangesAsync();
        }

        // Seed Categories
        if (!context.Categories.Any())
        {
            var categories = new List<Category>
            {
                new Category
                {
                    Name = "Beverages",
                    Description = "Hot and cold drinks",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Category
                {
                    Name = "Main Courses",
                    Description = "Primary dishes and entrees",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Category
                {
                    Name = "Appetizers",
                    Description = "Starters and small plates",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Category
                {
                    Name = "Desserts",
                    Description = "Sweet treats and desserts",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Category
                {
                    Name = "Sides",
                    Description = "Side dishes and accompaniments",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                }
            };

            context.Categories.AddRange(categories);
            await context.SaveChangesAsync();
        }

        // Seed Products
        if (!context.Products.Any())
        {
            var beverageCategory = context.Categories.First(c => c.Name == "Beverages");
            var mainCategory = context.Categories.First(c => c.Name == "Main Courses");
            var appetizerCategory = context.Categories.First(c => c.Name == "Appetizers");
            var dessertCategory = context.Categories.First(c => c.Name == "Desserts");
            var sidesCategory = context.Categories.First(c => c.Name == "Sides");

            var products = new List<Product>
            {
                // Beverages
                new Product
                {
                    Name = "Coffee",
                    Description = "Freshly brewed coffee",
                    SKU = "BEV001",
                    Barcode = "1234567890001",
                    CategoryId = beverageCategory.Id,
                    CostPrice = 1.50m,
                    SellingPrice = 3.50m,
                    CurrentStock = 100,
                    MinStockLevel = 20,
                    MaxStockLevel = 200,
                    Unit = "cups",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Product
                {
                    Name = "Coca Cola",
                    Description = "Refreshing cola drink",
                    SKU = "BEV002",
                    Barcode = "1234567890002",
                    CategoryId = beverageCategory.Id,
                    CostPrice = 0.80m,
                    SellingPrice = 2.50m,
                    CurrentStock = 150,
                    MinStockLevel = 30,
                    MaxStockLevel = 300,
                    Unit = "bottles",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                // Main Courses
                new Product
                {
                    Name = "Grilled Chicken",
                    Description = "Tender grilled chicken breast with herbs",
                    SKU = "MAIN001",
                    Barcode = "1234567890003",
                    CategoryId = mainCategory.Id,
                    CostPrice = 8.00m,
                    SellingPrice = 18.99m,
                    CurrentStock = 50,
                    MinStockLevel = 10,
                    MaxStockLevel = 100,
                    Unit = "plates",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Product
                {
                    Name = "Beef Burger",
                    Description = "Juicy beef burger with fries",
                    SKU = "MAIN002",
                    Barcode = "1234567890004",
                    CategoryId = mainCategory.Id,
                    CostPrice = 6.50m,
                    SellingPrice = 15.99m,
                    CurrentStock = 75,
                    MinStockLevel = 15,
                    MaxStockLevel = 150,
                    Unit = "plates",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                // Appetizers
                new Product
                {
                    Name = "Caesar Salad",
                    Description = "Fresh romaine lettuce with caesar dressing",
                    SKU = "APP001",
                    Barcode = "1234567890005",
                    CategoryId = appetizerCategory.Id,
                    CostPrice = 3.00m,
                    SellingPrice = 8.99m,
                    CurrentStock = 60,
                    MinStockLevel = 12,
                    MaxStockLevel = 120,
                    Unit = "plates",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                // Desserts
                new Product
                {
                    Name = "Chocolate Cake",
                    Description = "Rich chocolate cake slice",
                    SKU = "DES001",
                    Barcode = "1234567890006",
                    CategoryId = dessertCategory.Id,
                    CostPrice = 2.50m,
                    SellingPrice = 6.99m,
                    CurrentStock = 40,
                    MinStockLevel = 8,
                    MaxStockLevel = 80,
                    Unit = "slices",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                // Sides
                new Product
                {
                    Name = "French Fries",
                    Description = "Crispy golden french fries",
                    SKU = "SIDE001",
                    Barcode = "1234567890007",
                    CategoryId = sidesCategory.Id,
                    CostPrice = 1.20m,
                    SellingPrice = 4.99m,
                    CurrentStock = 80,
                    MinStockLevel = 16,
                    MaxStockLevel = 160,
                    Unit = "portions",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                }
            };

            context.Products.AddRange(products);
            await context.SaveChangesAsync();
        }

        // Seed Tables
        if (!context.Tables.Any())
        {
            var tables = new List<Table>
            {
                // Main Floor Tables
                new Table
                {
                    TableNumber = "T001",
                    TableName = "Window Table 1",
                    Capacity = 2,
                    Location = "Main Floor",
                    Description = "Small window table for 2",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                },
                new Table
                {
                    TableNumber = "T002",
                    TableName = "Window Table 2",
                    Capacity = 2,
                    Location = "Main Floor",
                    Description = "Small window table for 2",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                },
                new Table
                {
                    TableNumber = "T003",
                    TableName = "Center Table 1",
                    Capacity = 4,
                    Location = "Main Floor",
                    Description = "Regular 4-person table",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                },
                new Table
                {
                    TableNumber = "T004",
                    TableName = "Center Table 2",
                    Capacity = 4,
                    Location = "Main Floor",
                    Description = "Regular 4-person table",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                },
                new Table
                {
                    TableNumber = "T005",
                    TableName = "Large Table 1",
                    Capacity = 6,
                    Location = "Main Floor",
                    Description = "Large table for 6 people",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                },
                // VIP Section Tables
                new Table
                {
                    TableNumber = "V001",
                    TableName = "VIP Table 1",
                    Capacity = 4,
                    Location = "VIP Section",
                    Description = "Private VIP table",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                },
                new Table
                {
                    TableNumber = "V002",
                    TableName = "VIP Table 2",
                    Capacity = 6,
                    Location = "VIP Section",
                    Description = "Large VIP table",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                },
                // Outdoor Tables
                new Table
                {
                    TableNumber = "O001",
                    TableName = "Patio Table 1",
                    Capacity = 4,
                    Location = "Outdoor",
                    Description = "Outdoor patio table",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                },
                new Table
                {
                    TableNumber = "O002",
                    TableName = "Patio Table 2",
                    Capacity = 4,
                    Location = "Outdoor",
                    Description = "Outdoor patio table",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                },
                new Table
                {
                    TableNumber = "O003",
                    TableName = "Garden Table",
                    Capacity = 8,
                    Location = "Outdoor",
                    Description = "Large garden table for groups",
                    IsActive = true,
                    Status = TableStatus.Available,
                    CreatedDate = DateTime.UtcNow
                }
            };

            context.Tables.AddRange(tables);
            await context.SaveChangesAsync();
        }

        // Seed Customers
        if (!context.Customers.Any())
        {
            var customers = new List<Customer>
            {
                new Customer
                {
                    FirstName = "John",
                    LastName = "Customer",
                    Email = "john.customer@email.com",
                    Phone = "555-0101",
                    Address = "123 Main Street",
                    City = "Downtown",
                    PostalCode = "12345",
                    IsActive = true,
                    TotalPurchases = 0,
                    CreatedDate = DateTime.UtcNow
                },
                new Customer
                {
                    FirstName = "Sarah",
                    LastName = "Wilson",
                    Email = "sarah.wilson@email.com",
                    Phone = "555-0102",
                    Address = "456 Oak Avenue",
                    City = "Uptown",
                    PostalCode = "54321",
                    IsActive = true,
                    TotalPurchases = 0,
                    CreatedDate = DateTime.UtcNow
                },
                new Customer
                {
                    FirstName = "Michael",
                    LastName = "Brown",
                    Email = "michael.brown@email.com",
                    Phone = "555-0103",
                    Address = "789 Pine Road",
                    City = "Midtown",
                    PostalCode = "67890",
                    IsActive = true,
                    TotalPurchases = 0,
                    CreatedDate = DateTime.UtcNow
                }
            };

            context.Customers.AddRange(customers);
            await context.SaveChangesAsync();
        }

        // Seed Suppliers
        if (!context.Suppliers.Any())
        {
            var suppliers = new List<Supplier>
            {
                new Supplier
                {
                    Name = "Fresh Foods Distributor",
                    ContactPerson = "Robert Johnson",
                    Email = "orders@freshfoods.com",
                    Phone = "555-1001",
                    Address = "100 Warehouse District",
                    City = "Industrial Zone",
                    PostalCode = "98765",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Supplier
                {
                    Name = "Beverage Supply Co",
                    ContactPerson = "Lisa Chen",
                    Email = "sales@beveragesupply.com",
                    Phone = "555-1002",
                    Address = "200 Distribution Center",
                    City = "Commercial District",
                    PostalCode = "56789",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Supplier
                {
                    Name = "Quality Meats Inc",
                    ContactPerson = "David Miller",
                    Email = "info@qualitymeats.com",
                    Phone = "555-1003",
                    Address = "300 Meat Processing Way",
                    City = "Food District",
                    PostalCode = "34567",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                }
            };

            context.Suppliers.AddRange(suppliers);
            await context.SaveChangesAsync();
        }

        // Seed Permissions
        if (!context.Permissions.Any())
        {
            var permissions = new List<Permission>
            {
                // Products Module
                new Permission { Module = "Products", Action = "Create", Description = "Create new products", IsActive = true },
                new Permission { Module = "Products", Action = "Read", Description = "View products", IsActive = true },
                new Permission { Module = "Products", Action = "Update", Description = "Update existing products", IsActive = true },
                new Permission { Module = "Products", Action = "Delete", Description = "Delete products", IsActive = true },
                
                // Categories Module
                new Permission { Module = "Categories", Action = "Create", Description = "Create new categories", IsActive = true },
                new Permission { Module = "Categories", Action = "Read", Description = "View categories", IsActive = true },
                new Permission { Module = "Categories", Action = "Update", Description = "Update existing categories", IsActive = true },
                new Permission { Module = "Categories", Action = "Delete", Description = "Delete categories", IsActive = true },
                
                // Sales Module
                new Permission { Module = "Sales", Action = "Create", Description = "Create new sales", IsActive = true },
                new Permission { Module = "Sales", Action = "Read", Description = "View sales", IsActive = true },
                new Permission { Module = "Sales", Action = "Update", Description = "Update existing sales", IsActive = true },
                new Permission { Module = "Sales", Action = "Delete", Description = "Delete sales", IsActive = true },
                
                // Customers Module
                new Permission { Module = "Customers", Action = "Create", Description = "Create new customers", IsActive = true },
                new Permission { Module = "Customers", Action = "Read", Description = "View customers", IsActive = true },
                new Permission { Module = "Customers", Action = "Update", Description = "Update existing customers", IsActive = true },
                new Permission { Module = "Customers", Action = "Delete", Description = "Delete customers", IsActive = true },
                
                // Suppliers Module
                new Permission { Module = "Suppliers", Action = "Create", Description = "Create new suppliers", IsActive = true },
                new Permission { Module = "Suppliers", Action = "Read", Description = "View suppliers", IsActive = true },
                new Permission { Module = "Suppliers", Action = "Update", Description = "Update existing suppliers", IsActive = true },
                new Permission { Module = "Suppliers", Action = "Delete", Description = "Delete suppliers", IsActive = true },
                
                // Purchase Orders Module
                new Permission { Module = "PurchaseOrders", Action = "Create", Description = "Create new purchase orders", IsActive = true },
                new Permission { Module = "PurchaseOrders", Action = "Read", Description = "View purchase orders", IsActive = true },
                new Permission { Module = "PurchaseOrders", Action = "Update", Description = "Update existing purchase orders", IsActive = true },
                new Permission { Module = "PurchaseOrders", Action = "Receive", Description = "Receive purchase order items", IsActive = true },
                
                // Tables Module (Hospitality)
                new Permission { Module = "Tables", Action = "Create", Description = "Create new tables", IsActive = true },
                new Permission { Module = "Tables", Action = "Read", Description = "View tables", IsActive = true },
                new Permission { Module = "Tables", Action = "Update", Description = "Update existing tables", IsActive = true },
                new Permission { Module = "Tables", Action = "Delete", Description = "Delete tables", IsActive = true },
                new Permission { Module = "Tables", Action = "Manage", Description = "Manage table reservations and occupancy", IsActive = true },
                
                // Roles Module (Administration)
                new Permission { Module = "Roles", Action = "Create", Description = "Create new roles", IsActive = true },
                new Permission { Module = "Roles", Action = "Read", Description = "View roles", IsActive = true },
                new Permission { Module = "Roles", Action = "Update", Description = "Update existing roles", IsActive = true },
                new Permission { Module = "Roles", Action = "Delete", Description = "Delete roles", IsActive = true },
                new Permission { Module = "Roles", Action = "AssignPermissions", Description = "Assign permissions to roles", IsActive = true },
                
                // Users Module (Administration)
                new Permission { Module = "Users", Action = "Create", Description = "Create new users", IsActive = true },
                new Permission { Module = "Users", Action = "Read", Description = "View users", IsActive = true },
                new Permission { Module = "Users", Action = "Update", Description = "Update existing users", IsActive = true },
                new Permission { Module = "Users", Action = "Delete", Description = "Delete users", IsActive = true },
                
                // Reports Module
                new Permission { Module = "Reports", Action = "Sales", Description = "View sales reports", IsActive = true },
                new Permission { Module = "Reports", Action = "Inventory", Description = "View inventory reports", IsActive = true },
                new Permission { Module = "Reports", Action = "Financial", Description = "View financial reports", IsActive = true }
            };

            context.Permissions.AddRange(permissions);
            await context.SaveChangesAsync();
        }

        // Seed Roles
        if (!context.Roles.Any())
        {
            var roles = new List<Role>
            {
                new Role
                {
                    Name = "Administrator",
                    Description = "Full system access with all permissions",
                    IsActive = true,
                    IsSystemRole = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Role
                {
                    Name = "Manager",
                    Description = "Management level access to most modules",
                    IsActive = true,
                    IsSystemRole = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Role
                {
                    Name = "Sales Staff",
                    Description = "Sales and customer management access",
                    IsActive = true,
                    IsSystemRole = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Role
                {
                    Name = "Inventory Staff",
                    Description = "Products and supplier management access",
                    IsActive = true,
                    IsSystemRole = true,
                    CreatedDate = DateTime.UtcNow
                },
                new Role
                {
                    Name = "Cashier",
                    Description = "Basic sales operations access",
                    IsActive = true,
                    IsSystemRole = true,
                    CreatedDate = DateTime.UtcNow
                }
            };

            context.Roles.AddRange(roles);
            await context.SaveChangesAsync();

            // Assign Administrator role to admin user
            var adminUser = await context.Users.FirstOrDefaultAsync(u => u.Username == "admin");
            var adminRole = await context.Roles.FirstOrDefaultAsync(r => r.Name == "Administrator");
            
            if (adminUser != null && adminRole != null)
            {
                adminUser.RoleId = adminRole.Id;
                await context.SaveChangesAsync();
            }
        }

        // Seed Role Permissions
        if (!context.RolePermissions.Any())
        {
            var adminRole = await context.Roles.FirstOrDefaultAsync(r => r.Name == "Administrator");
            var allPermissions = await context.Permissions.ToListAsync();
            
            if (adminRole != null && allPermissions.Any())
            {
                // Administrator gets all permissions
                var adminRolePermissions = allPermissions.Select(p => new RolePermission
                {
                    RoleId = adminRole.Id,
                    PermissionId = p.Id,
                    IsGranted = true,
                    CreatedDate = DateTime.UtcNow
                }).ToList();

                context.RolePermissions.AddRange(adminRolePermissions);
                await context.SaveChangesAsync();
            }

            // Manager gets most permissions (excluding user/role management)
            var managerRole = await context.Roles.FirstOrDefaultAsync(r => r.Name == "Manager");
            if (managerRole != null)
            {
                var managerPermissions = allPermissions
                    .Where(p => !p.Module.Equals("Users", StringComparison.OrdinalIgnoreCase) && 
                               !p.Module.Equals("Roles", StringComparison.OrdinalIgnoreCase))
                    .Select(p => new RolePermission
                    {
                        RoleId = managerRole.Id,
                        PermissionId = p.Id,
                        IsGranted = true,
                        CreatedDate = DateTime.UtcNow
                    }).ToList();

                context.RolePermissions.AddRange(managerPermissions);
                await context.SaveChangesAsync();
            }

            // Sales Staff gets sales-related permissions
            var salesRole = await context.Roles.FirstOrDefaultAsync(r => r.Name == "Sales Staff");
            if (salesRole != null)
            {
                var salesPermissions = allPermissions
                    .Where(p => p.Module.Equals("Sales", StringComparison.OrdinalIgnoreCase) ||
                               p.Module.Equals("Customers", StringComparison.OrdinalIgnoreCase) ||
                               p.Module.Equals("Products", StringComparison.OrdinalIgnoreCase) && p.Action == "Read" ||
                               p.Module.Equals("Tables", StringComparison.OrdinalIgnoreCase))
                    .Select(p => new RolePermission
                    {
                        RoleId = salesRole.Id,
                        PermissionId = p.Id,
                        IsGranted = true,
                        CreatedDate = DateTime.UtcNow
                    }).ToList();

                context.RolePermissions.AddRange(salesPermissions);
                await context.SaveChangesAsync();
            }
        }
    }

    private static string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(hashedBytes);
    }
}